(() => {
    var r = {},
        e = {};

    function n(o) {
        var t = e[o];
        if (void 0 !== t) return t.exports;
        var i = e[o] = {
            exports: {}
        };
        return r[o](i, i.exports, n), i.exports
    }
    n.rv = function() {
        return "1.0.0-rc.0"
    }, n.ruid = "bundler=rspack@1.0.0-rc.0", ("undefined" == typeof window || !self.window) && (self.window = self)
})();
window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'test_2_single_track::canary';
window[window["TiktokAnalyticsObject"]]._vids = '';
window[window["TiktokAnalyticsObject"]]._cc = 'PK';
window[window.TiktokAnalyticsObject]._li || (window[window.TiktokAnalyticsObject]._li = {}), window[window.TiktokAnalyticsObject]._li["BUTALDTUNEDUE5MNG7PG"] = "faf84403-1c4a-11f0-aa2b-b83fd2c349dc";
window[window["TiktokAnalyticsObject"]]._cde = 390;;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = 'faf86dd1-1c4a-11f0-aa2b-b83fd2c349dc';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": false,
    "AutoConfig": false,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnrichIpv6": true,
    "EnrichIpv6V2": false,
    "EventBuilder": false,
    "HistoryObserver": false,
    "HitReservoir": false,
    "Identify": true,
    "JSBridge": false,
    "Monitor": false,
    "PageData": false,
    "PangleCookieMatching": true,
    "PerformanceInteraction": false,
    "RuntimeMeasurement": false,
    "Shopify": false,
    "WebFL": false
};
! function(n, t, i, e) {
    var o = [{
            id: "MWRmNzNmMi4wLjAuMjUw",
            map: {
                Monitor: !1
            }
        }, {
            id: "MWRmNzNmMi4wLjAuMjUw",
            map: {
                Monitor: !0
            }
        }],
        l = {
            "info": {
                "pixelCode": "BUTALDTUNEDUE5MNG7PG",
                "name": "TikTok Pixel for Shopify 1606068919",
                "status": 0,
                "setupMode": 1,
                "partner": "Shopify",
                "advertiserID": "6895022365126688769",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": true,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": null,
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {
                        "shop.app": [{
                            "version": "stable",
                            "rule_key": "shop.app",
                            "valueXpath": "//strong[@class='_19gi7yt0 _19gi7ytw _19gi7ytv _1fragemnu _19gi7yt2']",
                            "valueClass": "_19gi7yt0 _19gi7ytw _19gi7ytv _1fragemnu _19gi7yt2",
                            "currency": {
                                "val": "GBP",
                                "xpath": "//abbr[@class='_19gi7yt0 _19gi7ytu _19gi7ytt _1fragemnt _19gi7ytj notranslate _19gi7yt1c _19gi7yt19 _1fragems5']"
                            }
                        }]
                    }
                },
                "DiagnosticsConsole": true,
                "PangleCookieMatching": false,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                },
                "RuntimeMeasurement": true,
                "JSBridge": true
            },
            "rules": []
        },
        a = "https://analytics.tiktok.com/i18n/pixel/static/",
        n = null == (n = l) || null == (n = n.info) ? void 0 : n.pixelCode;

    function c() {
        return self && self.TiktokAnalyticsObject || "ttq"
    }

    function r() {
        return self && self[c()]
    }

    function d(n, t) {
        t = r()[t];
        return t && t[n] || {}
    }
    var s, u, f = r();
    f || (f = [], self && (self[c()] = f)), Object.assign(l, {
            options: d(n, "_o")
        }), s = l, f._i || (f._i = {}), (u = s.info.pixelCode) && (f._i[u] || (f._i[u] = []), Object.assign(f._i[u], s), f._i[u]._load = +new Date), Object.assign(l.info, {
            loadStart: d(n, "_t"),
            loadEnd: d(n, "_i")._load,
            loadId: f._li && f._li[n] || ""
        }), null != (t = (i = f).instance) && null != (t = t.call(i, n)) && null != (e = t.setPixelInfo) && e.call(t, l.info),
        function t(i, e, o) {
            if (!(o && 2 < o)) try {
                var n, l;
                (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(i): ((n = document.createElement("script")).type = "text/javascript", n.async = !0, n.src = i, n.setAttribute("data-id", e), (l = document.getElementsByTagName("script")[0]) && l.parentNode && l.parentNode.insertBefore(n, l))
            } catch (n) {
                t(i, e, o ? o + 1 : 2)
            }
        }(function(n, t, i) {
            var l = 0 < arguments.length && void 0 !== n ? n : {},
                a = 1 < arguments.length ? t : void 0,
                n = 2 < arguments.length ? i : void 0,
                t = function(n, t) {
                    for (var i = 0; i < n.length; i++)
                        if (t.call(null, n[i], i)) return n[i]
                }(o, function(n) {
                    for (var t = n.map, i = Object.keys(t), e = function(n) {
                            return !(!l[n] || !a[n]) === t[n]
                        }, o = 0; o < i.length; o++)
                        if (!e.call(null, i[o], o)) return !1;
                    return !0
                });
            return t ? "".concat(n, "shopify.").concat(t.id, ".js") : "".concat(n, "shopify.").concat(o[0].id, ".js")
        }(f._plugins, l.plugins, a), n)
}();