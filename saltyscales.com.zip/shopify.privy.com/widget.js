window._d_site = window._d_site || "F415A953B9F526CA9D9BCEDD";

(function(p, r, i, v, y) {
    p[i] = p[i] || function() {
        (p[i].q = p[i].q || []).push(arguments)
    };
    v = r.createElement('script');
    v.async = 1;
    v.src = 'https://widget.privy.com/assets/widget.js';
    y = r.getElementsByTagName('script')[0];
    y.parentNode.insertBefore(v, y);
})(window, document, 'Privy');