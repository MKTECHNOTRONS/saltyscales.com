var browserLang = navigator.language || navigator.userLanguage;

! function(t, e) {
    "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define("Noty", [], e) : "object" == typeof exports ? exports.Noty = e() : t.Noty = e()
}(this, function() {
    return function(t) {
        function e(o) {
            if (n[o]) return n[o].exports;
            var i = n[o] = {
                i: o,
                l: !1,
                exports: {}
            };
            return t[o].call(i.exports, i, i.exports, e), i.l = !0, i.exports
        }
        var n = {};
        return e.m = t, e.c = n, e.i = function(t) {
            return t
        }, e.d = function(t, n, o) {
            e.o(t, n) || Object.defineProperty(t, n, {
                configurable: !1,
                enumerable: !0,
                get: o
            })
        }, e.n = function(t) {
            var n = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return e.d(n, "a", n), n
        }, e.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }, e.p = "", e(e.s = 6)
    }([function(t, e, n) {
        "use strict";

        function o(t, e, n) {
            var o = void 0;
            if (!n) {
                for (o in e)
                    if (e.hasOwnProperty(o) && e[o] === t) return !0
            } else
                for (o in e)
                    if (e.hasOwnProperty(o) && e[o] === t) return !0;
            return !1
        }

        function i(t) {
            t = t || window.event, void 0 !== t.stopPropagation ? t.stopPropagation() : t.cancelBubble = !0
        }

        function r() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                e = "noty_" + t + "_";
            return e += "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                var e = 16 * Math.random() | 0;
                return ("x" === t ? e : 3 & e | 8).toString(16)
            })
        }

        function s(t) {
            var e = t.offsetHeight,
                n = window.getComputedStyle(t);
            return e += parseInt(n.marginTop) + parseInt(n.marginBottom)
        }

        function u(t, e, n) {
            var o = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            e = e.split(" ");
            for (var i = 0; i < e.length; i++) document.addEventListener ? t.addEventListener(e[i], n, o) : document.attachEvent && t.attachEvent("on" + e[i], n)
        }

        function a(t, e) {
            return ("string" == typeof t ? t : f(t)).indexOf(" " + e + " ") >= 0
        }

        function c(t, e) {
            var n = f(t),
                o = n + e;
            a(n, e) || (t.className = o.substring(1))
        }

        function l(t, e) {
            var n = f(t),
                o = void 0;
            a(t, e) && (o = n.replace(" " + e + " ", " "), t.className = o.substring(1, o.length - 1))
        }

        function d(t) {
            t.parentNode && t.parentNode.removeChild(t)
        }

        function f(t) {
            return (" " + (t && t.className || "") + " ").replace(/\s+/gi, " ")
        }

        function h() {
            function t() {
                b.PageHidden = document[s], o()
            }

            function e() {
                b.PageHidden = !0, o()
            }

            function n() {
                b.PageHidden = !1, o()
            }

            function o() {
                b.PageHidden ? i() : r()
            }

            function i() {
                setTimeout(function() {
                    Object.keys(b.Store).forEach(function(t) {
                        b.Store.hasOwnProperty(t) && b.Store[t].options.visibilityControl && b.Store[t].stop()
                    })
                }, 100)
            }

            function r() {
                setTimeout(function() {
                    Object.keys(b.Store).forEach(function(t) {
                        b.Store.hasOwnProperty(t) && b.Store[t].options.visibilityControl && b.Store[t].resume()
                    }), b.queueRenderAll()
                }, 100)
            }
            var s = void 0,
                a = void 0;
            void 0 !== document.hidden ? (s = "hidden", a = "visibilitychange") : void 0 !== document.msHidden ? (s = "msHidden", a = "msvisibilitychange") : void 0 !== document.webkitHidden && (s = "webkitHidden", a = "webkitvisibilitychange"), a && u(document, a, t), u(window, "blur", e), u(window, "focus", n)
        }

        function p(t) {
            if (t.hasSound) {
                var e = document.createElement("audio");
                t.options.sounds.sources.forEach(function(t) {
                    var n = document.createElement("source");
                    n.src = t, n.type = "audio/" + m(t), e.appendChild(n)
                }), t.barDom ? t.barDom.appendChild(e) : document.querySelector("body").appendChild(e), e.volume = t.options.sounds.volume, t.soundPlayed || (e.play(), t.soundPlayed = !0), e.onended = function() {
                    d(e)
                }
            }
        }

        function m(t) {
            return t.match(/\.([^.]+)$/)[1]
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.css = e.deepExtend = e.animationEndEvents = void 0;
        var v = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        };
        e.inArray = o, e.stopPropagation = i, e.generateID = r, e.outerHeight = s, e.addListener = u, e.hasClass = a, e.addClass = c, e.removeClass = l, e.remove = d, e.classList = f, e.visibilityChangeFlow = h, e.createAudioElements = p;
        var y = n(1),
            b = function(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t)
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e.default = t, e
            }(y);
        e.animationEndEvents = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", e.deepExtend = function t(e) {
            e = e || {};
            for (var n = 1; n < arguments.length; n++) {
                var o = arguments[n];
                if (o)
                    for (var i in o) o.hasOwnProperty(i) && (Array.isArray(o[i]) ? e[i] = o[i] : "object" === v(o[i]) && null !== o[i] ? e[i] = t(e[i], o[i]) : e[i] = o[i])
            }
            return e
        }, e.css = function() {
            function t(t) {
                return t.replace(/^-ms-/, "ms-").replace(/-([\da-z])/gi, function(t, e) {
                    return e.toUpperCase()
                })
            }

            function e(t) {
                var e = document.body.style;
                if (t in e) return t;
                for (var n = i.length, o = t.charAt(0).toUpperCase() + t.slice(1), r = void 0; n--;)
                    if ((r = i[n] + o) in e) return r;
                return t
            }

            function n(n) {
                return n = t(n), r[n] || (r[n] = e(n))
            }

            function o(t, e, o) {
                e = n(e), t.style[e] = o
            }
            var i = ["Webkit", "O", "Moz", "ms"],
                r = {};
            return function(t, e) {
                var n = arguments,
                    i = void 0,
                    r = void 0;
                if (2 === n.length)
                    for (i in e) e.hasOwnProperty(i) && void 0 !== (r = e[i]) && e.hasOwnProperty(i) && o(t, i, r);
                else o(t, n[1], n[2])
            }
        }()
    }, function(t, e, n) {
        "use strict";

        function o() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "global",
                e = 0,
                n = x;
            return E.hasOwnProperty(t) && (n = E[t].maxVisible, Object.keys(P).forEach(function(n) {
                P[n].options.queue !== t || P[n].closed || e++
            })), {
                current: e,
                maxVisible: n
            }
        }

        function i(t) {
            E.hasOwnProperty(t.options.queue) || (E[t.options.queue] = {
                maxVisible: x,
                queue: []
            }), E[t.options.queue].queue.push(t)
        }

        function r(t) {
            if (E.hasOwnProperty(t.options.queue)) {
                var e = [];
                Object.keys(E[t.options.queue].queue).forEach(function(n) {
                    E[t.options.queue].queue[n].id !== t.id && e.push(E[t.options.queue].queue[n])
                }), E[t.options.queue].queue = e
            }
        }

        function s() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "global";
            if (E.hasOwnProperty(t)) {
                var e = E[t].queue.shift();
                e && e.show()
            }
        }

        function u() {
            Object.keys(E).forEach(function(t) {
                s(t)
            })
        }

        function a(t) {
            var e = k.generateID("ghost"),
                n = document.createElement("div");
            n.setAttribute("id", e), k.css(n, {
                height: k.outerHeight(t.barDom) + "px"
            }), t.barDom.insertAdjacentHTML("afterend", n.outerHTML), k.remove(t.barDom), n = document.getElementById(e), k.addClass(n, "noty_fix_effects_height"), k.addListener(n, k.animationEndEvents, function() {
                k.remove(n)
            })
        }

        function c(t) {
            m(t);
            var e = '<div class="noty_body">' + t.options.text + "</div>" + d(t) + '<div class="noty_progressbar"></div>';
            t.barDom = document.createElement("div"), t.barDom.setAttribute("id", t.id), k.addClass(t.barDom, "noty_bar noty_type__" + t.options.type + " noty_theme__" + t.options.theme), t.barDom.innerHTML = e, b(t, "onTemplate")
        }

        function l(t) {
            return !(!t.options.buttons || !Object.keys(t.options.buttons).length)
        }

        function d(t) {
            if (l(t)) {
                var e = document.createElement("div");
                return k.addClass(e, "noty_buttons"), Object.keys(t.options.buttons).forEach(function(n) {
                    e.appendChild(t.options.buttons[n].dom)
                }), t.options.buttons.forEach(function(t) {
                    e.appendChild(t.dom)
                }), e.outerHTML
            }
            return ""
        }

        function f(t) {
            t.options.modal && (0 === C && p(), e.DocModalCount = C += 1)
        }

        function h(t) {
            if (t.options.modal && C > 0 && (e.DocModalCount = C -= 1, C <= 0)) {
                var n = document.querySelector(".noty_modal");
                n && (k.removeClass(n, "noty_modal_open"), k.addClass(n, "noty_modal_close"), k.addListener(n, k.animationEndEvents, function() {
                    k.remove(n)
                }))
            }
        }

        function p() {
            var t = document.querySelector("body"),
                e = document.createElement("div");
            k.addClass(e, "noty_modal"), t.insertBefore(e, t.firstChild), k.addClass(e, "noty_modal_open"), k.addListener(e, k.animationEndEvents, function() {
                k.removeClass(e, "noty_modal_open")
            })
        }

        function m(t) {
            if (t.options.container) return void(t.layoutDom = document.querySelector(t.options.container));
            var e = "noty_layout__" + t.options.layout;
            t.layoutDom = document.querySelector("div#" + e), t.layoutDom || (t.layoutDom = document.createElement("div"), t.layoutDom.setAttribute("id", e), t.layoutDom.setAttribute("role", "alert"), t.layoutDom.setAttribute("aria-live", "polite"), k.addClass(t.layoutDom, "noty_layout"), document.querySelector("body").appendChild(t.layoutDom))
        }

        function v(t) {
            t.options.timeout && (t.options.progressBar && t.progressDom && k.css(t.progressDom, {
                transition: "width " + t.options.timeout + "ms linear",
                width: "0%"
            }), clearTimeout(t.closeTimer), t.closeTimer = setTimeout(function() {
                t.close()
            }, t.options.timeout))
        }

        function y(t) {
            t.options.timeout && t.closeTimer && (clearTimeout(t.closeTimer), t.closeTimer = -1, t.options.progressBar && t.progressDom && k.css(t.progressDom, {
                transition: "width 0ms linear",
                width: "100%"
            }))
        }

        function b(t, e) {
            t.listeners.hasOwnProperty(e) && t.listeners[e].forEach(function(e) {
                "function" == typeof e && e.apply(t)
            })
        }

        function w(t) {
            b(t, "afterShow"), v(t), k.addListener(t.barDom, "mouseenter", function() {
                y(t)
            }), k.addListener(t.barDom, "mouseleave", function() {
                v(t)
            })
        }

        function g(t) {
            delete P[t.id], t.closing = !1, b(t, "afterClose"), k.remove(t.barDom), 0 !== t.layoutDom.querySelectorAll(".noty_bar").length || t.options.container || k.remove(t.layoutDom), (k.inArray("docVisible", t.options.titleCount.conditions) || k.inArray("docHidden", t.options.titleCount.conditions)) && D.decrement(), s(t.options.queue)
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.Defaults = e.Store = e.Queues = e.DefaultMaxVisible = e.docTitle = e.DocModalCount = e.PageHidden = void 0, e.getQueueCounts = o, e.addToQueue = i, e.removeFromQueue = r, e.queueRender = s, e.queueRenderAll = u, e.ghostFix = a, e.build = c, e.hasButtons = l, e.handleModal = f, e.handleModalClose = h, e.queueClose = v, e.dequeueClose = y, e.fire = b, e.openFlow = w, e.closeFlow = g;
        var _ = n(0),
            k = function(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t)
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e.default = t, e
            }(_),
            C = (e.PageHidden = !1, e.DocModalCount = 0),
            S = {
                originalTitle: null,
                count: 0,
                changed: !1,
                timer: -1
            },
            D = e.docTitle = {
                increment: function() {
                    S.count++, D._update()
                },
                decrement: function() {
                    if (--S.count <= 0) return void D._clear();
                    D._update()
                },
                _update: function() {
                    var t = document.title;
                    S.changed ? document.title = "(" + S.count + ") " + S.originalTitle : (S.originalTitle = t, document.title = "(" + S.count + ") " + t, S.changed = !0)
                },
                _clear: function() {
                    S.changed && (S.count = 0, document.title = S.originalTitle, S.changed = !1)
                }
            },
            x = e.DefaultMaxVisible = 6,
            E = e.Queues = {
                global: {
                    maxVisible: x,
                    queue: []
                }
            },
            P = e.Store = {};
        e.Defaults = {
            type: "alert",
            layout: "topRight",
            theme: "mint",
            text: "",
            timeout: !1,
            progressBar: !0,
            closeWith: ["click"],
            animation: {
                open: "noty_effects_open",
                close: "noty_effects_close"
            },
            id: !1,
            force: !1,
            killer: !1,
            queue: "global",
            container: !1,
            buttons: [],
            callbacks: {
                beforeShow: null,
                onShow: null,
                afterShow: null,
                onClose: null,
                afterClose: null,
                onClick: null,
                onHover: null,
                onTemplate: null
            },
            sounds: {
                sources: [],
                volume: 1,
                conditions: []
            },
            titleCount: {
                conditions: []
            },
            modal: !1,
            visibilityControl: !1
        }
    }, function(t, e, n) {
        "use strict";

        function o(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.NotyButton = void 0;
        var i = n(0),
            r = function(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t)
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e.default = t, e
            }(i);
        e.NotyButton = function t(e, n, i) {
            var s = this,
                u = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
            return o(this, t), this.dom = document.createElement("button"), this.dom.innerHTML = e, this.id = u.id = u.id || r.generateID("button"), this.cb = i, Object.keys(u).forEach(function(t) {
                s.dom.setAttribute(t, u[t])
            }), r.addClass(this.dom, n || "noty_btn"), this
        }
    }, function(t, e, n) {
        "use strict";

        function o(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var i = function() {
            function t(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }
            return function(e, n, o) {
                return n && t(e.prototype, n), o && t(e, o), e
            }
        }();
        e.Push = function() {
            function t() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "/service-worker.js";
                return o(this, t), this.subData = {}, this.workerPath = e, this.listeners = {
                    onPermissionGranted: [],
                    onPermissionDenied: [],
                    onSubscriptionSuccess: [],
                    onSubscriptionCancel: [],
                    onWorkerError: [],
                    onWorkerSuccess: [],
                    onWorkerNotSupported: []
                }, this
            }
            return i(t, [{
                key: "on",
                value: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
                    return "function" == typeof e && this.listeners.hasOwnProperty(t) && this.listeners[t].push(e), this
                }
            }, {
                key: "fire",
                value: function(t) {
                    var e = this,
                        n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                    this.listeners.hasOwnProperty(t) && this.listeners[t].forEach(function(t) {
                        "function" == typeof t && t.apply(e, n)
                    })
                }
            }, {
                key: "create",
                value: function() {
                    console.log("NOT IMPLEMENTED YET")
                }
            }, {
                key: "isSupported",
                value: function() {
                    var t = !1;
                    try {
                        t = window.Notification || window.webkitNotifications || navigator.mozNotification || window.external && void 0 !== window.external.msIsSiteMode()
                    } catch (t) {}
                    return t
                }
            }, {
                key: "getPermissionStatus",
                value: function() {
                    var t = "default";
                    if (window.Notification && window.Notification.permissionLevel) t = window.Notification.permissionLevel;
                    else if (window.webkitNotifications && window.webkitNotifications.checkPermission) switch (window.webkitNotifications.checkPermission()) {
                        case 1:
                            t = "default";
                            break;
                        case 0:
                            t = "granted";
                            break;
                        default:
                            t = "denied"
                    } else window.Notification && window.Notification.permission ? t = window.Notification.permission : navigator.mozNotification ? t = "granted" : window.external && void 0 !== window.external.msIsSiteMode() && (t = window.external.msIsSiteMode() ? "granted" : "default");
                    return t.toString().toLowerCase()
                }
            }, {
                key: "getEndpoint",
                value: function(t) {
                    var e = t.endpoint,
                        n = t.subscriptionId;
                    return n && -1 === e.indexOf(n) && (e += "/" + n), e
                }
            }, {
                key: "isSWRegistered",
                value: function() {
                    try {
                        return "activated" === navigator.serviceWorker.controller.state
                    } catch (t) {
                        return !1
                    }
                }
            }, {
                key: "unregisterWorker",
                value: function() {
                    var t = this;
                    "serviceWorker" in navigator && navigator.serviceWorker.getRegistrations().then(function(e) {
                        var n = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var r, s = e[Symbol.iterator](); !(n = (r = s.next()).done); n = !0) {
                                r.value.unregister(), t.fire("onSubscriptionCancel")
                            }
                        } catch (t) {
                            o = !0, i = t
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                    })
                }
            }, {
                key: "requestSubscription",
                value: function() {
                    var t = this,
                        e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        n = this,
                        o = this.getPermissionStatus(),
                        i = function(o) {
                            "granted" === o ? (t.fire("onPermissionGranted"), "serviceWorker" in navigator ? navigator.serviceWorker.register(t.workerPath).then(function() {
                                navigator.serviceWorker.ready.then(function(t) {
                                    n.fire("onWorkerSuccess"), t.pushManager.subscribe({
                                        userVisibleOnly: e
                                    }).then(function(t) {
                                        var e = t.getKey("p256dh"),
                                            o = t.getKey("auth");
                                        n.subData = {
                                            endpoint: n.getEndpoint(t),
                                            p256dh: e ? window.btoa(String.fromCharCode.apply(null, new Uint8Array(e))) : null,
                                            auth: o ? window.btoa(String.fromCharCode.apply(null, new Uint8Array(o))) : null
                                        }, n.fire("onSubscriptionSuccess", [n.subData])
                                    }).catch(function(t) {
                                        n.fire("onWorkerError", [t])
                                    })
                                })
                            }) : n.fire("onWorkerNotSupported")) : "denied" === o && (t.fire("onPermissionDenied"), t.unregisterWorker())
                        };
                    "default" === o ? window.Notification && window.Notification.requestPermission ? window.Notification.requestPermission(i) : window.webkitNotifications && window.webkitNotifications.checkPermission && window.webkitNotifications.requestPermission(i) : i(o)
                }
            }]), t
        }()
    }, function(t, e, n) {
        (function(e, o) {
            ! function(e, n) {
                t.exports = n()
            }(0, function() {
                "use strict";

                function t(t) {
                    var e = typeof t;
                    return null !== t && ("object" === e || "function" === e)
                }

                function i(t) {
                    return "function" == typeof t
                }

                function r(t) {
                    z = t
                }

                function s(t) {
                    U = t
                }

                function u() {
                    return void 0 !== R ? function() {
                        R(c)
                    } : a()
                }

                function a() {
                    var t = setTimeout;
                    return function() {
                        return t(c, 1)
                    }
                }

                function c() {
                    for (var t = 0; t < Q; t += 2) {
                        (0, X[t])(X[t + 1]), X[t] = void 0, X[t + 1] = void 0
                    }
                    Q = 0
                }

                function l(t, e) {
                    var n = arguments,
                        o = this,
                        i = new this.constructor(f);
                    void 0 === i[tt] && A(i);
                    var r = o._state;
                    return r ? function() {
                        var t = n[r - 1];
                        U(function() {
                            return P(r, i, t, o._result)
                        })
                    }() : S(o, i, t, e), i
                }

                function d(t) {
                    var e = this;
                    if (t && "object" == typeof t && t.constructor === e) return t;
                    var n = new e(f);
                    return g(n, t), n
                }

                function f() {}

                function h() {
                    return new TypeError("You cannot resolve a promise with itself")
                }

                function p() {
                    return new TypeError("A promises callback cannot return that same promise.")
                }

                function m(t) {
                    try {
                        return t.then
                    } catch (t) {
                        return it.error = t, it
                    }
                }

                function v(t, e, n, o) {
                    try {
                        t.call(e, n, o)
                    } catch (t) {
                        return t
                    }
                }

                function y(t, e, n) {
                    U(function(t) {
                        var o = !1,
                            i = v(n, e, function(n) {
                                o || (o = !0, e !== n ? g(t, n) : k(t, n))
                            }, function(e) {
                                o || (o = !0, C(t, e))
                            }, "Settle: " + (t._label || " unknown promise"));
                        !o && i && (o = !0, C(t, i))
                    }, t)
                }

                function b(t, e) {
                    e._state === nt ? k(t, e._result) : e._state === ot ? C(t, e._result) : S(e, void 0, function(e) {
                        return g(t, e)
                    }, function(e) {
                        return C(t, e)
                    })
                }

                function w(t, e, n) {
                    e.constructor === t.constructor && n === l && e.constructor.resolve === d ? b(t, e) : n === it ? (C(t, it.error), it.error = null) : void 0 === n ? k(t, e) : i(n) ? y(t, e, n) : k(t, e)
                }

                function g(e, n) {
                    e === n ? C(e, h()) : t(n) ? w(e, n, m(n)) : k(e, n)
                }

                function _(t) {
                    t._onerror && t._onerror(t._result), D(t)
                }

                function k(t, e) {
                    t._state === et && (t._result = e, t._state = nt, 0 !== t._subscribers.length && U(D, t))
                }

                function C(t, e) {
                    t._state === et && (t._state = ot, t._result = e, U(_, t))
                }

                function S(t, e, n, o) {
                    var i = t._subscribers,
                        r = i.length;
                    t._onerror = null, i[r] = e, i[r + nt] = n, i[r + ot] = o, 0 === r && t._state && U(D, t)
                }

                function D(t) {
                    var e = t._subscribers,
                        n = t._state;
                    if (0 !== e.length) {
                        for (var o = void 0, i = void 0, r = t._result, s = 0; s < e.length; s += 3) o = e[s], i = e[s + n], o ? P(n, o, i, r) : i(r);
                        t._subscribers.length = 0
                    }
                }

                function x() {
                    this.error = null
                }

                function E(t, e) {
                    try {
                        return t(e)
                    } catch (t) {
                        return rt.error = t, rt
                    }
                }

                function P(t, e, n, o) {
                    var r = i(n),
                        s = void 0,
                        u = void 0,
                        a = void 0,
                        c = void 0;
                    if (r) {
                        if (s = E(n, o), s === rt ? (c = !0, u = s.error, s.error = null) : a = !0, e === s) return void C(e, p())
                    } else s = o, a = !0;
                    e._state !== et || (r && a ? g(e, s) : c ? C(e, u) : t === nt ? k(e, s) : t === ot && C(e, s))
                }

                function T(t, e) {
                    try {
                        e(function(e) {
                            g(t, e)
                        }, function(e) {
                            C(t, e)
                        })
                    } catch (e) {
                        C(t, e)
                    }
                }

                function O() {
                    return st++
                }

                function A(t) {
                    t[tt] = st++, t._state = void 0, t._result = void 0, t._subscribers = []
                }

                function M(t, e) {
                    this._instanceConstructor = t, this.promise = new t(f), this.promise[tt] || A(this.promise), I(e) ? (this.length = e.length, this._remaining = e.length, this._result = new Array(this.length), 0 === this.length ? k(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(e), 0 === this._remaining && k(this.promise, this._result))) : C(this.promise, q())
                }

                function q() {
                    return new Error("Array Methods must be provided an Array")
                }

                function j(t) {
                    return new M(this, t).promise
                }

                function N(t) {
                    var e = this;
                    return new e(I(t) ? function(n, o) {
                        for (var i = t.length, r = 0; r < i; r++) e.resolve(t[r]).then(n, o)
                    } : function(t, e) {
                        return e(new TypeError("You must pass an array to race."))
                    })
                }

                function L(t) {
                    var e = this,
                        n = new e(f);
                    return C(n, t), n
                }

                function H() {
                    throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")
                }

                function W() {
                    throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")
                }

                function V(t) {
                    this[tt] = O(), this._result = this._state = void 0, this._subscribers = [], f !== t && ("function" != typeof t && H(), this instanceof V ? T(this, t) : W())
                }

                function B() {
                    var t = void 0;
                    if (void 0 !== o) t = o;
                    else if ("undefined" != typeof self) t = self;
                    else try {
                        t = Function("return this")()
                    } catch (t) {
                        throw new Error("polyfill failed because global object is unavailable in this environment")
                    }
                    var e = t.Promise;
                    if (e) {
                        var n = null;
                        try {
                            n = Object.prototype.toString.call(e.resolve())
                        } catch (t) {}
                        if ("[object Promise]" === n && !e.cast) return
                    }
                    t.Promise = V
                }
                var F = void 0;
                F = Array.isArray ? Array.isArray : function(t) {
                    return "[object Array]" === Object.prototype.toString.call(t)
                };
                var I = F,
                    Q = 0,
                    R = void 0,
                    z = void 0,
                    U = function(t, e) {
                        X[Q] = t, X[Q + 1] = e, 2 === (Q += 2) && (z ? z(c) : Z())
                    },
                    Y = "undefined" != typeof window ? window : void 0,
                    K = Y || {},
                    G = K.MutationObserver || K.WebKitMutationObserver,
                    $ = "undefined" == typeof self && void 0 !== e && "[object process]" === {}.toString.call(e),
                    J = "undefined" != typeof Uint8ClampedArray && "undefined" != typeof importScripts && "undefined" != typeof MessageChannel,
                    X = new Array(1e3),
                    Z = void 0;
                Z = $ ? function() {
                    return function() {
                        return e.nextTick(c)
                    }
                }() : G ? function() {
                    var t = 0,
                        e = new G(c),
                        n = document.createTextNode("");
                    return e.observe(n, {
                            characterData: !0
                        }),
                        function() {
                            n.data = t = ++t % 2
                        }
                }() : J ? function() {
                    var t = new MessageChannel;
                    return t.port1.onmessage = c,
                        function() {
                            return t.port2.postMessage(0)
                        }
                }() : void 0 === Y ? function() {
                    try {
                        var t = n(9);
                        return R = t.runOnLoop || t.runOnContext, u()
                    } catch (t) {
                        return a()
                    }
                }() : a();
                var tt = Math.random().toString(36).substring(16),
                    et = void 0,
                    nt = 1,
                    ot = 2,
                    it = new x,
                    rt = new x,
                    st = 0;
                return M.prototype._enumerate = function(t) {
                    for (var e = 0; this._state === et && e < t.length; e++) this._eachEntry(t[e], e)
                }, M.prototype._eachEntry = function(t, e) {
                    var n = this._instanceConstructor,
                        o = n.resolve;
                    if (o === d) {
                        var i = m(t);
                        if (i === l && t._state !== et) this._settledAt(t._state, e, t._result);
                        else if ("function" != typeof i) this._remaining--, this._result[e] = t;
                        else if (n === V) {
                            var r = new n(f);
                            w(r, t, i), this._willSettleAt(r, e)
                        } else this._willSettleAt(new n(function(e) {
                            return e(t)
                        }), e)
                    } else this._willSettleAt(o(t), e)
                }, M.prototype._settledAt = function(t, e, n) {
                    var o = this.promise;
                    o._state === et && (this._remaining--, t === ot ? C(o, n) : this._result[e] = n), 0 === this._remaining && k(o, this._result)
                }, M.prototype._willSettleAt = function(t, e) {
                    var n = this;
                    S(t, void 0, function(t) {
                        return n._settledAt(nt, e, t)
                    }, function(t) {
                        return n._settledAt(ot, e, t)
                    })
                }, V.all = j, V.race = N, V.resolve = d, V.reject = L, V._setScheduler = r, V._setAsap = s, V._asap = U, V.prototype = {
                    constructor: V,
                    then: l,
                    catch: function(t) {
                        return this.then(null, t)
                    }
                }, V.polyfill = B, V.Promise = V, V
            })
        }).call(e, n(7), n(8))
    }, function(t, e) {}, function(t, e, n) {
        "use strict";

        function o(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
            return e.default = t, e
        }

        function i(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var r = function() {
            function t(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }
            return function(e, n, o) {
                return n && t(e.prototype, n), o && t(e, o), e
            }
        }();
        n(5);
        var s = n(4),
            u = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }(s),
            a = n(0),
            c = o(a),
            l = n(1),
            d = o(l),
            f = n(2),
            h = n(3),
            p = function() {
                function t() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return i(this, t), this.options = c.deepExtend({}, d.Defaults, e), this.id = this.options.id || c.generateID("bar"), this.closeTimer = -1, this.barDom = null, this.layoutDom = null, this.progressDom = null, this.showing = !1, this.shown = !1, this.closed = !1, this.closing = !1, this.killable = this.options.timeout || this.options.closeWith.length > 0, this.hasSound = this.options.sounds.sources.length > 0, this.soundPlayed = !1, this.listeners = {
                        beforeShow: [],
                        onShow: [],
                        afterShow: [],
                        onClose: [],
                        afterClose: [],
                        onClick: [],
                        onHover: [],
                        onTemplate: []
                    }, this.promises = {
                        show: null,
                        close: null
                    }, this.on("beforeShow", this.options.callbacks.beforeShow), this.on("onShow", this.options.callbacks.onShow), this.on("afterShow", this.options.callbacks.afterShow), this.on("onClose", this.options.callbacks.onClose), this.on("afterClose", this.options.callbacks.afterClose), this.on("onClick", this.options.callbacks.onClick), this.on("onHover", this.options.callbacks.onHover), this.on("onTemplate", this.options.callbacks.onTemplate), this
                }
                return r(t, [{
                    key: "on",
                    value: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
                        return "function" == typeof e && this.listeners.hasOwnProperty(t) && this.listeners[t].push(e), this
                    }
                }, {
                    key: "show",
                    value: function() {
                        var e = this;
                        !0 === this.options.killer ? t.closeAll() : "string" == typeof this.options.killer && t.closeAll(this.options.killer);
                        var n = d.getQueueCounts(this.options.queue);
                        if (n.current >= n.maxVisible || d.PageHidden && this.options.visibilityControl) return d.addToQueue(this), d.PageHidden && this.hasSound && c.inArray("docHidden", this.options.sounds.conditions) && c.createAudioElements(this), d.PageHidden && c.inArray("docHidden", this.options.titleCount.conditions) && d.docTitle.increment(), this;
                        if (d.Store[this.id] = this, d.fire(this, "beforeShow"), this.showing = !0, this.closing) return this.showing = !1, this;
                        if (d.build(this), d.handleModal(this), this.options.force ? this.layoutDom.insertBefore(this.barDom, this.layoutDom.firstChild) : this.layoutDom.appendChild(this.barDom), this.hasSound && !this.soundPlayed && c.inArray("docVisible", this.options.sounds.conditions) && c.createAudioElements(this), c.inArray("docVisible", this.options.titleCount.conditions) && d.docTitle.increment(), this.shown = !0, this.closed = !1, d.hasButtons(this) && Object.keys(this.options.buttons).forEach(function(t) {
                                var n = e.barDom.querySelector("#" + e.options.buttons[t].id);
                                c.addListener(n, "click", function(n) {
                                    c.stopPropagation(n), e.options.buttons[t].cb()
                                })
                            }), this.progressDom = this.barDom.querySelector(".noty_progressbar"), c.inArray("click", this.options.closeWith) && (c.addClass(this.barDom, "noty_close_with_click"), c.addListener(this.barDom, "click", function(t) {
                                c.stopPropagation(t), d.fire(e, "onClick"), e.close()
                            }, !1)), c.addListener(this.barDom, "mouseenter", function() {
                                d.fire(e, "onHover")
                            }, !1), this.options.timeout && c.addClass(this.barDom, "noty_has_timeout"), this.options.progressBar && c.addClass(this.barDom, "noty_has_progressbar"), c.inArray("button", this.options.closeWith)) {
                            c.addClass(this.barDom, "noty_close_with_button");
                            var o = document.createElement("div");
                            c.addClass(o, "noty_close_button"), o.innerHTML = "×", this.barDom.appendChild(o), c.addListener(o, "click", function(t) {
                                c.stopPropagation(t), e.close()
                            }, !1)
                        }
                        return d.fire(this, "onShow"), null === this.options.animation.open ? this.promises.show = new u.default(function(t) {
                            t()
                        }) : "function" == typeof this.options.animation.open ? this.promises.show = new u.default(this.options.animation.open.bind(this)) : (c.addClass(this.barDom, this.options.animation.open), this.promises.show = new u.default(function(t) {
                            c.addListener(e.barDom, c.animationEndEvents, function() {
                                c.removeClass(e.barDom, e.options.animation.open), t()
                            })
                        })), this.promises.show.then(function() {
                            var t = e;
                            setTimeout(function() {
                                d.openFlow(t)
                            }, 100)
                        }), this
                    }
                }, {
                    key: "stop",
                    value: function() {
                        return d.dequeueClose(this), this
                    }
                }, {
                    key: "resume",
                    value: function() {
                        return d.queueClose(this), this
                    }
                }, {
                    key: "setTimeout",
                    value: function(t) {
                        function e(e) {
                            return t.apply(this, arguments)
                        }
                        return e.toString = function() {
                            return t.toString()
                        }, e
                    }(function(t) {
                        if (this.stop(), this.options.timeout = t, this.barDom) {
                            this.options.timeout ? c.addClass(this.barDom, "noty_has_timeout") : c.removeClass(this.barDom, "noty_has_timeout");
                            var e = this;
                            setTimeout(function() {
                                e.resume()
                            }, 100)
                        }
                        return this
                    })
                }, {
                    key: "setText",
                    value: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        return this.barDom && (this.barDom.querySelector(".noty_body").innerHTML = t), e && (this.options.text = t), this
                    }
                }, {
                    key: "setType",
                    value: function(t) {
                        var e = this,
                            n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        if (this.barDom) {
                            c.classList(this.barDom).split(" ").forEach(function(t) {
                                "noty_type__" === t.substring(0, 11) && c.removeClass(e.barDom, t)
                            }), c.addClass(this.barDom, "noty_type__" + t)
                        }
                        return n && (this.options.type = t), this
                    }
                }, {
                    key: "setTheme",
                    value: function(t) {
                        var e = this,
                            n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        if (this.barDom) {
                            c.classList(this.barDom).split(" ").forEach(function(t) {
                                "noty_theme__" === t.substring(0, 12) && c.removeClass(e.barDom, t)
                            }), c.addClass(this.barDom, "noty_theme__" + t)
                        }
                        return n && (this.options.theme = t), this
                    }
                }, {
                    key: "close",
                    value: function() {
                        var t = this;
                        return this.closed ? this : this.shown ? (d.fire(this, "onClose"), this.closing = !0, null === this.options.animation.close ? this.promises.close = new u.default(function(t) {
                            t()
                        }) : "function" == typeof this.options.animation.close ? this.promises.close = new u.default(this.options.animation.close.bind(this)) : (c.addClass(this.barDom, this.options.animation.close), this.promises.close = new u.default(function(e) {
                            c.addListener(t.barDom, c.animationEndEvents, function() {
                                t.options.force ? c.remove(t.barDom) : d.ghostFix(t), e()
                            })
                        })), this.promises.close.then(function() {
                            d.closeFlow(t), d.handleModalClose(t)
                        }), this.closed = !0, this) : (d.removeFromQueue(this), this)
                    }
                }], [{
                    key: "closeAll",
                    value: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        return Object.keys(d.Store).forEach(function(e) {
                            t ? d.Store[e].options.queue === t && d.Store[e].killable && d.Store[e].close() : d.Store[e].killable && d.Store[e].close()
                        }), this
                    }
                }, {
                    key: "overrideDefaults",
                    value: function(t) {
                        return d.Defaults = c.deepExtend({}, d.Defaults, t), this
                    }
                }, {
                    key: "setMaxVisible",
                    value: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : d.DefaultMaxVisible,
                            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "global";
                        return d.Queues.hasOwnProperty(e) || (d.Queues[e] = {
                            maxVisible: t,
                            queue: []
                        }), d.Queues[e].maxVisible = t, this
                    }
                }, {
                    key: "button",
                    value: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                            n = arguments[2],
                            o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                        return new f.NotyButton(t, e, n, o)
                    }
                }, {
                    key: "version",
                    value: function() {
                        return "3.1.4"
                    }
                }, {
                    key: "Push",
                    value: function(t) {
                        return new h.Push(t)
                    }
                }]), t
            }();
        e.default = p, c.visibilityChangeFlow(), t.exports = e.default
    }, function(t, e) {
        function n() {
            throw new Error("setTimeout has not been defined")
        }

        function o() {
            throw new Error("clearTimeout has not been defined")
        }

        function i(t) {
            if (l === setTimeout) return setTimeout(t, 0);
            if ((l === n || !l) && setTimeout) return l = setTimeout, setTimeout(t, 0);
            try {
                return l(t, 0)
            } catch (e) {
                try {
                    return l.call(null, t, 0)
                } catch (e) {
                    return l.call(this, t, 0)
                }
            }
        }

        function r(t) {
            if (d === clearTimeout) return clearTimeout(t);
            if ((d === o || !d) && clearTimeout) return d = clearTimeout, clearTimeout(t);
            try {
                return d(t)
            } catch (e) {
                try {
                    return d.call(null, t)
                } catch (e) {
                    return d.call(this, t)
                }
            }
        }

        function s() {
            m && h && (m = !1, h.length ? p = h.concat(p) : v = -1, p.length && u())
        }

        function u() {
            if (!m) {
                var t = i(s);
                m = !0;
                for (var e = p.length; e;) {
                    for (h = p, p = []; ++v < e;) h && h[v].run();
                    v = -1, e = p.length
                }
                h = null, m = !1, r(t)
            }
        }

        function a(t, e) {
            this.fun = t, this.array = e
        }

        function c() {}
        var l, d, f = t.exports = {};
        ! function() {
            try {
                l = "function" == typeof setTimeout ? setTimeout : n
            } catch (t) {
                l = n
            }
            try {
                d = "function" == typeof clearTimeout ? clearTimeout : o
            } catch (t) {
                d = o
            }
        }();
        var h, p = [],
            m = !1,
            v = -1;
        f.nextTick = function(t) {
            var e = new Array(arguments.length - 1);
            if (arguments.length > 1)
                for (var n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
            p.push(new a(t, e)), 1 !== p.length || m || i(u)
        }, a.prototype.run = function() {
            this.fun.apply(null, this.array)
        }, f.title = "browser", f.browser = !0, f.env = {}, f.argv = [], f.version = "", f.versions = {}, f.on = c, f.addListener = c, f.once = c, f.off = c, f.removeListener = c, f.removeAllListeners = c, f.emit = c, f.prependListener = c, f.prependOnceListener = c, f.listeners = function(t) {
            return []
        }, f.binding = function(t) {
            throw new Error("process.binding is not supported")
        }, f.cwd = function() {
            return "/"
        }, f.chdir = function(t) {
            throw new Error("process.chdir is not supported")
        }, f.umask = function() {
            return 0
        }
    }, function(t, e) {
        var n;
        n = function() {
            return this
        }();
        try {
            n = n || Function("return this")() || (0, eval)("this")
        } catch (t) {
            "object" == typeof window && (n = window)
        }
        t.exports = n
    }, function(t, e) {}])
});

/**
 * @yaireo/relative-time - javascript function to transform timestamp or date to local relative-time
 *
 * @version v1.0.3
 * @homepage https://github.com/yairEO/relative-time
 */

! function(e, t) {
    var o = o || {};
    "function" == typeof o && o.amd ? o([], t) : "object" == typeof exports && "object" == typeof module ? module.exports = t() : "object" == typeof exports ? exports.RelativeTime = t() : e.RelativeTime = t()
}(this, (function() {
    const e = {
            year: 31536e6,
            month: 2628e6,
            day: 864e5,
            hour: 36e5,
            minute: 6e4,
            second: 1e3
        },
        t = "en",
        o = {
            numeric: "auto"
        };

    function n(e) {
        e = {
            locale: (e = e || {}).locale || t,
            options: { ...o,
                ...e.options
            }
        }, this.rtf = new Intl.RelativeTimeFormat(e.locale, e.options)
    }
    return n.prototype = {
        from(t, o) {
            const n = t - (o || new Date);
            for (let t in e)
                if (Math.abs(n) > e[t] || "second" == t) return this.rtf.format(Math.round(n / e[t]), t)
        }
    }, n
}));

const relativeTime = new RelativeTime();


/*!
 * Glide.js v3.6.0
 * (c) 2013-2022 Jędrzej Chałubek (https://github.com/jedrzejchalubek/)
 * Released under the MIT License.
 */
! function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).Glide = e()
}(this, (function() {
    "use strict";

    function t(e) {
        return t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }, t(e)
    }

    function e(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function n(t, e) {
        for (var n = 0; n < e.length; n++) {
            var i = e[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
        }
    }

    function i(t, e, i) {
        return e && n(t.prototype, e), i && n(t, i), t
    }

    function r(t) {
        return r = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
            return t.__proto__ || Object.getPrototypeOf(t)
        }, r(t)
    }

    function o(t, e) {
        return o = Object.setPrototypeOf || function(t, e) {
            return t.__proto__ = e, t
        }, o(t, e)
    }

    function s(t, e) {
        if (e && ("object" == typeof e || "function" == typeof e)) return e;
        if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
        return function(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }(t)
    }

    function a(t) {
        var e = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
            } catch (t) {
                return !1
            }
        }();
        return function() {
            var n, i = r(t);
            if (e) {
                var o = r(this).constructor;
                n = Reflect.construct(i, arguments, o)
            } else n = i.apply(this, arguments);
            return s(this, n)
        }
    }

    function u(t, e) {
        for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = r(t)););
        return t
    }

    function c() {
        return c = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(t, e, n) {
            var i = u(t, e);
            if (i) {
                var r = Object.getOwnPropertyDescriptor(i, e);
                return r.get ? r.get.call(arguments.length < 3 ? t : n) : r.value
            }
        }, c.apply(this, arguments)
    }
    var l = {
        type: "slider",
        startAt: 0,
        perView: 1,
        focusAt: 0,
        gap: 10,
        autoplay: !1,
        hoverpause: !0,
        keyboard: !0,
        bound: !1,
        swipeThreshold: 80,
        dragThreshold: 120,
        perSwipe: "",
        touchRatio: .5,
        touchAngle: 45,
        animationDuration: 400,
        rewind: !0,
        rewindDuration: 800,
        animationTimingFunc: "cubic-bezier(.165, .840, .440, 1)",
        waitForTransition: !0,
        throttle: 10,
        direction: "ltr",
        peek: 0,
        cloningRatio: 1,
        breakpoints: {},
        classes: {
            swipeable: "glide--swipeable",
            dragging: "glide--dragging",
            direction: {
                ltr: "glide--ltr",
                rtl: "glide--rtl"
            },
            type: {
                slider: "glide--slider",
                carousel: "glide--carousel"
            },
            slide: {
                clone: "glide__slide--clone",
                active: "glide__slide--active"
            },
            arrow: {
                disabled: "glide__arrow--disabled"
            },
            nav: {
                active: "glide__bullet--active"
            }
        }
    };

    function f(t) {
        console.error("[Glide warn]: ".concat(t))
    }

    function d(t) {
        return parseInt(t)
    }

    function h(t) {
        return "string" == typeof t
    }

    function v(e) {
        var n = t(e);
        return "function" === n || "object" === n && !!e
    }

    function p(t) {
        return "function" == typeof t
    }

    function m(t) {
        return void 0 === t
    }

    function g(t) {
        return t.constructor === Array
    }

    function y(t, e, n) {
        var i = {};
        for (var r in e) p(e[r]) ? i[r] = e[r](t, i, n) : f("Extension must be a function");
        for (var o in i) p(i[o].mount) && i[o].mount();
        return i
    }

    function b(t, e, n) {
        Object.defineProperty(t, e, n)
    }

    function w(t, e) {
        var n = Object.assign({}, t, e);
        return e.hasOwnProperty("classes") && (n.classes = Object.assign({}, t.classes, e.classes), e.classes.hasOwnProperty("direction") && (n.classes.direction = Object.assign({}, t.classes.direction, e.classes.direction)), e.classes.hasOwnProperty("type") && (n.classes.type = Object.assign({}, t.classes.type, e.classes.type)), e.classes.hasOwnProperty("slide") && (n.classes.slide = Object.assign({}, t.classes.slide, e.classes.slide)), e.classes.hasOwnProperty("arrow") && (n.classes.arrow = Object.assign({}, t.classes.arrow, e.classes.arrow)), e.classes.hasOwnProperty("nav") && (n.classes.nav = Object.assign({}, t.classes.nav, e.classes.nav))), e.hasOwnProperty("breakpoints") && (n.breakpoints = Object.assign({}, t.breakpoints, e.breakpoints)), n
    }
    var _ = function() {
            function t() {
                var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                e(this, t), this.events = n, this.hop = n.hasOwnProperty
            }
            return i(t, [{
                key: "on",
                value: function(t, e) {
                    if (!g(t)) {
                        this.hop.call(this.events, t) || (this.events[t] = []);
                        var n = this.events[t].push(e) - 1;
                        return {
                            remove: function() {
                                delete this.events[t][n]
                            }
                        }
                    }
                    for (var i = 0; i < t.length; i++) this.on(t[i], e)
                }
            }, {
                key: "emit",
                value: function(t, e) {
                    if (g(t))
                        for (var n = 0; n < t.length; n++) this.emit(t[n], e);
                    else this.hop.call(this.events, t) && this.events[t].forEach((function(t) {
                        t(e || {})
                    }))
                }
            }]), t
        }(),
        k = function() {
            function t(n) {
                var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                e(this, t), this._c = {}, this._t = [], this._e = new _, this.disabled = !1, this.selector = n, this.settings = w(l, i), this.index = this.settings.startAt
            }
            return i(t, [{
                key: "mount",
                value: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return this._e.emit("mount.before"), v(t) ? this._c = y(this, t, this._e) : f("You need to provide a object on `mount()`"), this._e.emit("mount.after"), this
                }
            }, {
                key: "mutate",
                value: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                    return g(t) ? this._t = t : f("You need to provide a array on `mutate()`"), this
                }
            }, {
                key: "update",
                value: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return this.settings = w(this.settings, t), t.hasOwnProperty("startAt") && (this.index = t.startAt), this._e.emit("update"), this
                }
            }, {
                key: "go",
                value: function(t) {
                    return this._c.Run.make(t), this
                }
            }, {
                key: "move",
                value: function(t) {
                    return this._c.Transition.disable(), this._c.Move.make(t), this
                }
            }, {
                key: "destroy",
                value: function() {
                    return this._e.emit("destroy"), this
                }
            }, {
                key: "play",
                value: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    return t && (this.settings.autoplay = t), this._e.emit("play"), this
                }
            }, {
                key: "pause",
                value: function() {
                    return this._e.emit("pause"), this
                }
            }, {
                key: "disable",
                value: function() {
                    return this.disabled = !0, this
                }
            }, {
                key: "enable",
                value: function() {
                    return this.disabled = !1, this
                }
            }, {
                key: "on",
                value: function(t, e) {
                    return this._e.on(t, e), this
                }
            }, {
                key: "isType",
                value: function(t) {
                    return this.settings.type === t
                }
            }, {
                key: "settings",
                get: function() {
                    return this._o
                },
                set: function(t) {
                    v(t) ? this._o = t : f("Options must be an `object` instance.")
                }
            }, {
                key: "index",
                get: function() {
                    return this._i
                },
                set: function(t) {
                    this._i = d(t)
                }
            }, {
                key: "type",
                get: function() {
                    return this.settings.type
                }
            }, {
                key: "disabled",
                get: function() {
                    return this._d
                },
                set: function(t) {
                    this._d = !!t
                }
            }]), t
        }();

    function S() {
        return (new Date).getTime()
    }

    function H(t, e, n) {
        var i, r, o, s, a = 0;
        n || (n = {});
        var u = function() {
                a = !1 === n.leading ? 0 : S(), i = null, s = t.apply(r, o), i || (r = o = null)
            },
            c = function() {
                var c = S();
                a || !1 !== n.leading || (a = c);
                var l = e - (c - a);
                return r = this, o = arguments, l <= 0 || l > e ? (i && (clearTimeout(i), i = null), a = c, s = t.apply(r, o), i || (r = o = null)) : i || !1 === n.trailing || (i = setTimeout(u, l)), s
            };
        return c.cancel = function() {
            clearTimeout(i), a = 0, i = r = o = null
        }, c
    }
    var O = {
        ltr: ["marginLeft", "marginRight"],
        rtl: ["marginRight", "marginLeft"]
    };

    function T(t) {
        if (t && t.parentNode) {
            for (var e = t.parentNode.firstChild, n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        }
        return []
    }

    function x(t) {
        return !!(t && t instanceof window.HTMLElement)
    }

    function A(t) {
        return Array.prototype.slice.call(t)
    }
    var j = '[data-glide-el="track"]';
    var R = function() {
        function t() {
            var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            e(this, t), this.listeners = n
        }
        return i(t, [{
            key: "on",
            value: function(t, e, n) {
                var i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                h(t) && (t = [t]);
                for (var r = 0; r < t.length; r++) this.listeners[t[r]] = n, e.addEventListener(t[r], this.listeners[t[r]], i)
            }
        }, {
            key: "off",
            value: function(t, e) {
                var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                h(t) && (t = [t]);
                for (var i = 0; i < t.length; i++) e.removeEventListener(t[i], this.listeners[t[i]], n)
            }
        }, {
            key: "destroy",
            value: function() {
                delete this.listeners
            }
        }]), t
    }();
    var P = ["ltr", "rtl"],
        C = {
            ">": "<",
            "<": ">",
            "=": "="
        };

    function L(t, e) {
        return {
            modify: function(t) {
                return e.Direction.is("rtl") ? -t : t
            }
        }
    }

    function M(t, e) {
        return {
            modify: function(t) {
                var n = Math.floor(t / e.Sizes.slideWidth);
                return t + e.Gaps.value * n
            }
        }
    }

    function z(t, e) {
        return {
            modify: function(t) {
                return t + e.Clones.grow / 2
            }
        }
    }

    function E(t, e) {
        return {
            modify: function(n) {
                if (t.settings.focusAt >= 0) {
                    var i = e.Peek.value;
                    return v(i) ? n - i.before : n - i
                }
                return n
            }
        }
    }

    function D(t, e) {
        return {
            modify: function(n) {
                var i = e.Gaps.value,
                    r = e.Sizes.width,
                    o = t.settings.focusAt,
                    s = e.Sizes.slideWidth;
                return "center" === o ? n - (r / 2 - s / 2) : n - s * o - i * o
            }
        }
    }
    var B = !1;
    try {
        var W = Object.defineProperty({}, "passive", {
            get: function() {
                B = !0
            }
        });
        window.addEventListener("testPassive", null, W), window.removeEventListener("testPassive", null, W)
    } catch (t) {}
    var q = B,
        I = ["touchstart", "mousedown"],
        V = ["touchmove", "mousemove"],
        G = ["touchend", "touchcancel", "mouseup", "mouseleave"],
        F = ["mousedown", "mousemove", "mouseup", "mouseleave"];
    var N = '[data-glide-el^="controls"]',
        Y = "".concat(N, ' [data-glide-dir*="<"]'),
        X = "".concat(N, ' [data-glide-dir*=">"]');

    function K(t) {
        return v(t) ? (e = t, Object.keys(e).sort().reduce((function(t, n) {
            return t[n] = e[n], t[n], t
        }), {})) : (f("Breakpoints option must be an object"), {});
        var e
    }
    var J = {
            Html: function(t, e, n) {
                var i = {
                    mount: function() {
                        this.root = t.selector, this.track = this.root.querySelector(j), this.collectSlides()
                    },
                    collectSlides: function() {
                        this.slides = A(this.wrapper.children).filter((function(e) {
                            return !e.classList.contains(t.settings.classes.slide.clone)
                        }))
                    }
                };
                return b(i, "root", {
                    get: function() {
                        return i._r
                    },
                    set: function(t) {
                        h(t) && (t = document.querySelector(t)), x(t) ? i._r = t : f("Root element must be a existing Html node")
                    }
                }), b(i, "track", {
                    get: function() {
                        return i._t
                    },
                    set: function(t) {
                        x(t) ? i._t = t : f("Could not find track element. Please use ".concat(j, " attribute."))
                    }
                }), b(i, "wrapper", {
                    get: function() {
                        return i.track.children[0]
                    }
                }), n.on("update", (function() {
                    i.collectSlides()
                })), i
            },
            Translate: function(t, e, n) {
                var i = {
                    set: function(n) {
                        var i = function(t, e, n) {
                                var i = [M, z, E, D].concat(t._t, [L]);
                                return {
                                    mutate: function(r) {
                                        for (var o = 0; o < i.length; o++) {
                                            var s = i[o];
                                            p(s) && p(s().modify) ? r = s(t, e, n).modify(r) : f("Transformer should be a function that returns an object with `modify()` method")
                                        }
                                        return r
                                    }
                                }
                            }(t, e).mutate(n),
                            r = "translate3d(".concat(-1 * i, "px, 0px, 0px)");
                        e.Html.wrapper.style.mozTransform = r, e.Html.wrapper.style.webkitTransform = r, e.Html.wrapper.style.transform = r
                    },
                    remove: function() {
                        e.Html.wrapper.style.transform = ""
                    },
                    getStartIndex: function() {
                        var n = e.Sizes.length,
                            i = t.index,
                            r = t.settings.perView;
                        return e.Run.isOffset(">") || e.Run.isOffset("|>") ? n + (i - r) : (i + r) % n
                    },
                    getTravelDistance: function() {
                        var n = e.Sizes.slideWidth * t.settings.perView;
                        return e.Run.isOffset(">") || e.Run.isOffset("|>") ? -1 * n : n
                    }
                };
                return n.on("move", (function(r) {
                    if (!t.isType("carousel") || !e.Run.isOffset()) return i.set(r.movement);
                    e.Transition.after((function() {
                        n.emit("translate.jump"), i.set(e.Sizes.slideWidth * t.index)
                    }));
                    var o = e.Sizes.slideWidth * e.Translate.getStartIndex();
                    return i.set(o - e.Translate.getTravelDistance())
                })), n.on("destroy", (function() {
                    i.remove()
                })), i
            },
            Transition: function(t, e, n) {
                var i = !1,
                    r = {
                        compose: function(e) {
                            var n = t.settings;
                            return i ? "".concat(e, " 0ms ").concat(n.animationTimingFunc) : "".concat(e, " ").concat(this.duration, "ms ").concat(n.animationTimingFunc)
                        },
                        set: function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "transform";
                            e.Html.wrapper.style.transition = this.compose(t)
                        },
                        remove: function() {
                            e.Html.wrapper.style.transition = ""
                        },
                        after: function(t) {
                            setTimeout((function() {
                                t()
                            }), this.duration)
                        },
                        enable: function() {
                            i = !1, this.set()
                        },
                        disable: function() {
                            i = !0, this.set()
                        }
                    };
                return b(r, "duration", {
                    get: function() {
                        var n = t.settings;
                        return t.isType("slider") && e.Run.offset ? n.rewindDuration : n.animationDuration
                    }
                }), n.on("move", (function() {
                    r.set()
                })), n.on(["build.before", "resize", "translate.jump"], (function() {
                    r.disable()
                })), n.on("run", (function() {
                    r.enable()
                })), n.on("destroy", (function() {
                    r.remove()
                })), r
            },
            Direction: function(t, e, n) {
                var i = {
                    mount: function() {
                        this.value = t.settings.direction
                    },
                    resolve: function(t) {
                        var e = t.slice(0, 1);
                        return this.is("rtl") ? t.split(e).join(C[e]) : t
                    },
                    is: function(t) {
                        return this.value === t
                    },
                    addClass: function() {
                        e.Html.root.classList.add(t.settings.classes.direction[this.value])
                    },
                    removeClass: function() {
                        e.Html.root.classList.remove(t.settings.classes.direction[this.value])
                    }
                };
                return b(i, "value", {
                    get: function() {
                        return i._v
                    },
                    set: function(t) {
                        P.indexOf(t) > -1 ? i._v = t : f("Direction value must be `ltr` or `rtl`")
                    }
                }), n.on(["destroy", "update"], (function() {
                    i.removeClass()
                })), n.on("update", (function() {
                    i.mount()
                })), n.on(["build.before", "update"], (function() {
                    i.addClass()
                })), i
            },
            Peek: function(t, e, n) {
                var i = {
                    mount: function() {
                        this.value = t.settings.peek
                    }
                };
                return b(i, "value", {
                    get: function() {
                        return i._v
                    },
                    set: function(t) {
                        v(t) ? (t.before = d(t.before), t.after = d(t.after)) : t = d(t), i._v = t
                    }
                }), b(i, "reductor", {
                    get: function() {
                        var e = i.value,
                            n = t.settings.perView;
                        return v(e) ? e.before / n + e.after / n : 2 * e / n
                    }
                }), n.on(["resize", "update"], (function() {
                    i.mount()
                })), i
            },
            Sizes: function(t, e, n) {
                var i = {
                    setupSlides: function() {
                        for (var t = "".concat(this.slideWidth, "px"), n = e.Html.slides, i = 0; i < n.length; i++) n[i].style.width = t
                    },
                    setupWrapper: function() {
                        e.Html.wrapper.style.width = "".concat(this.wrapperSize, "px")
                    },
                    remove: function() {
                        for (var t = e.Html.slides, n = 0; n < t.length; n++) t[n].style.width = "";
                        e.Html.wrapper.style.width = ""
                    }
                };
                return b(i, "length", {
                    get: function() {
                        return e.Html.slides.length
                    }
                }), b(i, "width", {
                    get: function() {
                        return e.Html.track.offsetWidth
                    }
                }), b(i, "wrapperSize", {
                    get: function() {
                        return i.slideWidth * i.length + e.Gaps.grow + e.Clones.grow
                    }
                }), b(i, "slideWidth", {
                    get: function() {
                        return i.width / t.settings.perView - e.Peek.reductor - e.Gaps.reductor
                    }
                }), n.on(["build.before", "resize", "update"], (function() {
                    i.setupSlides(), i.setupWrapper()
                })), n.on("destroy", (function() {
                    i.remove()
                })), i
            },
            Gaps: function(t, e, n) {
                var i = {
                    apply: function(t) {
                        for (var n = 0, i = t.length; n < i; n++) {
                            var r = t[n].style,
                                o = e.Direction.value;
                            r[O[o][0]] = 0 !== n ? "".concat(this.value / 2, "px") : "", n !== t.length - 1 ? r[O[o][1]] = "".concat(this.value / 2, "px") : r[O[o][1]] = ""
                        }
                    },
                    remove: function(t) {
                        for (var e = 0, n = t.length; e < n; e++) {
                            var i = t[e].style;
                            i.marginLeft = "", i.marginRight = ""
                        }
                    }
                };
                return b(i, "value", {
                    get: function() {
                        return d(t.settings.gap)
                    }
                }), b(i, "grow", {
                    get: function() {
                        return i.value * e.Sizes.length
                    }
                }), b(i, "reductor", {
                    get: function() {
                        var e = t.settings.perView;
                        return i.value * (e - 1) / e
                    }
                }), n.on(["build.after", "update"], H((function() {
                    i.apply(e.Html.wrapper.children)
                }), 30)), n.on("destroy", (function() {
                    i.remove(e.Html.wrapper.children)
                })), i
            },
            Move: function(t, e, n) {
                var i = {
                    mount: function() {
                        this._o = 0
                    },
                    make: function() {
                        var t = this,
                            i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                        this.offset = i, n.emit("move", {
                            movement: this.value
                        }), e.Transition.after((function() {
                            n.emit("move.after", {
                                movement: t.value
                            })
                        }))
                    }
                };
                return b(i, "offset", {
                    get: function() {
                        return i._o
                    },
                    set: function(t) {
                        i._o = m(t) ? 0 : d(t)
                    }
                }), b(i, "translate", {
                    get: function() {
                        return e.Sizes.slideWidth * t.index
                    }
                }), b(i, "value", {
                    get: function() {
                        var t = this.offset,
                            n = this.translate;
                        return e.Direction.is("rtl") ? n + t : n - t
                    }
                }), n.on(["build.before", "run"], (function() {
                    i.make()
                })), i
            },
            Clones: function(t, e, n) {
                var i = {
                    mount: function() {
                        this.items = [], t.isType("carousel") && (this.items = this.collect())
                    },
                    collect: function() {
                        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                            i = e.Html.slides,
                            r = t.settings,
                            o = r.perView,
                            s = r.classes,
                            a = r.cloningRatio;
                        if (0 !== i.length)
                            for (var u = +!!t.settings.peek, c = o + u + Math.round(o / 2), l = i.slice(0, c).reverse(), f = i.slice(-1 * c), d = 0; d < Math.max(a, Math.floor(o / i.length)); d++) {
                                for (var h = 0; h < l.length; h++) {
                                    var v = l[h].cloneNode(!0);
                                    v.classList.add(s.slide.clone), n.push(v)
                                }
                                for (var p = 0; p < f.length; p++) {
                                    var m = f[p].cloneNode(!0);
                                    m.classList.add(s.slide.clone), n.unshift(m)
                                }
                            }
                        return n
                    },
                    append: function() {
                        for (var t = this.items, n = e.Html, i = n.wrapper, r = n.slides, o = Math.floor(t.length / 2), s = t.slice(0, o).reverse(), a = t.slice(-1 * o).reverse(), u = "".concat(e.Sizes.slideWidth, "px"), c = 0; c < a.length; c++) i.appendChild(a[c]);
                        for (var l = 0; l < s.length; l++) i.insertBefore(s[l], r[0]);
                        for (var f = 0; f < t.length; f++) t[f].style.width = u
                    },
                    remove: function() {
                        for (var t = this.items, n = 0; n < t.length; n++) e.Html.wrapper.removeChild(t[n])
                    }
                };
                return b(i, "grow", {
                    get: function() {
                        return (e.Sizes.slideWidth + e.Gaps.value) * i.items.length
                    }
                }), n.on("update", (function() {
                    i.remove(), i.mount(), i.append()
                })), n.on("build.before", (function() {
                    t.isType("carousel") && i.append()
                })), n.on("destroy", (function() {
                    i.remove()
                })), i
            },
            Resize: function(t, e, n) {
                var i = new R,
                    r = {
                        mount: function() {
                            this.bind()
                        },
                        bind: function() {
                            i.on("resize", window, H((function() {
                                n.emit("resize")
                            }), t.settings.throttle))
                        },
                        unbind: function() {
                            i.off("resize", window)
                        }
                    };
                return n.on("destroy", (function() {
                    r.unbind(), i.destroy()
                })), r
            },
            Build: function(t, e, n) {
                var i = {
                    mount: function() {
                        n.emit("build.before"), this.typeClass(), this.activeClass(), n.emit("build.after")
                    },
                    typeClass: function() {
                        e.Html.root.classList.add(t.settings.classes.type[t.settings.type])
                    },
                    activeClass: function() {
                        var n = t.settings.classes,
                            i = e.Html.slides[t.index];
                        i && (i.classList.add(n.slide.active), T(i).forEach((function(t) {
                            t.classList.remove(n.slide.active)
                        })))
                    },
                    removeClasses: function() {
                        var n = t.settings.classes,
                            i = n.type,
                            r = n.slide;
                        e.Html.root.classList.remove(i[t.settings.type]), e.Html.slides.forEach((function(t) {
                            t.classList.remove(r.active)
                        }))
                    }
                };
                return n.on(["destroy", "update"], (function() {
                    i.removeClasses()
                })), n.on(["resize", "update"], (function() {
                    i.mount()
                })), n.on("move.after", (function() {
                    i.activeClass()
                })), i
            },
            Run: function(t, e, n) {
                var i = {
                    mount: function() {
                        this._o = !1
                    },
                    make: function(i) {
                        var r = this;
                        t.disabled || (!t.settings.waitForTransition || t.disable(), this.move = i, n.emit("run.before", this.move), this.calculate(), n.emit("run", this.move), e.Transition.after((function() {
                            r.isStart() && n.emit("run.start", r.move), r.isEnd() && n.emit("run.end", r.move), r.isOffset() && (r._o = !1, n.emit("run.offset", r.move)), n.emit("run.after", r.move), t.enable()
                        })))
                    },
                    calculate: function() {
                        var e = this.move,
                            n = this.length,
                            r = e.steps,
                            o = e.direction,
                            s = 1;
                        if ("=" === o) return t.settings.bound && d(r) > n ? void(t.index = n) : void(t.index = r);
                        if (">" !== o || ">" !== r)
                            if ("<" !== o || "<" !== r) {
                                if ("|" === o && (s = t.settings.perView || 1), ">" === o || "|" === o && ">" === r) {
                                    var a = function(e) {
                                        var n = t.index;
                                        if (t.isType("carousel")) return n + e;
                                        return n + (e - n % e)
                                    }(s);
                                    return a > n && (this._o = !0), void(t.index = function(e, n) {
                                        var r = i.length;
                                        if (e <= r) return e;
                                        if (t.isType("carousel")) return e - (r + 1);
                                        if (t.settings.rewind) return i.isBound() && !i.isEnd() ? r : 0;
                                        if (i.isBound()) return r;
                                        return Math.floor(r / n) * n
                                    }(a, s))
                                }
                                if ("<" === o || "|" === o && "<" === r) {
                                    var u = function(e) {
                                        var n = t.index;
                                        if (t.isType("carousel")) return n - e;
                                        return (Math.ceil(n / e) - 1) * e
                                    }(s);
                                    return u < 0 && (this._o = !0), void(t.index = function(e, n) {
                                        var r = i.length;
                                        if (e >= 0) return e;
                                        if (t.isType("carousel")) return e + (r + 1);
                                        if (t.settings.rewind) return i.isBound() && i.isStart() ? r : Math.floor(r / n) * n;
                                        return 0
                                    }(u, s))
                                }
                                f("Invalid direction pattern [".concat(o).concat(r, "] has been used"))
                            } else t.index = 0;
                        else t.index = n
                    },
                    isStart: function() {
                        return t.index <= 0
                    },
                    isEnd: function() {
                        return t.index >= this.length
                    },
                    isOffset: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0;
                        return t ? !!this._o && ("|>" === t ? "|" === this.move.direction && ">" === this.move.steps : "|<" === t ? "|" === this.move.direction && "<" === this.move.steps : this.move.direction === t) : this._o
                    },
                    isBound: function() {
                        return t.isType("slider") && "center" !== t.settings.focusAt && t.settings.bound
                    }
                };
                return b(i, "move", {
                    get: function() {
                        return this._m
                    },
                    set: function(t) {
                        var e = t.substr(1);
                        this._m = {
                            direction: t.substr(0, 1),
                            steps: e ? d(e) ? d(e) : e : 0
                        }
                    }
                }), b(i, "length", {
                    get: function() {
                        var n = t.settings,
                            i = e.Html.slides.length;
                        return this.isBound() ? i - 1 - (d(n.perView) - 1) + d(n.focusAt) : i - 1
                    }
                }), b(i, "offset", {
                    get: function() {
                        return this._o
                    }
                }), i
            },
            Swipe: function(t, e, n) {
                var i = new R,
                    r = 0,
                    o = 0,
                    s = 0,
                    a = !1,
                    u = !!q && {
                        passive: !0
                    },
                    c = {
                        mount: function() {
                            this.bindSwipeStart()
                        },
                        start: function(e) {
                            if (!a && !t.disabled) {
                                this.disable();
                                var i = this.touches(e);
                                r = null, o = d(i.pageX), s = d(i.pageY), this.bindSwipeMove(), this.bindSwipeEnd(), n.emit("swipe.start")
                            }
                        },
                        move: function(i) {
                            if (!t.disabled) {
                                var a = t.settings,
                                    u = a.touchAngle,
                                    c = a.touchRatio,
                                    l = a.classes,
                                    f = this.touches(i),
                                    h = d(f.pageX) - o,
                                    v = d(f.pageY) - s,
                                    p = Math.abs(h << 2),
                                    m = Math.abs(v << 2),
                                    g = Math.sqrt(p + m),
                                    y = Math.sqrt(m);
                                if (!(180 * (r = Math.asin(y / g)) / Math.PI < u)) return !1;
                                i.stopPropagation(), e.Move.make(h * parseFloat(c)), e.Html.root.classList.add(l.dragging), n.emit("swipe.move")
                            }
                        },
                        end: function(i) {
                            if (!t.disabled) {
                                var s = t.settings,
                                    a = s.perSwipe,
                                    u = s.touchAngle,
                                    c = s.classes,
                                    l = this.touches(i),
                                    f = this.threshold(i),
                                    d = l.pageX - o,
                                    h = 180 * r / Math.PI;
                                this.enable(), d > f && h < u ? e.Run.make(e.Direction.resolve("".concat(a, "<"))) : d < -f && h < u ? e.Run.make(e.Direction.resolve("".concat(a, ">"))) : e.Move.make(), e.Html.root.classList.remove(c.dragging), this.unbindSwipeMove(), this.unbindSwipeEnd(), n.emit("swipe.end")
                            }
                        },
                        bindSwipeStart: function() {
                            var n = this,
                                r = t.settings,
                                o = r.swipeThreshold,
                                s = r.dragThreshold;
                            o && i.on(I[0], e.Html.wrapper, (function(t) {
                                n.start(t)
                            }), u), s && i.on(I[1], e.Html.wrapper, (function(t) {
                                n.start(t)
                            }), u)
                        },
                        unbindSwipeStart: function() {
                            i.off(I[0], e.Html.wrapper, u), i.off(I[1], e.Html.wrapper, u)
                        },
                        bindSwipeMove: function() {
                            var n = this;
                            i.on(V, e.Html.wrapper, H((function(t) {
                                n.move(t)
                            }), t.settings.throttle), u)
                        },
                        unbindSwipeMove: function() {
                            i.off(V, e.Html.wrapper, u)
                        },
                        bindSwipeEnd: function() {
                            var t = this;
                            i.on(G, e.Html.wrapper, (function(e) {
                                t.end(e)
                            }))
                        },
                        unbindSwipeEnd: function() {
                            i.off(G, e.Html.wrapper)
                        },
                        touches: function(t) {
                            return F.indexOf(t.type) > -1 ? t : t.touches[0] || t.changedTouches[0]
                        },
                        threshold: function(e) {
                            var n = t.settings;
                            return F.indexOf(e.type) > -1 ? n.dragThreshold : n.swipeThreshold
                        },
                        enable: function() {
                            return a = !1, e.Transition.enable(), this
                        },
                        disable: function() {
                            return a = !0, e.Transition.disable(), this
                        }
                    };
                return n.on("build.after", (function() {
                    e.Html.root.classList.add(t.settings.classes.swipeable)
                })), n.on("destroy", (function() {
                    c.unbindSwipeStart(), c.unbindSwipeMove(), c.unbindSwipeEnd(), i.destroy()
                })), c
            },
            Images: function(t, e, n) {
                var i = new R,
                    r = {
                        mount: function() {
                            this.bind()
                        },
                        bind: function() {
                            i.on("dragstart", e.Html.wrapper, this.dragstart)
                        },
                        unbind: function() {
                            i.off("dragstart", e.Html.wrapper)
                        },
                        dragstart: function(t) {
                            t.preventDefault()
                        }
                    };
                return n.on("destroy", (function() {
                    r.unbind(), i.destroy()
                })), r
            },
            Anchors: function(t, e, n) {
                var i = new R,
                    r = !1,
                    o = !1,
                    s = {
                        mount: function() {
                            this._a = e.Html.wrapper.querySelectorAll("a"), this.bind()
                        },
                        bind: function() {
                            i.on("click", e.Html.wrapper, this.click)
                        },
                        unbind: function() {
                            i.off("click", e.Html.wrapper)
                        },
                        click: function(t) {
                            o && (t.stopPropagation(), t.preventDefault())
                        },
                        detach: function() {
                            if (o = !0, !r) {
                                for (var t = 0; t < this.items.length; t++) this.items[t].draggable = !1;
                                r = !0
                            }
                            return this
                        },
                        attach: function() {
                            if (o = !1, r) {
                                for (var t = 0; t < this.items.length; t++) this.items[t].draggable = !0;
                                r = !1
                            }
                            return this
                        }
                    };
                return b(s, "items", {
                    get: function() {
                        return s._a
                    }
                }), n.on("swipe.move", (function() {
                    s.detach()
                })), n.on("swipe.end", (function() {
                    e.Transition.after((function() {
                        s.attach()
                    }))
                })), n.on("destroy", (function() {
                    s.attach(), s.unbind(), i.destroy()
                })), s
            },
            Controls: function(t, e, n) {
                var i = new R,
                    r = !!q && {
                        passive: !0
                    },
                    o = {
                        mount: function() {
                            this._n = e.Html.root.querySelectorAll('[data-glide-el="controls[nav]"]'), this._c = e.Html.root.querySelectorAll(N), this._arrowControls = {
                                previous: e.Html.root.querySelectorAll(Y),
                                next: e.Html.root.querySelectorAll(X)
                            }, this.addBindings()
                        },
                        setActive: function() {
                            for (var t = 0; t < this._n.length; t++) this.addClass(this._n[t].children)
                        },
                        removeActive: function() {
                            for (var t = 0; t < this._n.length; t++) this.removeClass(this._n[t].children)
                        },
                        addClass: function(e) {
                            var n = t.settings,
                                i = e[t.index];
                            i && i && (i.classList.add(n.classes.nav.active), T(i).forEach((function(t) {
                                t.classList.remove(n.classes.nav.active)
                            })))
                        },
                        removeClass: function(e) {
                            var n = e[t.index];
                            n && n.classList.remove(t.settings.classes.nav.active)
                        },
                        setArrowState: function() {
                            if (!t.settings.rewind) {
                                var n = o._arrowControls.next,
                                    i = o._arrowControls.previous;
                                this.resetArrowState(n, i), 0 === t.index && this.disableArrow(i), t.index === e.Run.length && this.disableArrow(n)
                            }
                        },
                        resetArrowState: function() {
                            for (var e = t.settings, n = arguments.length, i = new Array(n), r = 0; r < n; r++) i[r] = arguments[r];
                            i.forEach((function(t) {
                                A(t).forEach((function(t) {
                                    t.classList.remove(e.classes.arrow.disabled)
                                }))
                            }))
                        },
                        disableArrow: function() {
                            for (var e = t.settings, n = arguments.length, i = new Array(n), r = 0; r < n; r++) i[r] = arguments[r];
                            i.forEach((function(t) {
                                A(t).forEach((function(t) {
                                    t.classList.add(e.classes.arrow.disabled)
                                }))
                            }))
                        },
                        addBindings: function() {
                            for (var t = 0; t < this._c.length; t++) this.bind(this._c[t].children)
                        },
                        removeBindings: function() {
                            for (var t = 0; t < this._c.length; t++) this.unbind(this._c[t].children)
                        },
                        bind: function(t) {
                            for (var e = 0; e < t.length; e++) i.on("click", t[e], this.click), i.on("touchstart", t[e], this.click, r)
                        },
                        unbind: function(t) {
                            for (var e = 0; e < t.length; e++) i.off(["click", "touchstart"], t[e])
                        },
                        click: function(t) {
                            q || "touchstart" !== t.type || t.preventDefault();
                            var n = t.currentTarget.getAttribute("data-glide-dir");
                            e.Run.make(e.Direction.resolve(n))
                        }
                    };
                return b(o, "items", {
                    get: function() {
                        return o._c
                    }
                }), n.on(["mount.after", "move.after"], (function() {
                    o.setActive()
                })), n.on(["mount.after", "run"], (function() {
                    o.setArrowState()
                })), n.on("destroy", (function() {
                    o.removeBindings(), o.removeActive(), i.destroy()
                })), o
            },
            Keyboard: function(t, e, n) {
                var i = new R,
                    r = {
                        mount: function() {
                            t.settings.keyboard && this.bind()
                        },
                        bind: function() {
                            i.on("keyup", document, this.press)
                        },
                        unbind: function() {
                            i.off("keyup", document)
                        },
                        press: function(n) {
                            var i = t.settings.perSwipe;
                            "ArrowRight" === n.code && e.Run.make(e.Direction.resolve("".concat(i, ">"))), "ArrowLeft" === n.code && e.Run.make(e.Direction.resolve("".concat(i, "<")))
                        }
                    };
                return n.on(["destroy", "update"], (function() {
                    r.unbind()
                })), n.on("update", (function() {
                    r.mount()
                })), n.on("destroy", (function() {
                    i.destroy()
                })), r
            },
            Autoplay: function(t, e, n) {
                var i = new R,
                    r = {
                        mount: function() {
                            this.enable(), this.start(), t.settings.hoverpause && this.bind()
                        },
                        enable: function() {
                            this._e = !0
                        },
                        disable: function() {
                            this._e = !1
                        },
                        start: function() {
                            var i = this;
                            this._e && (this.enable(), t.settings.autoplay && m(this._i) && (this._i = setInterval((function() {
                                i.stop(), e.Run.make(">"), i.start(), n.emit("autoplay")
                            }), this.time)))
                        },
                        stop: function() {
                            this._i = clearInterval(this._i)
                        },
                        bind: function() {
                            var t = this;
                            i.on("mouseover", e.Html.root, (function() {
                                t._e && t.stop()
                            })), i.on("mouseout", e.Html.root, (function() {
                                t._e && t.start()
                            }))
                        },
                        unbind: function() {
                            i.off(["mouseover", "mouseout"], e.Html.root)
                        }
                    };
                return b(r, "time", {
                    get: function() {
                        var n = e.Html.slides[t.index].getAttribute("data-glide-autoplay");
                        return d(n || t.settings.autoplay)
                    }
                }), n.on(["destroy", "update"], (function() {
                    r.unbind()
                })), n.on(["run.before", "swipe.start", "update"], (function() {
                    r.stop()
                })), n.on(["pause", "destroy"], (function() {
                    r.disable(), r.stop()
                })), n.on(["run.after", "swipe.end"], (function() {
                    r.start()
                })), n.on(["play"], (function() {
                    r.enable(), r.start()
                })), n.on("update", (function() {
                    r.mount()
                })), n.on("destroy", (function() {
                    i.destroy()
                })), r
            },
            Breakpoints: function(t, e, n) {
                var i = new R,
                    r = t.settings,
                    o = K(r.breakpoints),
                    s = Object.assign({}, r),
                    a = {
                        match: function(t) {
                            if (void 0 !== window.matchMedia)
                                for (var e in t)
                                    if (t.hasOwnProperty(e) && window.matchMedia("(max-width: ".concat(e, "px)")).matches) return t[e];
                            return s
                        }
                    };
                return Object.assign(r, a.match(o)), i.on("resize", window, H((function() {
                    t.settings = w(r, a.match(o))
                }), t.settings.throttle)), n.on("update", (function() {
                    o = K(o), s = Object.assign({}, r)
                })), n.on("destroy", (function() {
                    i.off("resize", window)
                })), a
            }
        },
        Q = function(t) {
            ! function(t, e) {
                if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), e && o(t, e)
            }(s, t);
            var n = a(s);

            function s() {
                return e(this, s), n.apply(this, arguments)
            }
            return i(s, [{
                key: "mount",
                value: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return c(r(s.prototype), "mount", this).call(this, Object.assign({}, J, t))
                }
            }]), s
        }(k);
    return Q
}));
var cssId = 'MeggnoApps_Google_Reviews_Custom_Badge'; // you could encode the css path itself to generate id..
if (!document.getElementById(cssId)) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.id = cssId;
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = 'https://meggnotec.ams3.digitaloceanspaces.com/noty/vendor/needim/noty/lib/noty-v9.css?1705771216';
    //    link.href = 'https://gtsbc.meggnoapps.com/sfy/noty/vendor/needim/noty/lib/noty.css';
    link.media = 'all';
    head.appendChild(link);
}
var show_for = 1;
var close_clicked = 0;
if (sessionStorage.getItem('close_clicked')) {
    close_clicked = 1;
}
if (sessionStorage.getItem('show_for')) {
    show_for = sessionStorage.getItem('show_for');
}
var close_type = 1;
var custom = new Noty({
    text: '<div class="meggnotec-seller-rating custom">' +
        '<div class="g-icon">' +
        '<a href="https://www.google.com/shopping/customerreviews/merchantreviews?q=saltyscales.com" target="_blank" style="text-decoration:none;" title="GCR" rel="noreferrer">' +
        '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><path fill="#2A84FC" d="M21.579 12.234c0-.677-.055-1.358-.172-2.025h-9.403v3.839h5.384a4.615 4.615 0 01-1.992 3.029v2.49h3.212c1.886-1.736 2.97-4.3 2.97-7.333z"></path><path fill="#00AC47" d="M12.004 21.974c2.688 0 4.956-.882 6.608-2.406l-3.213-2.491c-.893.608-2.047.952-3.392.952-2.6 0-4.806-1.754-5.597-4.113H3.095v2.567a9.97 9.97 0 008.909 5.491z"></path><path fill="#FFBA00" d="M6.407 13.916a5.971 5.971 0 010-3.817V7.53H3.095a9.977 9.977 0 000 8.952l3.312-2.567z"></path><path fill="#FC2C25" d="M12.004 5.982a5.417 5.417 0 013.824 1.494l2.846-2.846a9.581 9.581 0 00-6.67-2.593A9.967 9.967 0 003.095 7.53l3.312 2.57c.787-2.363 2.996-4.117 5.597-4.117z"></path></svg>' +
        '</a>' +
        '</div>' +
        '<div class="googlecustomerreviews_containerdiv">' +
        '<a href="https://www.google.com/shopping/customerreviews/merchantreviews?q=saltyscales.com" target="_blank" style="text-decoration:none;" rel="noreferrer">' +
        '<span class="meggnotec-stars-container" style="--stars-width: 100%; --color-bright: gold;">★★★★★</span>' +
        '</a>' +
        '</div>' +
        '<div class="reviews">' +
        '<a href="https://www.google.com/shopping/customerreviews/merchantreviews?q=saltyscales.com" target="_blank" style="text-decoration:none;" rel="noreferrer">&nbsp;' +
        '<span>Google Customer Reviews</span>' +
        '</a>' +
        '</div>' +
        '</div>',
    layout: 'bottomRight',
    theme: 'semanticui',
    type: 'alert',
    closeWith: ['button'],
    callbacks: {
        onClose: function() {
            sessionStorage.setItem('close_clicked', true);
            if (close_type === 2) {
                sessionStorage.setItem('googleBadgeShownCount', 2);
                sessionStorage.setItem('show_for', 5);
            };
            if (close_type === 3) {
                sessionStorage.setItem('googleBadgeShownCount', 99999999);
            };
        }
    }
});

if (!sessionStorage.getItem('googleBadgeShownCount') && close_clicked === 0) {
    sessionStorage.setItem('googleBadgeShownCount', 1);
}
if (parseInt(sessionStorage.getItem('googleBadgeShownCount')) === 1) {
    setTimeout(function() {
        custom.show();
    }, 0 * 1000);
}
if (close_clicked === 1 && close_type === 2) sessionStorage.setItem('googleBadgeShownCount', parseInt(sessionStorage.getItem('googleBadgeShownCount')) + 1);
if (parseInt(sessionStorage.getItem('googleBadgeShownCount')) > show_for && close_clicked === 1 && close_type === 2) sessionStorage.setItem('googleBadgeShownCount', 1);
/**
 * Wait for an element before resolving a promise
 * @param {String} querySelector - Selector of element to wait for
 * @param {Integer} timeout - Milliseconds to wait before timing out, or 0 for no timeout              
 */
function waitForElement(querySelector, timeout) {
    return new Promise((resolve, reject) => {
        var timer = false;
        if (document.querySelectorAll(querySelector).length) return resolve();
        const observer = new MutationObserver(() => {
            if (document.querySelectorAll(querySelector).length) {
                observer.disconnect();
                if (timer !== false) clearTimeout(timer);
                return resolve();
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        if (timeout) timer = setTimeout(() => {
            observer.disconnect();
            reject();
        }, timeout);
    });
}