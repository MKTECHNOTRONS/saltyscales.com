! function(t, e) {
    "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? exports.AfterpayAttractWidget = e() : t.AfterpayAttractWidget = e()
}(window, (function() {
    return function(t) {
        var e = {};

        function r(n) {
            if (e[n]) return e[n].exports;
            var o = e[n] = {
                i: n,
                l: !1,
                exports: {}
            };
            return t[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports
        }
        return r.m = t, r.c = e, r.d = function(t, e, n) {
            r.o(t, e) || Object.defineProperty(t, e, {
                enumerable: !0,
                get: n
            })
        }, r.r = function(t) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(t, "__esModule", {
                value: !0
            })
        }, r.t = function(t, e) {
            if (1 & e && (t = r(t)), 8 & e) return t;
            if (4 & e && "object" == typeof t && t && t.__esModule) return t;
            var n = Object.create(null);
            if (r.r(n), Object.defineProperty(n, "default", {
                    enumerable: !0,
                    value: t
                }), 2 & e && "string" != typeof t)
                for (var o in t) r.d(n, o, function(e) {
                    return t[e]
                }.bind(null, o));
            return n
        }, r.n = function(t) {
            var e = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return r.d(e, "a", e), e
        }, r.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }, r.p = "", r(r.s = 84)
    }([function(t, e, r) {
        "use strict";
        var n;
        r.d(e, "f", (function() {
                return n
            })), r.d(e, "j", (function() {
                return c
            })), r.d(e, "k", (function() {
                return u
            })), r.d(e, "b", (function() {
                return s
            })), r.d(e, "a", (function() {
                return f
            })), r.d(e, "d", (function() {
                return d
            })), r.d(e, "e", (function() {
                return l
            })), r.d(e, "h", (function() {
                return p
            })), r.d(e, "i", (function() {
                return y
            })), r.d(e, "g", (function() {
                return v
            })), r.d(e, "l", (function() {
                return O
            })), r.d(e, "c", (function() {
                return P
            })),
            function(t) {
                t.NO_RECORD = "NO_RECORD", t.IN_PROGRESS = "IN_PROGRESS", t.IN_REVIEW = "IN_REVIEW", t.REQUIRES_ATTENTION = "REQUIRES_ATTENTION", t.READY_TO_INSTALL = "READY_TO_INSTALL", t.COMPLETE = "COMPLETE", t.PRE_CONFIGURED = "PRE_CONFIGURED"
            }(n || (n = {}));
        var o, i, a, s, c = [n.COMPLETE, n.READY_TO_INSTALL, n.PRE_CONFIGURED],
            u = [n.IN_PROGRESS, n.IN_REVIEW, n.REQUIRES_ATTENTION];
        n.NO_RECORD;
        ! function(t) {
            t.LOGGED_IN = "LOGGED_IN", t.LOGGED_OUT = "LOGGED_OUT", t.ASK_EMAIL_ERROR = "ASK_EMAIL_ERROR", t.ASK_CODE = "ASK_CODE"
        }(o || (o = {})),
        function(t) {
            t.V1 = "SHOPIFY_APP_VERSION_V1", t.V2 = "SHOPIFY_APP_VERSION_V2", t.V3 = "SHOPIFY_APP_VERSION_V3"
        }(i || (i = {})),
        function(t) {
            t.APP_NOT_INSTALLED = "APP_NOT_INSTALLED", t.APP_INSTALLED = "APP_INSTALLED", t.INSTALLATION_STARTED = "INSTALLATION_STARTED", t.INSTALLATION_COMPLETE = "INSTALLATION_COMPLETE", t.UNINSTALLED = "UNINSTALLED"
        }(a || (a = {})),
        function(t) {
            t[t.MINIMUM_AMOUNT = 100] = "MINIMUM_AMOUNT", t[t.MAXIMUM_AMOUNT = 2e5] = "MAXIMUM_AMOUNT"
        }(s || (s = {}));
        var p, f = {
                min: s.MINIMUM_AMOUNT,
                max: s.MAXIMUM_AMOUNT
            },
            d = {
                min: 100,
                max: 8e4
            },
            l = {
                min: 100,
                max: 12e4
            };
        ! function(t) {
            t.PRODUCT = "product", t.STATIC_CART = "staticCart", t.MOBILE_PRODUCT = "mobileProduct", t.MOBILE_STATIC_CART = "mobileStaticCart"
        }(p || (p = {}));
        var h, y;
        ! function(t) {
            t.PUBLISHED = "PUBLISHED", t.DRAFT = "DRAFT", t.INITIAL = "INITIAL"
        }(h || (h = {})),
        function(t) {
            t.ACTIVE = "ACTIVE", t.DRAFT = "DRAFT", t.INITIAL = "INITIAL"
        }(y || (y = {}));
        var A, v = "https://afterpayus-integrations.s3.amazonaws.com/shopify-configs";
        ! function(t) {
            t.PREVIEW = "PREVIEW", t.CUSTOMIZE = "CUSTOMIZE", t.MANUAL_PLACEMENT = "MANUAL_PLACEMENT"
        }(A || (A = {}));
        var E, O = {
            GIFT_CARD_RE: /(giftcertificate|giftcard)/gim
        };
        ! function(t) {
            t.DEV_MODE = "devMode", t.DEFAULT = "default", t.OFF = ""
        }(E || (E = {}));
        var P = 0
    }, function(t, e, r) {
        t.exports = r(35)
    }, function(t, e, r) {
        "use strict";

        function n(t, e, r) {
            return e in t ? Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = r, t
        }
        r.d(e, "a", (function() {
            return n
        }))
    }, function(t, e, r) {
        "use strict";

        function n(t, e, r, n, o, i, a) {
            try {
                var s = t[i](a),
                    c = s.value
            } catch (t) {
                return void r(t)
            }
            s.done ? e(c) : Promise.resolve(c).then(n, o)
        }

        function o(t) {
            return function() {
                var e = this,
                    r = arguments;
                return new Promise((function(o, i) {
                    var a = t.apply(e, r);

                    function s(t) {
                        n(a, o, i, s, c, "next", t)
                    }

                    function c(t) {
                        n(a, o, i, s, c, "throw", t)
                    }
                    s(void 0)
                }))
            }
        }
        r.d(e, "a", (function() {
            return o
        }))
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.ComponentType = e.Group = void 0,
            function(t) {
                t.AuthCode = "AuthCode", t.Button = "Button", t.ButtonGroup = "ButtonGroup", t.Cart = "Cart", t.Client = "Client", t.ContextualSaveBar = "ContextualSaveBar", t.Error = "Error", t.Features = "Features", t.FeedbackModal = "FeedbackModal", t.Fullscreen = "Fullscreen", t.LeaveConfirmation = "LeaveConfirmation", t.Link = "Link", t.Loading = "Loading", t.Menu = "Menu", t.Modal = "Modal", t.Navigation = "Navigation", t.Performance = "Performance", t.Pos = "Pos", t.Print = "Print", t.ResourcePicker = "Resource_Picker", t.Scanner = "Scanner", t.SessionToken = "SessionToken", t.Share = "Share", t.TitleBar = "TitleBar", t.Toast = "Toast", t.MarketingExternalActivityTopBar = "MarketingExternalActivityTopBar"
            }(e.Group || (e.Group = {})),
            function(t) {
                t.Button = "Button", t.ButtonGroup = "ButtonGroup"
            }(e.ComponentType || (e.ComponentType = {}))
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            },
            a = this && this.__spreadArrays || function() {
                for (var t = 0, e = 0, r = arguments.length; e < r; e++) t += arguments[e].length;
                var n = Array(t),
                    o = 0;
                for (e = 0; e < r; e++)
                    for (var i = arguments[e], a = 0, s = i.length; a < s; a++, o++) n[o] = i[a];
                return n
            },
            s = this && this.__importDefault || function(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.NonSnakeCaseGroup = e.findMatchInEnum = e.forEachInEnum = e.getMergedProps = e.updateActionFromPayload = e.ActionSetWithChildren = e.ActionSet = e.isValidOptionalString = e.isValidOptionalNumber = e.getEventNameSpace = e.getVersion = e.actionWrapper = void 0;
        var c = r(28),
            u = r(54),
            p = r(29),
            f = r(30),
            d = s(r(55)),
            l = r(4),
            h = s(r(56)),
            y = r(57);

        function A() {
            return y.version
        }

        function v(t, r, n) {
            if (r.startsWith("" + f.PREFIX + f.SEPARATOR)) return r;
            var o = function(t) {
                if (e.NonSnakeCaseGroup.includes(t)) return t.toUpperCase();
                return (r = t, r.replace(/([A-Z])/g, (function(t, e, r) {
                    return (0 !== r ? "_" : "") + t[0].toLowerCase()
                }))).toUpperCase();
                var r
            }(t);
            if (n) {
                var i = n.subgroups,
                    a = n.type;
                i && i.length > 0 && (o += o.length > 0 ? f.SEPARATOR : "", i.forEach((function(t, e) {
                    o += "" + t.toUpperCase() + (e < i.length - 1 ? f.SEPARATOR : "")
                }))), a !== t && a && (o += "" + (o.length > 0 ? f.SEPARATOR : "") + a.toUpperCase())
            }
            return o && (o += "" + (o.length > 0 ? f.SEPARATOR : "") + r.toUpperCase()), "" + f.PREFIX + f.SEPARATOR + o
        }
        e.actionWrapper = function(t) {
            return i(i({}, t), {
                version: A(),
                clientInterface: {
                    name: y.name,
                    version: A()
                }
            })
        }, e.getVersion = A, e.getEventNameSpace = v, e.isValidOptionalNumber = function(t) {
            return null == t || "number" == typeof t
        }, e.isValidOptionalString = function(t) {
            return null == t || "string" == typeof t
        };
        var E = function() {
            function t(t, e, r, n) {
                var o = this;
                this.app = t, this.type = e, this.group = r, this.subgroups = [], this.subscriptions = [], t || p.throwError(p.Action.INVALID_ACTION, "Missing required `app`"), this.id = n || h.default(), this.defaultGroup = r;
                var i = this.set;
                this.set = function() {
                    for (var t, e = [], r = 0; r < arguments.length; r++) e[r] = arguments[r];
                    return o.app.hooks ? (t = o.app.hooks).run.apply(t, a([c.LifecycleHook.UpdateAction, i, o], e)) : i.apply(o, e)
                }
            }
            return t.prototype.set = function() {
                for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e]
            }, Object.defineProperty(t.prototype, "component", {
                get: function() {
                    return {
                        id: this.id,
                        subgroups: this.subgroups,
                        type: this.type
                    }
                },
                enumerable: !1,
                configurable: !0
            }), t.prototype.updateSubscription = function(t, e, r) {
                var n, o = t.eventType,
                    i = t.callback,
                    a = t.component;
                return (n = this.subscriptions.findIndex((function(e) {
                    return e === t
                }))) >= 0 ? this.subscriptions[n].unsubscribe() : n = void 0, this.group = e, this.subgroups = r, Object.assign(a, {
                    subgroups: this.subgroups
                }), this.subscribe(o, i, a, n)
            }, t.prototype.error = function(t) {
                var e = this,
                    r = [];
                return b(p.Action, (function(n) {
                        r.push(e.subscriptions.length), e.subscribe(n, t)
                    })),
                    function() {
                        r.map((function(t) {
                            return e.subscriptions[t]
                        })).forEach((function(t) {
                            u.removeFromCollection(e.subscriptions, t, (function(t) {
                                t.unsubscribe()
                            }))
                        }))
                    }
            }, t.prototype.subscribe = function(t, e, r, n) {
                var o, a = this,
                    s = r || this.component,
                    c = t.toUpperCase(),
                    u = "number" == typeof n ? e : e.bind(this);
                o = p.isErrorEventName(t) ? v(l.Group.Error, t, i(i({}, s), {
                    type: ""
                })) : v(this.group, t, s);
                var f = this.app.subscribe(o, u, r ? r.id : this.id),
                    d = {
                        eventType: c,
                        unsubscribe: f,
                        callback: u,
                        component: s,
                        updateSubscribe: function(t, e) {
                            return a.updateSubscription.call(a, d, t, e)
                        }
                    };
                return "number" == typeof n && n >= 0 && n < this.subscriptions.length ? this.subscriptions[n] = d : this.subscriptions.push(d), f
            }, t.prototype.unsubscribe = function(t) {
                return void 0 === t && (t = !1), P(this.subscriptions, this.defaultGroup, t), this
            }, t
        }();
        e.ActionSet = E;
        var O = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.children = [], e
            }
            return o(e, t), e.prototype.unsubscribe = function(t, r) {
                return void 0 === t && (t = !0), void 0 === r && (r = !1), P(this.subscriptions, this.defaultGroup, r), this.children.forEach((function(r) {
                    e.prototype.isPrototypeOf(r) ? r.unsubscribe(t, !t) : r.unsubscribe(!t)
                })), this
            }, e.prototype.getChild = function(t) {
                var e = this.children.findIndex((function(e) {
                    return e.id === t
                }));
                return e >= 0 ? this.children[e] : void 0
            }, e.prototype.getChildIndex = function(t) {
                return this.children.findIndex((function(e) {
                    return e.id === t
                }))
            }, e.prototype.getChildSubscriptions = function(t, e) {
                return this.subscriptions.filter((function(r) {
                    return r.component.id === t && (!e || e === r.eventType)
                }))
            }, e.prototype.addChild = function(t, r, n) {
                var o = this,
                    i = t.subscriptions;
                return this.getChild(t.id) || this.children.push(t), !i || r === t.group && n === t.subgroups || (i.forEach((function(t) {
                    (0, t.updateSubscribe)(r, n)
                })), Object.assign(t, {
                    group: r,
                    subgroups: n
                }), e.prototype.isPrototypeOf(t) && t.children.forEach((function(t) {
                    return o.addChild(t, r, n)
                }))), this
            }, e.prototype.removeChild = function(t) {
                var e = this;
                return u.removeFromCollection(this.children, this.getChild(t), (function() {
                    e.subscriptions.filter((function(e) {
                        return e.component.id === t
                    })).forEach((function(t) {
                        u.removeFromCollection(e.subscriptions, t, (function(t) {
                            t.unsubscribe()
                        }))
                    }))
                })), this
            }, e.prototype.subscribeToChild = function(t, e, r) {
                var n = this,
                    o = r.bind(this);
                if (e instanceof Array) return e.forEach((function(e) {
                    return n.subscribeToChild(t, e, r)
                })), this;
                if ("string" != typeof e) return this;
                var i = e.toUpperCase(),
                    a = this.getChildSubscriptions(t.id, i);
                if (a.length > 0) a.forEach((function(e) {
                    return e.updateSubscribe(n.group, t.subgroups)
                }));
                else {
                    var s = {
                        id: t.id,
                        subgroups: t.subgroups,
                        type: t.type
                    };
                    this.subscribe(i, o, s)
                }
                return this
            }, e.prototype.getUpdatedChildActions = function(t, e) {
                if (0 !== t.length) {
                    for (var r = t.filter((function(t, e, r) {
                            return e === r.indexOf(t)
                        })), n = r.map((function(t) {
                            return t.id
                        })), o = e.filter((function(t) {
                            return n.indexOf(t.id) < 0
                        })); o.length > 0;) {
                        if (!(i = o.pop())) break;
                        this.removeChild(i.id)
                    }
                    return r
                }
                for (; e.length > 0;) {
                    var i;
                    if (!(i = e.pop())) break;
                    this.removeChild(i.id)
                }
            }, e
        }(E);

        function P(t, e, r) {
            void 0 === r && (r = !1), t.forEach((function(t) {
                r ? (0, t.updateSubscribe)(e, []) : (0, t.unsubscribe)()
            })), r || (t.length = 0)
        }

        function g(t, e) {
            var r = d.default(t, e);
            return r || Object.assign(t, e)
        }

        function b(t, e) {
            Object.keys(t).forEach((function(r) {
                e(t[r])
            }))
        }
        e.ActionSetWithChildren = O, e.updateActionFromPayload = function(t, e) {
            return t.id === e.id && (Object.assign(t, g(t, e)), !0)
        }, e.getMergedProps = g, e.forEachInEnum = b, e.findMatchInEnum = function(t, e) {
            var r = Object.keys(t).find((function(r) {
                return e === t[r]
            }));
            return r ? t[r] : void 0
        }, e.NonSnakeCaseGroup = [l.Group.AuthCode, l.Group.Button, l.Group.ButtonGroup, l.Group.Cart, l.Group.Error, l.Group.Features, l.Group.Fullscreen, l.Group.Link, l.Group.Loading, l.Group.Menu, l.Group.Modal, l.Group.Navigation, l.Group.Pos, l.Group.Print, l.Group.ResourcePicker, l.Group.Scanner, l.Group.SessionToken, l.Group.Share, l.Group.TitleBar, l.Group.Toast]
    }, function(t, e, r) {
        "use strict";
        var n = r(20),
            o = Object.prototype.toString;

        function i(t) {
            return "[object Array]" === o.call(t)
        }

        function a(t) {
            return void 0 === t
        }

        function s(t) {
            return null !== t && "object" == typeof t
        }

        function c(t) {
            if ("[object Object]" !== o.call(t)) return !1;
            var e = Object.getPrototypeOf(t);
            return null === e || e === Object.prototype
        }

        function u(t) {
            return "[object Function]" === o.call(t)
        }

        function p(t, e) {
            if (null != t)
                if ("object" != typeof t && (t = [t]), i(t))
                    for (var r = 0, n = t.length; r < n; r++) e.call(null, t[r], r, t);
                else
                    for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && e.call(null, t[o], o, t)
        }
        t.exports = {
            isArray: i,
            isArrayBuffer: function(t) {
                return "[object ArrayBuffer]" === o.call(t)
            },
            isBuffer: function(t) {
                return null !== t && !a(t) && null !== t.constructor && !a(t.constructor) && "function" == typeof t.constructor.isBuffer && t.constructor.isBuffer(t)
            },
            isFormData: function(t) {
                return "undefined" != typeof FormData && t instanceof FormData
            },
            isArrayBufferView: function(t) {
                return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(t) : t && t.buffer && t.buffer instanceof ArrayBuffer
            },
            isString: function(t) {
                return "string" == typeof t
            },
            isNumber: function(t) {
                return "number" == typeof t
            },
            isObject: s,
            isPlainObject: c,
            isUndefined: a,
            isDate: function(t) {
                return "[object Date]" === o.call(t)
            },
            isFile: function(t) {
                return "[object File]" === o.call(t)
            },
            isBlob: function(t) {
                return "[object Blob]" === o.call(t)
            },
            isFunction: u,
            isStream: function(t) {
                return s(t) && u(t.pipe)
            },
            isURLSearchParams: function(t) {
                return "undefined" != typeof URLSearchParams && t instanceof URLSearchParams
            },
            isStandardBrowserEnv: function() {
                return ("undefined" == typeof navigator || "ReactNative" !== navigator.product && "NativeScript" !== navigator.product && "NS" !== navigator.product) && ("undefined" != typeof window && "undefined" != typeof document)
            },
            forEach: p,
            merge: function t() {
                var e = {};

                function r(r, n) {
                    c(e[n]) && c(r) ? e[n] = t(e[n], r) : c(r) ? e[n] = t({}, r) : i(r) ? e[n] = r.slice() : e[n] = r
                }
                for (var n = 0, o = arguments.length; n < o; n++) p(arguments[n], r);
                return e
            },
            extend: function(t, e, r) {
                return p(e, (function(e, o) {
                    t[o] = r && "function" == typeof e ? n(e, r) : e
                })), t
            },
            trim: function(t) {
                return t.replace(/^\s*/, "").replace(/\s*$/, "")
            },
            stripBOM: function(t) {
                return 65279 === t.charCodeAt(0) && (t = t.slice(1)), t
            }
        }
    }, function(t, e, r) {
        "use strict";
        (function(t) {
            r.d(e, "a", (function() {
                return o
            })), r.d(e, "d", (function() {
                return i
            })), r.d(e, "c", (function() {
                return a
            })), r.d(e, "b", (function() {
                return s
            }));
            r(1), r(3), r(2), r(8), r(34);
            var n = r(0);
            r(12);
            var o = [n.h.PRODUCT, n.h.MOBILE_PRODUCT, n.h.STATIC_CART, n.h.MOBILE_STATIC_CART];

            function i(t) {
                return [n.h.PRODUCT, n.h.MOBILE_PRODUCT].includes(t)
            }

            function a(t) {
                return [n.h.STATIC_CART, n.h.MOBILE_STATIC_CART].includes(t)
            }
            "/onsite-messaging/".concat(n.h.PRODUCT), "/onsite-messaging/".concat(n.h.MOBILE_PRODUCT), "/onsite-messaging/".concat(n.h.STATIC_CART), "/onsite-messaging/".concat(n.h.MOBILE_STATIC_CART);

            function s(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    r = t.afterpayFontFamily,
                    n = t.afterpayMarginBottom,
                    o = t.afterpayMarginLeft,
                    i = t.afterpayMarginRight,
                    a = t.afterpayMarginTop,
                    s = t.afterpayTextAlign,
                    c = t.afterpayTextColor,
                    u = t.afterpayTextSize,
                    p = t.afterpayLogoColor,
                    f = t.afterpayBoldInstallmentAmount;
                return {
                    afterpayFontFamily: r,
                    afterpayMarginBottom: n,
                    afterpayMarginLeft: o,
                    afterpayMarginRight: i,
                    afterpayMarginTop: a,
                    afterpayTextAlign: s,
                    afterpayTextColor: c,
                    afterpayTextSize: u,
                    afterpayLogoColor: p,
                    afterpayBoldInstallmentAmount: f,
                    hideAfterpay: e
                }
            }
        }).call(this, r(19))
    }, function(t, e, r) {
        "use strict";
        r.d(e, "a", (function() {
            return o
        }));
        var n = r(13);

        function o(t, e) {
            return function(t) {
                if (Array.isArray(t)) return t
            }(t) || function(t, e) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                    var r = [],
                        n = !0,
                        o = !1,
                        i = void 0;
                    try {
                        for (var a, s = t[Symbol.iterator](); !(n = (a = s.next()).done) && (r.push(a.value), !e || r.length !== e); n = !0);
                    } catch (t) {
                        o = !0, i = t
                    } finally {
                        try {
                            n || null == s.return || s.return()
                        } finally {
                            if (o) throw i
                        }
                    }
                    return r
                }
            }(t, e) || Object(n.a)(t, e) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Button = e.isValidButtonProps = e.update = e.clickButton = e.Style = e.Icon = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t, e, r) {
            var n = e.id,
                o = s.getEventNameSpace(t, a.CLICK, e),
                i = {
                    id: n,
                    payload: r
                };
            return s.actionWrapper({
                type: o,
                group: t,
                payload: i
            })
        }

        function p(t, e, r) {
            var n = e.id,
                o = r.label,
                c = s.getEventNameSpace(t, a.UPDATE, e),
                u = i(i({}, r), {
                    id: n,
                    label: o
                });
            return s.actionWrapper({
                type: c,
                group: t,
                payload: u
            })
        }! function(t) {
            t.CLICK = "CLICK", t.UPDATE = "UPDATE"
        }(a = e.Action || (e.Action = {})),
        function(t) {
            t.Print = "print"
        }(e.Icon || (e.Icon = {})),
        function(t) {
            t.Danger = "danger"
        }(e.Style || (e.Style = {})), e.clickButton = u, e.update = p, e.isValidButtonProps = function(t) {
            return "string" == typeof t.id && "string" == typeof t.label
        };
        var f = function(t) {
            function e(e, r) {
                var n = t.call(this, e, c.ComponentType.Button, c.Group.Button) || this;
                return n.disabled = !1, n.loading = !1, n.plain = !1, n.set(r, !1), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        disabled: this.disabled,
                        icon: this.icon,
                        label: this.label,
                        style: this.style,
                        loading: this.loading,
                        plain: this.plain
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = s.getMergedProps(this.options, t),
                    n = r.label,
                    o = r.disabled,
                    i = r.icon,
                    c = r.style,
                    u = r.loading,
                    p = r.plain;
                return this.label = n, this.disabled = Boolean(o), this.icon = i, this.style = c, this.loading = Boolean(u), this.plain = Boolean(p), e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t, e) {
                switch (t) {
                    case a.CLICK:
                        this.app.dispatch(u(this.group, this.component, e));
                        break;
                    case a.UPDATE:
                        var r = p(this.group, this.component, this.payload);
                        this.app.dispatch(r)
                }
                return this
            }, e
        }(s.ActionSet);
        e.Button = f, e.create = function(t, e) {
            return new f(t, e)
        }
    }, function(t, e, r) {
        "use strict";

        function n(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
            return n
        }
        r.d(e, "a", (function() {
            return n
        }))
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.getSingleButton = void 0;
        var n = r(9);
        e.getSingleButton = function(t, e, r, o) {
            return t.addChild(e, t.group, r), t.subscribeToChild(e, n.Action.UPDATE, o), e.payload
        }
    }, function(t, e, r) {
        "use strict";
        r.d(e, "b", (function() {
            return l
        })), r.d(e, "a", (function() {
            return n
        }));
        r(8), r(10);
        r(13);
        var n, o, i, a = r(2),
            s = r(0);
        r(7);

        function c(t, e) {
            var r = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t);
                e && (n = n.filter((function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }))), r.push.apply(r, n)
            }
            return r
        }

        function u(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = null != arguments[e] ? arguments[e] : {};
                e % 2 ? c(Object(r), !0).forEach((function(e) {
                    Object(a.a)(t, e, r[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : c(Object(r)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                }))
            }
            return t
        }! function(t) {
            t.COLOR = "color", t.BLACK = "black", t.WHITE = "white"
        }(n || (n = {})),
        function(t) {
            t.LEFT = "left", t.CENTER = "center", t.RIGHT = "right", t.INHERIT = "inherit"
        }(o || (o = {})),
        function(t) {
            t.LEFT = "left", t.MIDDLE = "middle", t.RIGHT = "right", t.INHERIT = "inherit"
        }(i || (i = {}));
        var p = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : s.i.INITIAL;
                return u(u(u({}, h()), f()), {}, {
                    status: t
                })
            },
            f = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return u({
                    priceSelector: "",
                    hideInterestFree: !1,
                    showUpperLimit: !1,
                    mutationObserverSelector: {
                        activated: !1,
                        observerTarget: ""
                    },
                    replaceModalOpenIcon: "ⓘ"
                }, t)
            },
            d = function() {
                return {
                    domainName: "",
                    minMaxThreshold: {
                        min: s.b.MINIMUM_AMOUNT,
                        max: s.b.MAXIMUM_AMOUNT
                    },
                    textType: "total",
                    modalLearnMoreURL: !1,
                    modalContent: "",
                    giftCard: !1
                }
            };

        function l() {
            var t, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : s.i.INITIAL;
            return t = {
                shop: d()
            }, Object(a.a)(t, s.h.PRODUCT, p(e)), Object(a.a)(t, s.h.MOBILE_PRODUCT, p(e)), Object(a.a)(t, s.h.STATIC_CART, p(e)), Object(a.a)(t, s.h.MOBILE_STATIC_CART, p(e)), t
        }

        function h() {
            return {
                afterpayLogoColor: n.COLOR,
                afterpayTextSize: "inherit",
                afterpayTextColor: "#000000",
                afterpayTextAlign: o.INHERIT,
                afterpayMarginTop: "0px",
                afterpayMarginBottom: "0px",
                afterpayMarginLeft: "0px",
                afterpayMarginRight: "0px",
                afterpayBoldInstallmentAmount: !1,
                afterpayFontFamily: "default",
                hideAfterpay: !1
            }
        }
    }, function(t, e, r) {
        "use strict";
        r.d(e, "a", (function() {
            return o
        }));
        var n = r(10);

        function o(t, e) {
            if (t) {
                if ("string" == typeof t) return Object(n.a)(t, e);
                var r = Object.prototype.toString.call(t).slice(8, -1);
                return "Object" === r && t.constructor && (r = t.constructor.name), "Map" === r || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? Object(n.a)(t, e) : void 0
            }
        }
    }, function(t, e, r) {
        t.exports = r(36)
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.ButtonGroup = e.isGroupedButtonPayload = e.isGroupedButton = e.update = e.Action = void 0;
        var a, s = r(11),
            c = r(5),
            u = r(4);

        function p(t, e, r) {
            return function(t, e, r, n, o) {
                var a = e.id,
                    s = n.label,
                    u = c.getEventNameSpace(t, r, e),
                    p = i(i({}, n), {
                        id: a,
                        label: s,
                        payload: o
                    });
                return c.actionWrapper({
                    type: u,
                    group: t,
                    payload: p
                })
            }(t, e, a.UPDATE, r)
        }! function(t) {
            t.UPDATE = "UPDATE"
        }(a = e.Action || (e.Action = {})), e.update = p, e.isGroupedButton = function(t) {
            var e = t;
            return e.buttons && e.buttons.length > 0 && void 0 !== e.label
        }, e.isGroupedButtonPayload = function(t) {
            var e = t;
            return Array.isArray(e.buttons) && "string" == typeof e.id && "string" == typeof e.label
        };
        var f = function(t) {
            function e(e, r) {
                var n = t.call(this, e, u.ComponentType.ButtonGroup, u.Group.ButtonGroup) || this;
                return n.disabled = !1, n.plain = !1, n.buttonsOptions = [], n.buttons = [], n.set(r, !1), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        buttons: this.buttonsOptions,
                        disabled: this.disabled,
                        label: this.label,
                        plain: this.plain
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        buttons: this.buttons,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = c.getMergedProps(this.options, t),
                    n = r.label,
                    o = r.disabled,
                    i = r.buttons,
                    s = r.plain;
                return this.label = n, this.disabled = Boolean(o), this.buttons = this.getButtons(i), this.plain = Boolean(s), e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.UPDATE:
                        var e = p(this.group, this.component, this.payload);
                        this.app.dispatch(e)
                }
                return this
            }, e.prototype.updateButtons = function(t) {
                if (this.buttons && 0 !== this.buttons.length) {
                    for (var e, r = 0, n = this.buttons; r < n.length; r++) {
                        var o = n[r];
                        if (e = c.updateActionFromPayload(o, t)) break
                    }
                    e && this.dispatch(a.UPDATE)
                }
            }, e.prototype.getSingleButton = function(t) {
                return s.getSingleButton(this, t, this.subgroups, this.updateButtons)
            }, e.prototype.getButtons = function(t) {
                var e = this,
                    r = [];
                return t ? (t.forEach((function(t) {
                    var n = s.getSingleButton(e, t, e.subgroups, e.updateButtons);
                    r.push(n)
                })), this.buttonsOptions = t, r) : []
            }, e
        }(c.ActionSetWithChildren);
        e.ButtonGroup = f, e.create = function(t, e) {
            return new f(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Toast = e.clear = e.show = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t) {
            return s.actionWrapper({
                group: c.Group.Toast,
                payload: t,
                type: a.SHOW
            })
        }

        function p(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Toast,
                type: a.CLEAR
            })
        }! function(t) {
            t.SHOW = "APP::TOAST::SHOW", t.CLEAR = "APP::TOAST::CLEAR"
        }(a = e.Action || (e.Action = {})), e.show = u, e.clear = p;
        var f = function(t) {
            function e(e, r) {
                var n = t.call(this, e, c.Group.Toast, c.Group.Toast) || this;
                return n.message = "", n.duration = 5e3, n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        duration: this.duration,
                        isError: this.isError,
                        message: this.message
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i({
                        id: this.id
                    }, this.options)
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t) {
                var e = s.getMergedProps(this.options, t),
                    r = e.message,
                    n = e.duration,
                    o = e.isError;
                return this.message = r, this.duration = n, this.isError = o, this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.SHOW:
                        var e = u(this.payload);
                        this.app.dispatch(e);
                        break;
                    case a.CLEAR:
                        this.app.dispatch(p({
                            id: this.id
                        }))
                }
                return this
            }, e
        }(s.ActionSet);
        e.Toast = f, e.create = function(t, e) {
            return new f(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.AppLink = e.update = e.Action = void 0;
        var a, s = r(5),
            c = r(4),
            u = r(33);

        function p(t, e, r) {
            var n = e.id,
                o = r.label,
                c = r.destination,
                u = i(i({}, r), {
                    id: n,
                    label: o,
                    destination: c
                });
            return s.actionWrapper({
                group: t,
                type: s.getEventNameSpace(t, a.UPDATE, e),
                payload: u
            })
        }! function(t) {
            t.UPDATE = "UPDATE"
        }(a = e.Action || (e.Action = {})), e.update = p;
        var f = function(t) {
            function e(e, r) {
                var n = t.call(this, e, c.Group.Link, c.Group.Link) || this;
                return n.label = "", n.destination = "", n.set(r, !1), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        label: this.label,
                        destination: this.destination,
                        redirectType: u.Action.APP
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    var t = this.options,
                        e = t.label,
                        r = t.destination,
                        n = t.redirectType,
                        o = r;
                    return {
                        id: this.id,
                        label: e,
                        destination: {
                            path: o
                        },
                        redirectType: n
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = s.getMergedProps(this.options, t),
                    n = r.label,
                    o = r.destination;
                return this.label = n, this.destination = o, e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.UPDATE:
                        var e = p(this.group, this.component, this.payload);
                        this.app.dispatch(e)
                }
                return this
            }, e
        }(s.ActionSet);
        e.AppLink = f, e.create = function(t, e) {
            return new f(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n = this && this.__createBinding || (Object.create ? function(t, e, r, n) {
                void 0 === n && (n = r), Object.defineProperty(t, n, {
                    enumerable: !0,
                    get: function() {
                        return e[r]
                    }
                })
            } : function(t, e, r, n) {
                void 0 === n && (n = r), t[n] = e[r]
            }),
            o = this && this.__setModuleDefault || (Object.create ? function(t, e) {
                Object.defineProperty(t, "default", {
                    enumerable: !0,
                    value: e
                })
            } : function(t, e) {
                t.default = e
            }),
            i = this && this.__importStar || function(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t)
                    for (var r in t) "default" !== r && Object.hasOwnProperty.call(t, r) && n(e, t, r);
                return o(e, t), e
            },
            a = this && this.__exportStar || function(t, e) {
                for (var r in t) "default" === r || e.hasOwnProperty(r) || n(e, t, r)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.Performance = e.Pos = e.AppLink = e.ChannelMenu = e.NavigationMenu = e.Share = e.ContextualSaveBar = e.MarketingExternalActivityTopBar = e.TitleBar = e.SessionToken = e.ResourcePicker = e.Redirect = e.Print = e.ModalContent = e.Modal = e.Loading = e.LeaveConfirmation = e.History = e.Toast = e.Fullscreen = e.FeedbackModal = e.Features = e.Flash = e.Error = e.Client = e.Cart = e.Scanner = e.ButtonGroup = e.Button = e.AuthCode = void 0;
        var s = i(r(53));
        e.AuthCode = s;
        var c = i(r(9));
        e.Button = c;
        var u = i(r(15));
        e.ButtonGroup = u;
        var p = i(r(58));
        e.Cart = p;
        var f = i(r(59));
        e.Client = f;
        var d = i(r(29));
        e.Error = d;
        var l = i(r(60));
        e.Flash = l;
        var h = i(r(62));
        e.Features = h;
        var y = i(r(64));
        e.FeedbackModal = y;
        var A = i(r(65));
        e.Fullscreen = A;
        var v = i(r(66));
        e.LeaveConfirmation = v;
        var E = i(r(67));
        e.Loading = E;
        var O = i(r(32));
        e.Modal = O;
        var P = i(r(68));
        e.ModalContent = P;
        var g = i(r(69));
        e.History = g;
        var b = i(r(33));
        e.Redirect = b;
        var _ = i(r(70));
        e.Print = _;
        var T = i(r(71));
        e.ResourcePicker = T;
        var m = i(r(72));
        e.Scanner = m;
        var S = i(r(73));
        e.SessionToken = S;
        var I = i(r(74));
        e.TitleBar = I;
        var C = i(r(16));
        e.Toast = C;
        var R = i(r(76));
        e.ContextualSaveBar = R;
        var N = i(r(77));
        e.Share = N;
        var w = i(r(78));
        e.NavigationMenu = w;
        var D = i(r(79));
        e.ChannelMenu = D;
        var M = i(r(17));
        e.AppLink = M;
        var L = i(r(80));
        e.Pos = L;
        var j = i(r(81));
        e.MarketingExternalActivityTopBar = j;
        var U = i(r(82));
        e.Performance = U;
        var B = r(83);
        Object.defineProperty(e, "isAppBridgeAction", {
            enumerable: !0,
            get: function() {
                return B.isAppBridgeAction
            }
        }), a(r(4), e)
    }, function(t, e) {
        var r, n, o = t.exports = {};

        function i() {
            throw new Error("setTimeout has not been defined")
        }

        function a() {
            throw new Error("clearTimeout has not been defined")
        }

        function s(t) {
            if (r === setTimeout) return setTimeout(t, 0);
            if ((r === i || !r) && setTimeout) return r = setTimeout, setTimeout(t, 0);
            try {
                return r(t, 0)
            } catch (e) {
                try {
                    return r.call(null, t, 0)
                } catch (e) {
                    return r.call(this, t, 0)
                }
            }
        }! function() {
            try {
                r = "function" == typeof setTimeout ? setTimeout : i
            } catch (t) {
                r = i
            }
            try {
                n = "function" == typeof clearTimeout ? clearTimeout : a
            } catch (t) {
                n = a
            }
        }();
        var c, u = [],
            p = !1,
            f = -1;

        function d() {
            p && c && (p = !1, c.length ? u = c.concat(u) : f = -1, u.length && l())
        }

        function l() {
            if (!p) {
                var t = s(d);
                p = !0;
                for (var e = u.length; e;) {
                    for (c = u, u = []; ++f < e;) c && c[f].run();
                    f = -1, e = u.length
                }
                c = null, p = !1,
                    function(t) {
                        if (n === clearTimeout) return clearTimeout(t);
                        if ((n === a || !n) && clearTimeout) return n = clearTimeout, clearTimeout(t);
                        try {
                            n(t)
                        } catch (e) {
                            try {
                                return n.call(null, t)
                            } catch (e) {
                                return n.call(this, t)
                            }
                        }
                    }(t)
            }
        }

        function h(t, e) {
            this.fun = t, this.array = e
        }

        function y() {}
        o.nextTick = function(t) {
            var e = new Array(arguments.length - 1);
            if (arguments.length > 1)
                for (var r = 1; r < arguments.length; r++) e[r - 1] = arguments[r];
            u.push(new h(t, e)), 1 !== u.length || p || s(l)
        }, h.prototype.run = function() {
            this.fun.apply(null, this.array)
        }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = y, o.addListener = y, o.once = y, o.off = y, o.removeListener = y, o.removeAllListeners = y, o.emit = y, o.prependListener = y, o.prependOnceListener = y, o.listeners = function(t) {
            return []
        }, o.binding = function(t) {
            throw new Error("process.binding is not supported")
        }, o.cwd = function() {
            return "/"
        }, o.chdir = function(t) {
            throw new Error("process.chdir is not supported")
        }, o.umask = function() {
            return 0
        }
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t, e) {
            return function() {
                for (var r = new Array(arguments.length), n = 0; n < r.length; n++) r[n] = arguments[n];
                return t.apply(e, r)
            }
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6);

        function o(t) {
            return encodeURIComponent(t).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
        }
        t.exports = function(t, e, r) {
            if (!e) return t;
            var i;
            if (r) i = r(e);
            else if (n.isURLSearchParams(e)) i = e.toString();
            else {
                var a = [];
                n.forEach(e, (function(t, e) {
                    null != t && (n.isArray(t) ? e += "[]" : t = [t], n.forEach(t, (function(t) {
                        n.isDate(t) ? t = t.toISOString() : n.isObject(t) && (t = JSON.stringify(t)), a.push(o(e) + "=" + o(t))
                    })))
                })), i = a.join("&")
            }
            if (i) {
                var s = t.indexOf("#"); - 1 !== s && (t = t.slice(0, s)), t += (-1 === t.indexOf("?") ? "?" : "&") + i
            }
            return t
        }
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t) {
            return !(!t || !t.__CANCEL__)
        }
    }, function(t, e, r) {
        "use strict";
        (function(e) {
            var n = r(6),
                o = r(41),
                i = {
                    "Content-Type": "application/x-www-form-urlencoded"
                };

            function a(t, e) {
                !n.isUndefined(t) && n.isUndefined(t["Content-Type"]) && (t["Content-Type"] = e)
            }
            var s, c = {
                adapter: (("undefined" != typeof XMLHttpRequest || void 0 !== e && "[object process]" === Object.prototype.toString.call(e)) && (s = r(24)), s),
                transformRequest: [function(t, e) {
                    return o(e, "Accept"), o(e, "Content-Type"), n.isFormData(t) || n.isArrayBuffer(t) || n.isBuffer(t) || n.isStream(t) || n.isFile(t) || n.isBlob(t) ? t : n.isArrayBufferView(t) ? t.buffer : n.isURLSearchParams(t) ? (a(e, "application/x-www-form-urlencoded;charset=utf-8"), t.toString()) : n.isObject(t) ? (a(e, "application/json;charset=utf-8"), JSON.stringify(t)) : t
                }],
                transformResponse: [function(t) {
                    if ("string" == typeof t) try {
                        t = JSON.parse(t)
                    } catch (t) {}
                    return t
                }],
                timeout: 0,
                xsrfCookieName: "XSRF-TOKEN",
                xsrfHeaderName: "X-XSRF-TOKEN",
                maxContentLength: -1,
                maxBodyLength: -1,
                validateStatus: function(t) {
                    return t >= 200 && t < 300
                }
            };
            c.headers = {
                common: {
                    Accept: "application/json, text/plain, */*"
                }
            }, n.forEach(["delete", "get", "head"], (function(t) {
                c.headers[t] = {}
            })), n.forEach(["post", "put", "patch"], (function(t) {
                c.headers[t] = n.merge(i)
            })), t.exports = c
        }).call(this, r(19))
    }, function(t, e, r) {
        "use strict";
        var n = r(6),
            o = r(42),
            i = r(44),
            a = r(21),
            s = r(45),
            c = r(48),
            u = r(49),
            p = r(25);
        t.exports = function(t) {
            return new Promise((function(e, r) {
                var f = t.data,
                    d = t.headers;
                n.isFormData(f) && delete d["Content-Type"];
                var l = new XMLHttpRequest;
                if (t.auth) {
                    var h = t.auth.username || "",
                        y = t.auth.password ? unescape(encodeURIComponent(t.auth.password)) : "";
                    d.Authorization = "Basic " + btoa(h + ":" + y)
                }
                var A = s(t.baseURL, t.url);
                if (l.open(t.method.toUpperCase(), a(A, t.params, t.paramsSerializer), !0), l.timeout = t.timeout, l.onreadystatechange = function() {
                        if (l && 4 === l.readyState && (0 !== l.status || l.responseURL && 0 === l.responseURL.indexOf("file:"))) {
                            var n = "getAllResponseHeaders" in l ? c(l.getAllResponseHeaders()) : null,
                                i = {
                                    data: t.responseType && "text" !== t.responseType ? l.response : l.responseText,
                                    status: l.status,
                                    statusText: l.statusText,
                                    headers: n,
                                    config: t,
                                    request: l
                                };
                            o(e, r, i), l = null
                        }
                    }, l.onabort = function() {
                        l && (r(p("Request aborted", t, "ECONNABORTED", l)), l = null)
                    }, l.onerror = function() {
                        r(p("Network Error", t, null, l)), l = null
                    }, l.ontimeout = function() {
                        var e = "timeout of " + t.timeout + "ms exceeded";
                        t.timeoutErrorMessage && (e = t.timeoutErrorMessage), r(p(e, t, "ECONNABORTED", l)), l = null
                    }, n.isStandardBrowserEnv()) {
                    var v = (t.withCredentials || u(A)) && t.xsrfCookieName ? i.read(t.xsrfCookieName) : void 0;
                    v && (d[t.xsrfHeaderName] = v)
                }
                if ("setRequestHeader" in l && n.forEach(d, (function(t, e) {
                        void 0 === f && "content-type" === e.toLowerCase() ? delete d[e] : l.setRequestHeader(e, t)
                    })), n.isUndefined(t.withCredentials) || (l.withCredentials = !!t.withCredentials), t.responseType) try {
                    l.responseType = t.responseType
                } catch (e) {
                    if ("json" !== t.responseType) throw e
                }
                "function" == typeof t.onDownloadProgress && l.addEventListener("progress", t.onDownloadProgress), "function" == typeof t.onUploadProgress && l.upload && l.upload.addEventListener("progress", t.onUploadProgress), t.cancelToken && t.cancelToken.promise.then((function(t) {
                    l && (l.abort(), r(t), l = null)
                })), f || (f = null), l.send(f)
            }))
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(43);
        t.exports = function(t, e, r, o, i) {
            var a = new Error(t);
            return n(a, e, r, o, i)
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6);
        t.exports = function(t, e) {
            e = e || {};
            var r = {},
                o = ["url", "method", "data"],
                i = ["headers", "auth", "proxy", "params"],
                a = ["baseURL", "transformRequest", "transformResponse", "paramsSerializer", "timeout", "timeoutMessage", "withCredentials", "adapter", "responseType", "xsrfCookieName", "xsrfHeaderName", "onUploadProgress", "onDownloadProgress", "decompress", "maxContentLength", "maxBodyLength", "maxRedirects", "transport", "httpAgent", "httpsAgent", "cancelToken", "socketPath", "responseEncoding"],
                s = ["validateStatus"];

            function c(t, e) {
                return n.isPlainObject(t) && n.isPlainObject(e) ? n.merge(t, e) : n.isPlainObject(e) ? n.merge({}, e) : n.isArray(e) ? e.slice() : e
            }

            function u(o) {
                n.isUndefined(e[o]) ? n.isUndefined(t[o]) || (r[o] = c(void 0, t[o])) : r[o] = c(t[o], e[o])
            }
            n.forEach(o, (function(t) {
                n.isUndefined(e[t]) || (r[t] = c(void 0, e[t]))
            })), n.forEach(i, u), n.forEach(a, (function(o) {
                n.isUndefined(e[o]) ? n.isUndefined(t[o]) || (r[o] = c(void 0, t[o])) : r[o] = c(void 0, e[o])
            })), n.forEach(s, (function(n) {
                n in e ? r[n] = c(t[n], e[n]) : n in t && (r[n] = c(void 0, t[n]))
            }));
            var p = o.concat(i).concat(a).concat(s),
                f = Object.keys(t).concat(Object.keys(e)).filter((function(t) {
                    return -1 === p.indexOf(t)
                }));
            return n.forEach(f, u), r
        }
    }, function(t, e, r) {
        "use strict";

        function n(t) {
            this.message = t
        }
        n.prototype.toString = function() {
            return "Cancel" + (this.message ? ": " + this.message : "")
        }, n.prototype.__CANCEL__ = !0, t.exports = n
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.LifecycleHook = e.MessageType = e.PermissionType = e.isV1Config = void 0, e.isV1Config = function(t) {
                return void 0 !== t.shopOrigin
            },
            function(t) {
                t.Dispatch = "Dispatch", t.Subscribe = "Subscribe"
            }(e.PermissionType || (e.PermissionType = {})),
            function(t) {
                t.GetState = "getState", t.Dispatch = "dispatch", t.Subscribe = "subscribe", t.Unsubscribe = "unsubscribe"
            }(e.MessageType || (e.MessageType = {})),
            function(t) {
                t.UpdateAction = "UpdateAction", t.DispatchAction = "DispatchAction"
            }(e.LifecycleHook || (e.LifecycleHook = {}))
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.throwError = e.fromAction = e.AppBridgeError = e.invalidOriginAction = e.isErrorEventName = e.permissionAction = e.networkAction = e.persistenceAction = e.unsupportedOperationAction = e.unexpectedAction = e.invalidAction = e.invalidActionType = e.invalidPayload = e.Message = e.AppActionType = e.Action = void 0;
        var n, o = r(5),
            i = r(4);

        function a(t, e, r) {
            var n = e.payload;
            return o.actionWrapper({
                type: t,
                group: i.Group.Error,
                payload: {
                    action: e,
                    message: r,
                    type: t,
                    id: n && n.id ? n.id : void 0
                }
            })
        }! function(t) {
            t.INVALID_ACTION = "APP::ERROR::INVALID_ACTION", t.INVALID_ACTION_TYPE = "APP::ERROR::INVALID_ACTION_TYPE", t.INVALID_PAYLOAD = "APP::ERROR::INVALID_PAYLOAD", t.INVALID_OPTIONS = "APP::ERROR::INVALID_OPTIONS", t.UNEXPECTED_ACTION = "APP::ERROR::UNEXPECTED_ACTION", t.PERSISTENCE = "APP::ERROR::PERSISTENCE", t.UNSUPPORTED_OPERATION = "APP::ERROR::UNSUPPORTED_OPERATION", t.NETWORK = "APP::ERROR::NETWORK", t.PERMISSION = "APP::ERROR::PERMISSION", t.FAILED_AUTHENTICATION = "APP::ERROR::FAILED_AUTHENTICATION", t.INVALID_ORIGIN = "APP::ERROR::INVALID_ORIGIN"
        }(n = e.Action || (e.Action = {})),
        function(t) {
            t.INVALID_CONFIG = "APP::ERROR::INVALID_CONFIG", t.MISSING_CONFIG = "APP::APP_ERROR::MISSING_CONFIG", t.MISSING_APP_BRIDGE_MIDDLEWARE = "APP::APP_ERROR::MISSING_APP_BRIDGE_MIDDLEWARE", t.WINDOW_UNDEFINED = "APP::APP_ERROR::WINDOW_UNDEFINED", t.REDUX_REINSTANTIATED = "APP::APP_ERROR::REDUX_REINSTANTIATED", t.MISSING_LOCAL_ORIGIN = "APP::APP_ERROR::MISSING_LOCAL_ORIGIN", t.MISSING_HOST_PROVIDER = "APP::APP_ERROR::MISSING_HOST_PROVIDER", t.MISSING_ROUTER_CONTEXT = "APP::APP_ERROR::MISSING_ROUTER_CONTEXT", t.MISSING_HISTORY_BLOCK = "APP::APP_ERROR::MISSING_HISTORY_BLOCK"
        }(e.AppActionType || (e.AppActionType = {})),
        function(t) {
            t.MISSING_PAYLOAD = "Missing payload", t.INVALID_PAYLOAD_ID = "Id in payload is missing or invalid"
        }(e.Message || (e.Message = {})), e.invalidPayload = function(t, e) {
            return a(n.INVALID_PAYLOAD, t, e || "The action's payload is missing required properties or has invalid properties")
        }, e.invalidActionType = function(t, e) {
            return o.actionWrapper({
                group: i.Group.Error,
                payload: {
                    action: t,
                    message: e || "The action type is invalid or unsupported",
                    type: n.INVALID_ACTION_TYPE
                },
                type: n.INVALID_ACTION_TYPE
            })
        }, e.invalidAction = function(t, e) {
            return o.actionWrapper({
                group: i.Group.Error,
                payload: {
                    action: t,
                    message: e || "The action's has missing/invalid values for `group`, `type` or `version`",
                    type: n.INVALID_ACTION
                },
                type: n.INVALID_ACTION
            })
        }, e.unexpectedAction = function(t, e) {
            return o.actionWrapper({
                group: i.Group.Error,
                payload: {
                    action: t,
                    message: e || "Action cannot be called at this time",
                    type: n.UNEXPECTED_ACTION
                },
                type: n.UNEXPECTED_ACTION
            })
        }, e.unsupportedOperationAction = function(t, e) {
            return a(n.UNSUPPORTED_OPERATION, t, e || "The action type is unsupported")
        }, e.persistenceAction = function(t, e) {
            return a(n.PERSISTENCE, t, e || "Action cannot be persisted on server")
        }, e.networkAction = function(t, e) {
            return a(n.NETWORK, t, e || "Network error")
        }, e.permissionAction = function(t, e) {
            return a(n.PERMISSION, t, e || "Action is not permitted")
        }, e.isErrorEventName = function(t) {
            return "string" == typeof o.findMatchInEnum(n, t)
        }, e.invalidOriginAction = function(t) {
            return o.actionWrapper({
                group: i.Group.Error,
                payload: {
                    message: t,
                    type: n.INVALID_ORIGIN
                },
                type: n.INVALID_ORIGIN
            })
        };
        var s = function(t) {
            this.name = "AppBridgeError", this.message = t, "function" == typeof Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error(this.message).stack
        };

        function c(t, e, r) {
            var n = new s(t ? e + ": " + t : e);
            return n.action = r, n.type = e, n
        }
        e.AppBridgeError = s, s.prototype = Object.create(Error.prototype), e.fromAction = c, e.throwError = function() {
            var t, e, r = arguments[0];
            throw "string" == typeof arguments[1] ? t = arguments[1] : (e = arguments[1], t = arguments[2] || ""), c(t, r, e)
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.SEPARATOR = e.PREFIX = void 0, e.PREFIX = "APP", e.SEPARATOR = "::"
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Action = void 0,
            function(t) {
                t.UPDATE = "APP::FEATURES::UPDATE", t.REQUEST = "APP::FEATURES::REQUEST", t.REQUEST_UPDATE = "APP::FEATURES::REQUEST::UPDATE"
            }(e.Action || (e.Action = {}))
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.ModalIframe = e.ModalMessage = e.Modal = e.isMessageModal = e.isIframeModal = e.data = e.update = e.clickFooterButton = e.updateModalSize = e.closeModal = e.openModal = e.Size = e.Action = void 0;
        var a, s, c = r(11),
            u = r(5),
            p = r(4),
            f = r(9);
        ! function(t) {
            t.OPEN = "APP::MODAL::OPEN", t.CLOSE = "APP::MODAL::CLOSE", t.UPDATE = "APP::MODAL::UPDATE", t.UPDATE_CONTENT = "APP::MODAL::CONTENT::UPDATE", t.FOOTER_BUTTON_CLICK = "APP::MODAL::FOOTER::BUTTON::CLICK", t.FOOTER_BUTTON_UPDATE = "APP::MODAL::FOOTER::BUTTON::UPDATE", t.UPDATE_SIZE = "APP::MODAL::UPDATE_SIZE", t.DATA = "APP::MODAL::DATA"
        }(a = e.Action || (e.Action = {})),
        function(t) {
            t.Small = "small", t.Medium = "medium", t.Large = "large", t.Full = "full", t.Auto = "auto"
        }(s = e.Size || (e.Size = {}));
        var d = {
            group: p.Group.Modal,
            subgroups: ["Footer"],
            type: p.ComponentType.Button
        };

        function l(t) {
            return u.actionWrapper({
                group: p.Group.Modal,
                payload: t,
                type: a.OPEN
            })
        }

        function h(t) {
            return u.actionWrapper({
                group: p.Group.Modal,
                payload: t,
                type: a.CLOSE
            })
        }

        function y(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.Modal,
                type: a.UPDATE
            })
        }

        function A(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.Modal,
                type: a.DATA
            })
        }

        function v(t) {
            return "string" == typeof t.url || "string" == typeof t.path
        }
        e.openModal = l, e.closeModal = h, e.updateModalSize = function(t) {
            return u.actionWrapper({
                group: p.Group.Modal,
                payload: t,
                type: a.UPDATE_SIZE
            })
        }, e.clickFooterButton = function(t, e) {
            var r = i({
                id: t
            }, d);
            return f.clickButton(p.Group.Modal, r, e)
        }, e.update = y, e.data = A, e.isIframeModal = v, e.isMessageModal = function(t) {
            return "string" == typeof t.message
        };
        var E = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.size = s.Small, e
            }
            return o(e, t), Object.defineProperty(e.prototype, "footer", {
                get: function() {
                    if (this.footerPrimary || this.footerSecondary) return {
                        buttons: {
                            primary: this.footerPrimary,
                            secondary: this.footerSecondary
                        }
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "footerOptions", {
                get: function() {
                    if (this.footerPrimaryOptions || this.footerSecondaryOptions) return {
                        buttons: {
                            primary: this.footerPrimaryOptions,
                            secondary: this.footerSecondaryOptions
                        }
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.close = function() {
                this.app.dispatch(h({
                    id: this.id
                }))
            }, e.prototype.setFooterPrimaryButton = function(t, e) {
                var r = this,
                    n = d.subgroups;
                this.footerPrimaryOptions = this.getChildButton(t, this.footerPrimaryOptions), this.footerPrimary = this.footerPrimaryOptions ? c.getSingleButton(this, this.footerPrimaryOptions, n, (function(t) {
                    r.updatePrimaryFooterButton(t, e)
                })) : void 0
            }, e.prototype.setFooterSecondaryButtons = function(t, e) {
                var r = this,
                    n = d.subgroups,
                    o = t || [],
                    i = this.footerOptions && this.footerOptions.buttons.secondary || [];
                this.footerSecondaryOptions = this.getUpdatedChildActions(o, i), this.footerSecondary = this.footerSecondaryOptions ? this.footerSecondaryOptions.map((function(t) {
                    return c.getSingleButton(r, t, n, (function(t) {
                        r.updateSecondaryFooterButton(t, e)
                    }))
                })) : void 0
            }, e.prototype.getChildButton = function(t, e) {
                var r = t ? [t] : [],
                    n = e ? [e] : [],
                    o = this.getUpdatedChildActions(r, n);
                return o ? o[0] : void 0
            }, e.prototype.updatePrimaryFooterButton = function(t, e) {
                this.footer && this.footer.buttons.primary && u.updateActionFromPayload(this.footer.buttons.primary, t) && e()
            }, e.prototype.updateSecondaryFooterButton = function(t, e) {
                if (this.footer && this.footer.buttons && this.footer.buttons.secondary) {
                    for (var r, n = 0, o = this.footer.buttons.secondary; n < o.length; n++) {
                        var i = o[n];
                        if (r = u.updateActionFromPayload(i, t)) break
                    }
                    r && e()
                }
            }, e
        }(u.ActionSetWithChildren);
        e.Modal = E;
        var O = function(t) {
            function e(e, r) {
                var n = t.call(this, e, p.Group.Modal, p.Group.Modal) || this;
                return n.set(r, !1), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        footer: this.footer,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        footer: this.footerOptions,
                        message: this.message,
                        size: this.size,
                        title: this.title
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                var r = this;
                void 0 === e && (e = !0);
                var n = u.getMergedProps(this.options, t),
                    o = n.title,
                    i = n.footer,
                    s = n.message,
                    c = n.size;
                return this.title = o, this.message = s, this.size = c, this.setFooterPrimaryButton(i ? i.buttons.primary : void 0, (function() {
                    r.dispatch(a.UPDATE)
                })), this.setFooterSecondaryButtons(i ? i.buttons.secondary : void 0, (function() {
                    r.dispatch(a.UPDATE)
                })), e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.OPEN:
                        this.app.dispatch(l(this.payload));
                        break;
                    case a.CLOSE:
                        this.close();
                        break;
                    case a.UPDATE:
                        this.app.dispatch(y(this.payload))
                }
                return this
            }, e
        }(E);
        e.ModalMessage = O;
        var P = function(t) {
            function e(e, r) {
                var n = t.call(this, e, p.Group.Modal, p.Group.Modal) || this;
                return n.set(r, !1), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        footer: this.footer,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        footer: this.footerOptions,
                        path: this.path,
                        size: this.size,
                        title: this.title,
                        url: this.url,
                        loading: this.loading
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                var r = this;
                void 0 === e && (e = !0);
                var n = u.getMergedProps(this.options, t),
                    o = n.title,
                    i = n.footer,
                    s = n.path,
                    c = n.url,
                    p = n.size,
                    f = n.loading;
                return this.title = o, this.url = c, this.path = s, this.size = p, this.loading = f, this.setFooterPrimaryButton(i ? i.buttons.primary : void 0, (function() {
                    r.dispatch(a.UPDATE)
                })), this.setFooterSecondaryButtons(i ? i.buttons.secondary : void 0, (function() {
                    r.dispatch(a.UPDATE)
                })), e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t, e) {
                switch (t) {
                    case a.OPEN:
                        this.app.dispatch(l(this.payload));
                        break;
                    case a.CLOSE:
                        this.close();
                        break;
                    case a.UPDATE:
                        this.app.dispatch(y(this.payload));
                        break;
                    case a.DATA:
                        this.app.dispatch(A(e || {}))
                }
                return this
            }, e
        }(E);
        e.ModalIframe = P, e.create = function(t, e) {
            return v(e) ? new P(t, e) : new O(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Redirect = e.isRemotePayload = e.isAdminSectionPayload = e.isAdminPathPayload = e.isAppPayload = e.toDestination = e.toApp = e.toRemote = e.toAdminSection = e.toAdminPath = e.isProductVariantCreateResourcePayload = e.isProductVariantResourcePayload = e.isCreateResourcePayload = e.isResourcePayload = e.ResourceType = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t) {
            return !0 === t.create
        }

        function p(t) {
            var e = t;
            return void 0 !== e.id && void 0 !== e.variant
        }

        function f(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Navigation,
                type: a.ADMIN_PATH
            })
        }

        function d(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Navigation,
                type: a.ADMIN_SECTION
            })
        }

        function l(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Navigation,
                type: a.REMOTE
            })
        }

        function h(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Navigation,
                type: a.APP
            })
        }

        function y(t, e, r) {
            switch (t) {
                case a.APP:
                    var n = A(e) ? e : {
                        path: e
                    };
                    return h(i({
                        id: r
                    }, n));
                case a.ADMIN_PATH:
                    var o = v(e) ? e : {
                        path: e
                    };
                    return f(i({
                        id: r
                    }, o));
                case a.ADMIN_SECTION:
                    var s = E(e) ? e : {
                        section: e
                    };
                    return d(i({
                        id: r
                    }, s));
                case a.REMOTE:
                    var c = O(e) ? e : {
                        url: e
                    };
                    return l(i({
                        id: r
                    }, c))
            }
        }

        function A(t) {
            return "object" == typeof t && t.hasOwnProperty("path")
        }

        function v(t) {
            return "object" == typeof t && t.hasOwnProperty("path")
        }

        function E(t) {
            return "object" == typeof t && "object" == typeof t.section && t.section.hasOwnProperty("name")
        }

        function O(t) {
            return "object" == typeof t && t.hasOwnProperty("url")
        }! function(t) {
            t.ADMIN_SECTION = "APP::NAVIGATION::REDIRECT::ADMIN::SECTION", t.ADMIN_PATH = "APP::NAVIGATION::REDIRECT::ADMIN::PATH", t.REMOTE = "APP::NAVIGATION::REDIRECT::REMOTE", t.APP = "APP::NAVIGATION::REDIRECT::APP"
        }(a = e.Action || (e.Action = {})),
        function(t) {
            t.Product = "products", t.Collection = "collections", t.Order = "orders", t.Customer = "customers", t.Discount = "discounts"
        }(e.ResourceType || (e.ResourceType = {})), e.isResourcePayload = function(t) {
            return "string" == typeof t.id
        }, e.isCreateResourcePayload = u, e.isProductVariantResourcePayload = p, e.isProductVariantCreateResourcePayload = function(t) {
            return !!p(t) && u(t.variant)
        }, e.toAdminPath = f, e.toAdminSection = d, e.toRemote = l, e.toApp = h, e.toDestination = y, e.isAppPayload = A, e.isAdminPathPayload = v, e.isAdminSectionPayload = E, e.isRemotePayload = O;
        var P = function(t) {
            function e(e) {
                return t.call(this, e, "Redirect", c.Group.Navigation) || this
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return {
                        id: this.id
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.dispatch = function(t, e) {
                var r = y(t, e, this.payload.id);
                return this.app.dispatch(r), this
            }, e
        }(s.ActionSet);
        e.Redirect = P, e.create = function(t) {
            return new P(t)
        }
    }, function(t, e, r) {
        "use strict";

        function n(t, e) {
            if (null == t) return {};
            var r, n, o = function(t, e) {
                if (null == t) return {};
                var r, n, o = {},
                    i = Object.keys(t);
                for (n = 0; n < i.length; n++) r = i[n], e.indexOf(r) >= 0 || (o[r] = t[r]);
                return o
            }(t, e);
            if (Object.getOwnPropertySymbols) {
                var i = Object.getOwnPropertySymbols(t);
                for (n = 0; n < i.length; n++) r = i[n], e.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(t, r) && (o[r] = t[r])
            }
            return o
        }
        r.d(e, "a", (function() {
            return n
        }))
    }, function(t, e, r) {
        var n = function(t) {
            "use strict";
            var e = Object.prototype,
                r = e.hasOwnProperty,
                n = "function" == typeof Symbol ? Symbol : {},
                o = n.iterator || "@@iterator",
                i = n.asyncIterator || "@@asyncIterator",
                a = n.toStringTag || "@@toStringTag";

            function s(t, e, r) {
                return Object.defineProperty(t, e, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }), t[e]
            }
            try {
                s({}, "")
            } catch (t) {
                s = function(t, e, r) {
                    return t[e] = r
                }
            }

            function c(t, e, r, n) {
                var o = e && e.prototype instanceof f ? e : f,
                    i = Object.create(o.prototype),
                    a = new _(n || []);
                return i._invoke = function(t, e, r) {
                    var n = "suspendedStart";
                    return function(o, i) {
                        if ("executing" === n) throw new Error("Generator is already running");
                        if ("completed" === n) {
                            if ("throw" === o) throw i;
                            return m()
                        }
                        for (r.method = o, r.arg = i;;) {
                            var a = r.delegate;
                            if (a) {
                                var s = P(a, r);
                                if (s) {
                                    if (s === p) continue;
                                    return s
                                }
                            }
                            if ("next" === r.method) r.sent = r._sent = r.arg;
                            else if ("throw" === r.method) {
                                if ("suspendedStart" === n) throw n = "completed", r.arg;
                                r.dispatchException(r.arg)
                            } else "return" === r.method && r.abrupt("return", r.arg);
                            n = "executing";
                            var c = u(t, e, r);
                            if ("normal" === c.type) {
                                if (n = r.done ? "completed" : "suspendedYield", c.arg === p) continue;
                                return {
                                    value: c.arg,
                                    done: r.done
                                }
                            }
                            "throw" === c.type && (n = "completed", r.method = "throw", r.arg = c.arg)
                        }
                    }
                }(t, r, a), i
            }

            function u(t, e, r) {
                try {
                    return {
                        type: "normal",
                        arg: t.call(e, r)
                    }
                } catch (t) {
                    return {
                        type: "throw",
                        arg: t
                    }
                }
            }
            t.wrap = c;
            var p = {};

            function f() {}

            function d() {}

            function l() {}
            var h = {};
            h[o] = function() {
                return this
            };
            var y = Object.getPrototypeOf,
                A = y && y(y(T([])));
            A && A !== e && r.call(A, o) && (h = A);
            var v = l.prototype = f.prototype = Object.create(h);

            function E(t) {
                ["next", "throw", "return"].forEach((function(e) {
                    s(t, e, (function(t) {
                        return this._invoke(e, t)
                    }))
                }))
            }

            function O(t, e) {
                var n;
                this._invoke = function(o, i) {
                    function a() {
                        return new e((function(n, a) {
                            ! function n(o, i, a, s) {
                                var c = u(t[o], t, i);
                                if ("throw" !== c.type) {
                                    var p = c.arg,
                                        f = p.value;
                                    return f && "object" == typeof f && r.call(f, "__await") ? e.resolve(f.__await).then((function(t) {
                                        n("next", t, a, s)
                                    }), (function(t) {
                                        n("throw", t, a, s)
                                    })) : e.resolve(f).then((function(t) {
                                        p.value = t, a(p)
                                    }), (function(t) {
                                        return n("throw", t, a, s)
                                    }))
                                }
                                s(c.arg)
                            }(o, i, n, a)
                        }))
                    }
                    return n = n ? n.then(a, a) : a()
                }
            }

            function P(t, e) {
                var r = t.iterator[e.method];
                if (void 0 === r) {
                    if (e.delegate = null, "throw" === e.method) {
                        if (t.iterator.return && (e.method = "return", e.arg = void 0, P(t, e), "throw" === e.method)) return p;
                        e.method = "throw", e.arg = new TypeError("The iterator does not provide a 'throw' method")
                    }
                    return p
                }
                var n = u(r, t.iterator, e.arg);
                if ("throw" === n.type) return e.method = "throw", e.arg = n.arg, e.delegate = null, p;
                var o = n.arg;
                return o ? o.done ? (e[t.resultName] = o.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", e.arg = void 0), e.delegate = null, p) : o : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, p)
            }

            function g(t) {
                var e = {
                    tryLoc: t[0]
                };
                1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
            }

            function b(t) {
                var e = t.completion || {};
                e.type = "normal", delete e.arg, t.completion = e
            }

            function _(t) {
                this.tryEntries = [{
                    tryLoc: "root"
                }], t.forEach(g, this), this.reset(!0)
            }

            function T(t) {
                if (t) {
                    var e = t[o];
                    if (e) return e.call(t);
                    if ("function" == typeof t.next) return t;
                    if (!isNaN(t.length)) {
                        var n = -1,
                            i = function e() {
                                for (; ++n < t.length;)
                                    if (r.call(t, n)) return e.value = t[n], e.done = !1, e;
                                return e.value = void 0, e.done = !0, e
                            };
                        return i.next = i
                    }
                }
                return {
                    next: m
                }
            }

            function m() {
                return {
                    value: void 0,
                    done: !0
                }
            }
            return d.prototype = v.constructor = l, l.constructor = d, d.displayName = s(l, a, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                var e = "function" == typeof t && t.constructor;
                return !!e && (e === d || "GeneratorFunction" === (e.displayName || e.name))
            }, t.mark = function(t) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(t, l) : (t.__proto__ = l, s(t, a, "GeneratorFunction")), t.prototype = Object.create(v), t
            }, t.awrap = function(t) {
                return {
                    __await: t
                }
            }, E(O.prototype), O.prototype[i] = function() {
                return this
            }, t.AsyncIterator = O, t.async = function(e, r, n, o, i) {
                void 0 === i && (i = Promise);
                var a = new O(c(e, r, n, o), i);
                return t.isGeneratorFunction(r) ? a : a.next().then((function(t) {
                    return t.done ? t.value : a.next()
                }))
            }, E(v), s(v, a, "Generator"), v[o] = function() {
                return this
            }, v.toString = function() {
                return "[object Generator]"
            }, t.keys = function(t) {
                var e = [];
                for (var r in t) e.push(r);
                return e.reverse(),
                    function r() {
                        for (; e.length;) {
                            var n = e.pop();
                            if (n in t) return r.value = n, r.done = !1, r
                        }
                        return r.done = !0, r
                    }
            }, t.values = T, _.prototype = {
                constructor: _,
                reset: function(t) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(b), !t)
                        for (var e in this) "t" === e.charAt(0) && r.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
                },
                stop: function() {
                    this.done = !0;
                    var t = this.tryEntries[0].completion;
                    if ("throw" === t.type) throw t.arg;
                    return this.rval
                },
                dispatchException: function(t) {
                    if (this.done) throw t;
                    var e = this;

                    function n(r, n) {
                        return a.type = "throw", a.arg = t, e.next = r, n && (e.method = "next", e.arg = void 0), !!n
                    }
                    for (var o = this.tryEntries.length - 1; o >= 0; --o) {
                        var i = this.tryEntries[o],
                            a = i.completion;
                        if ("root" === i.tryLoc) return n("end");
                        if (i.tryLoc <= this.prev) {
                            var s = r.call(i, "catchLoc"),
                                c = r.call(i, "finallyLoc");
                            if (s && c) {
                                if (this.prev < i.catchLoc) return n(i.catchLoc, !0);
                                if (this.prev < i.finallyLoc) return n(i.finallyLoc)
                            } else if (s) {
                                if (this.prev < i.catchLoc) return n(i.catchLoc, !0)
                            } else {
                                if (!c) throw new Error("try statement without catch or finally");
                                if (this.prev < i.finallyLoc) return n(i.finallyLoc)
                            }
                        }
                    }
                },
                abrupt: function(t, e) {
                    for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                        var o = this.tryEntries[n];
                        if (o.tryLoc <= this.prev && r.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                            var i = o;
                            break
                        }
                    }
                    i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                    var a = i ? i.completion : {};
                    return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, p) : this.complete(a)
                },
                complete: function(t, e) {
                    if ("throw" === t.type) throw t.arg;
                    return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), p
                },
                finish: function(t) {
                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                        var r = this.tryEntries[e];
                        if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), b(r), p
                    }
                },
                catch: function(t) {
                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                        var r = this.tryEntries[e];
                        if (r.tryLoc === t) {
                            var n = r.completion;
                            if ("throw" === n.type) {
                                var o = n.arg;
                                b(r)
                            }
                            return o
                        }
                    }
                    throw new Error("illegal catch attempt")
                },
                delegateYield: function(t, e, r) {
                    return this.delegate = {
                        iterator: T(t),
                        resultName: e,
                        nextLoc: r
                    }, "next" === this.method && (this.arg = void 0), p
                }
            }, t
        }(t.exports);
        try {
            regeneratorRuntime = n
        } catch (t) {
            Function("r", "regeneratorRuntime = r")(n)
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6),
            o = r(20),
            i = r(37),
            a = r(26);

        function s(t) {
            var e = new i(t),
                r = o(i.prototype.request, e);
            return n.extend(r, i.prototype, e), n.extend(r, e), r
        }
        var c = s(r(23));
        c.Axios = i, c.create = function(t) {
            return s(a(c.defaults, t))
        }, c.Cancel = r(27), c.CancelToken = r(50), c.isCancel = r(22), c.all = function(t) {
            return Promise.all(t)
        }, c.spread = r(51), c.isAxiosError = r(52), t.exports = c, t.exports.default = c
    }, function(t, e, r) {
        "use strict";
        var n = r(6),
            o = r(21),
            i = r(38),
            a = r(39),
            s = r(26);

        function c(t) {
            this.defaults = t, this.interceptors = {
                request: new i,
                response: new i
            }
        }
        c.prototype.request = function(t) {
            "string" == typeof t ? (t = arguments[1] || {}).url = arguments[0] : t = t || {}, (t = s(this.defaults, t)).method ? t.method = t.method.toLowerCase() : this.defaults.method ? t.method = this.defaults.method.toLowerCase() : t.method = "get";
            var e = [a, void 0],
                r = Promise.resolve(t);
            for (this.interceptors.request.forEach((function(t) {
                    e.unshift(t.fulfilled, t.rejected)
                })), this.interceptors.response.forEach((function(t) {
                    e.push(t.fulfilled, t.rejected)
                })); e.length;) r = r.then(e.shift(), e.shift());
            return r
        }, c.prototype.getUri = function(t) {
            return t = s(this.defaults, t), o(t.url, t.params, t.paramsSerializer).replace(/^\?/, "")
        }, n.forEach(["delete", "get", "head", "options"], (function(t) {
            c.prototype[t] = function(e, r) {
                return this.request(s(r || {}, {
                    method: t,
                    url: e,
                    data: (r || {}).data
                }))
            }
        })), n.forEach(["post", "put", "patch"], (function(t) {
            c.prototype[t] = function(e, r, n) {
                return this.request(s(n || {}, {
                    method: t,
                    url: e,
                    data: r
                }))
            }
        })), t.exports = c
    }, function(t, e, r) {
        "use strict";
        var n = r(6);

        function o() {
            this.handlers = []
        }
        o.prototype.use = function(t, e) {
            return this.handlers.push({
                fulfilled: t,
                rejected: e
            }), this.handlers.length - 1
        }, o.prototype.eject = function(t) {
            this.handlers[t] && (this.handlers[t] = null)
        }, o.prototype.forEach = function(t) {
            n.forEach(this.handlers, (function(e) {
                null !== e && t(e)
            }))
        }, t.exports = o
    }, function(t, e, r) {
        "use strict";
        var n = r(6),
            o = r(40),
            i = r(22),
            a = r(23);

        function s(t) {
            t.cancelToken && t.cancelToken.throwIfRequested()
        }
        t.exports = function(t) {
            return s(t), t.headers = t.headers || {}, t.data = o(t.data, t.headers, t.transformRequest), t.headers = n.merge(t.headers.common || {}, t.headers[t.method] || {}, t.headers), n.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (function(e) {
                delete t.headers[e]
            })), (t.adapter || a.adapter)(t).then((function(e) {
                return s(t), e.data = o(e.data, e.headers, t.transformResponse), e
            }), (function(e) {
                return i(e) || (s(t), e && e.response && (e.response.data = o(e.response.data, e.response.headers, t.transformResponse))), Promise.reject(e)
            }))
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6);
        t.exports = function(t, e, r) {
            return n.forEach(r, (function(r) {
                t = r(t, e)
            })), t
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6);
        t.exports = function(t, e) {
            n.forEach(t, (function(r, n) {
                n !== e && n.toUpperCase() === e.toUpperCase() && (t[e] = r, delete t[n])
            }))
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(25);
        t.exports = function(t, e, r) {
            var o = r.config.validateStatus;
            r.status && o && !o(r.status) ? e(n("Request failed with status code " + r.status, r.config, null, r.request, r)) : t(r)
        }
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t, e, r, n, o) {
            return t.config = e, r && (t.code = r), t.request = n, t.response = o, t.isAxiosError = !0, t.toJSON = function() {
                return {
                    message: this.message,
                    name: this.name,
                    description: this.description,
                    number: this.number,
                    fileName: this.fileName,
                    lineNumber: this.lineNumber,
                    columnNumber: this.columnNumber,
                    stack: this.stack,
                    config: this.config,
                    code: this.code
                }
            }, t
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6);
        t.exports = n.isStandardBrowserEnv() ? {
            write: function(t, e, r, o, i, a) {
                var s = [];
                s.push(t + "=" + encodeURIComponent(e)), n.isNumber(r) && s.push("expires=" + new Date(r).toGMTString()), n.isString(o) && s.push("path=" + o), n.isString(i) && s.push("domain=" + i), !0 === a && s.push("secure"), document.cookie = s.join("; ")
            },
            read: function(t) {
                var e = document.cookie.match(new RegExp("(^|;\\s*)(" + t + ")=([^;]*)"));
                return e ? decodeURIComponent(e[3]) : null
            },
            remove: function(t) {
                this.write(t, "", Date.now() - 864e5)
            }
        } : {
            write: function() {},
            read: function() {
                return null
            },
            remove: function() {}
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(46),
            o = r(47);
        t.exports = function(t, e) {
            return t && !n(e) ? o(t, e) : e
        }
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t) {
            return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(t)
        }
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t, e) {
            return e ? t.replace(/\/+$/, "") + "/" + e.replace(/^\/+/, "") : t
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6),
            o = ["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"];
        t.exports = function(t) {
            var e, r, i, a = {};
            return t ? (n.forEach(t.split("\n"), (function(t) {
                if (i = t.indexOf(":"), e = n.trim(t.substr(0, i)).toLowerCase(), r = n.trim(t.substr(i + 1)), e) {
                    if (a[e] && o.indexOf(e) >= 0) return;
                    a[e] = "set-cookie" === e ? (a[e] ? a[e] : []).concat([r]) : a[e] ? a[e] + ", " + r : r
                }
            })), a) : a
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(6);
        t.exports = n.isStandardBrowserEnv() ? function() {
            var t, e = /(msie|trident)/i.test(navigator.userAgent),
                r = document.createElement("a");

            function o(t) {
                var n = t;
                return e && (r.setAttribute("href", n), n = r.href), r.setAttribute("href", n), {
                    href: r.href,
                    protocol: r.protocol ? r.protocol.replace(/:$/, "") : "",
                    host: r.host,
                    search: r.search ? r.search.replace(/^\?/, "") : "",
                    hash: r.hash ? r.hash.replace(/^#/, "") : "",
                    hostname: r.hostname,
                    port: r.port,
                    pathname: "/" === r.pathname.charAt(0) ? r.pathname : "/" + r.pathname
                }
            }
            return t = o(window.location.href),
                function(e) {
                    var r = n.isString(e) ? o(e) : e;
                    return r.protocol === t.protocol && r.host === t.host
                }
        }() : function() {
            return !0
        }
    }, function(t, e, r) {
        "use strict";
        var n = r(27);

        function o(t) {
            if ("function" != typeof t) throw new TypeError("executor must be a function.");
            var e;
            this.promise = new Promise((function(t) {
                e = t
            }));
            var r = this;
            t((function(t) {
                r.reason || (r.reason = new n(t), e(r.reason))
            }))
        }
        o.prototype.throwIfRequested = function() {
            if (this.reason) throw this.reason
        }, o.source = function() {
            var t;
            return {
                token: new o((function(e) {
                    t = e
                })),
                cancel: t
            }
        }, t.exports = o
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t) {
            return function(e) {
                return t.apply(null, e)
            }
        }
    }, function(t, e, r) {
        "use strict";
        t.exports = function(t) {
            return "object" == typeof t && !0 === t.isAxiosError
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.respond = e.request = e.Action = void 0;
        var n, o = r(5),
            i = r(4);
        ! function(t) {
            t.REQUEST = "APP::AUTH_CODE::REQUEST", t.RESPOND = "APP::AUTH_CODE::RESPOND"
        }(n = e.Action || (e.Action = {})), e.request = function(t) {
            return o.actionWrapper({
                group: i.Group.AuthCode,
                type: n.REQUEST,
                payload: {
                    id: t
                }
            })
        }, e.respond = function(t) {
            return o.actionWrapper({
                payload: t,
                group: i.Group.AuthCode,
                type: n.RESPOND
            })
        }
    }, function(t, e, r) {
        "use strict";

        function n(t, e, r) {
            var n = t.findIndex((function(t) {
                return t === e
            }));
            return n >= 0 && (t.splice(n, 1), r && r(e), !0)
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.removeFromCollection = e.addAndRemoveFromCollection = void 0, e.addAndRemoveFromCollection = function(t, e, r) {
            return t.push(e),
                function() {
                    return n(t, e, r)
                }
        }, e.removeFromCollection = n
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = function t(e, r) {
            if (null == r) return r;
            if (void 0 === e || !Object.getPrototypeOf(e).isPrototypeOf(r) || "Object" !== r.constructor.name && "Array" !== r.constructor.name) return r;
            var n = {};
            return Object.keys(r).forEach((function(o) {
                e.hasOwnProperty(o) ? "object" != typeof e[o] || Array.isArray(e[o]) ? n[o] = r[o] : n[o] = t(e[o], r[o]) : n[o] = r[o]
            })), Object.keys(e).forEach((function(t) {
                r.hasOwnProperty(t) || (n[t] = e[t])
            })), Object.setPrototypeOf(n, Object.getPrototypeOf(e)), n
        }
    }, function(t, e, r) {
        "use strict";

        function n(t) {
            return Array.from(t).map((function(t) {
                return ("00" + t.toString(16)).slice(-2)
            })).join("")
        }

        function o(t) {
            if ("function" == typeof Uint8Array && "object" == typeof window && window.crypto) {
                var e = new Uint8Array(t),
                    r = window.crypto.getRandomValues(e);
                if (r) return r
            }
            return Array.from(new Array(t), (function() {
                return 255 * Math.random() | 0
            }))
        }

        function i() {
            var t = o(1),
                e = o(2);
            return t[0] &= 191, e[0] &= 79, [n(o(4)), "-", n(o(2)), "-", n(e), "-", n(t), n(o(1)), "-", n(o(6))].join("")
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.generateUuid = void 0, e.generateUuid = i, e.default = i
    }, function(t) {
        t.exports = JSON.parse('{"name":"@shopify/app-bridge","version":"2.0.5","types":"index.d.ts","main":"index.js","unpkg":"umd/index.js","jsdelivr":"umd/index.js","files":["/actions/","/client/","/umd/","/util/","/validate/","/development.d.ts","/development.js","/index.d.ts","/index.js","/MessageTransport.d.ts","/MessageTransport.js","/production.d.ts","/production.js"],"private":false,"publishConfig":{"access":"public","@shopify:registry":"https://registry.npmjs.org"},"repository":"git@github.com:Shopify/app-bridge.git","homepage":"https://shopify.dev/tools/app-bridge","author":"Shopify Inc.","license":"MIT","scripts":{"build":"yarn build:tsc && yarn build:npm && yarn build:umd","build:tsc":"NODE_ENV=production tsc","build:umd":"NODE_ENV=production webpack -p","build:npm":"shx cp -r ./npm/index.js ./index.js","check":"tsc","clean":"cat package.json | node -pe \\"JSON.parse(require(\'fs\').readFileSync(\'/dev/stdin\').toString()).files.map(f => \'./\'+f).join(\' \')\\" | xargs rm -rf","pack":"yarn pack","size":"size-limit"},"sideEffects":false,"size-limit":[{"limit":"17 KB","path":"production.js"}],"dependencies":{"base64url":"^3.0.1"},"devDependencies":{"@types/node":"^10.12.5","shx":"^0.3.3"},"gitHead":"34f24f749cde5eeb742adf968895fc75a9b5391a"}')
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Cart = e.setLineItemProperties = e.removeLineItemDiscount = e.setLineItemDiscount = e.removeLineItem = e.updateLineItem = e.addLineItem = e.removeProperties = e.setProperties = e.setDiscount = e.updateCustomerAddress = e.addCustomerAddress = e.setCustomer = e.update = e.fetch = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t, e) {
            return void 0 === e && (e = {}), s.actionWrapper({
                group: c.Group.Cart,
                type: t,
                payload: e
            })
        }! function(t) {
            t.FETCH = "APP::CART::FETCH", t.UPDATE = "APP::CART::UPDATE", t.SET_CUSTOMER = "APP::CART::SET_CUSTOMER", t.REMOVE_CUSTOMER = "APP::CART::REMOVE_CUSTOMER", t.ADD_CUSTOMER_ADDRESS = "APP::CART::ADD_CUSTOMER_ADDRESS", t.UPDATE_CUSTOMER_ADDRESS = "APP::CART::UPDATE_CUSTOMER_ADDRESS", t.SET_DISCOUNT = "APP::CART::SET_DISCOUNT", t.REMOVE_DISCOUNT = "APP::CART::REMOVE_DISCOUNT", t.SET_PROPERTIES = "APP::CART::SET_PROPERTIES", t.REMOVE_PROPERTIES = "APP::CART::REMOVE_PROPERTIES", t.CLEAR = "APP::CART::CLEAR", t.ADD_LINE_ITEM = "APP::CART::ADD_LINE_ITEM", t.UPDATE_LINE_ITEM = "APP::CART::UPDATE_LINE_ITEM", t.REMOVE_LINE_ITEM = "APP::CART::REMOVE_LINE_ITEM", t.SET_LINE_ITEM_DISCOUNT = "APP::CART::SET_LINE_ITEM_DISCOUNT", t.REMOVE_LINE_ITEM_DISCOUNT = "APP::CART::REMOVE_LINE_ITEM_DISCOUNT", t.SET_LINE_ITEM_PROPERTIES = "APP::CART::SET_LINE_ITEM_PROPERTIES", t.REMOVE_LINE_ITEM_PROPERTIES = "APP::CART::REMOVE_LINE_ITEM_PROPERTIES"
        }(a = e.Action || (e.Action = {})), e.fetch = function() {
            return u(a.FETCH)
        }, e.update = function(t) {
            return u(a.UPDATE, t)
        }, e.setCustomer = function(t) {
            return u(a.SET_CUSTOMER, t)
        }, e.addCustomerAddress = function(t) {
            return u(a.ADD_CUSTOMER_ADDRESS, t)
        }, e.updateCustomerAddress = function(t) {
            return u(a.UPDATE_CUSTOMER_ADDRESS, t)
        }, e.setDiscount = function(t) {
            return u(a.SET_DISCOUNT, t)
        }, e.setProperties = function(t) {
            return u(a.SET_PROPERTIES, t)
        }, e.removeProperties = function(t) {
            return u(a.REMOVE_PROPERTIES, t)
        }, e.addLineItem = function(t) {
            return u(a.ADD_LINE_ITEM, t)
        }, e.updateLineItem = function(t) {
            return u(a.UPDATE_LINE_ITEM, t)
        }, e.removeLineItem = function(t) {
            return u(a.REMOVE_LINE_ITEM, t)
        }, e.setLineItemDiscount = function(t) {
            return u(a.SET_LINE_ITEM_DISCOUNT, t)
        }, e.removeLineItemDiscount = function(t) {
            return u(a.REMOVE_LINE_ITEM_DISCOUNT, t)
        }, e.setLineItemProperties = function(t) {
            return u(a.SET_LINE_ITEM_PROPERTIES, t)
        };
        var p = function(t) {
            function e(e, r) {
                return t.call(this, e, c.Group.Cart, c.Group.Cart, r ? r.id : void 0) || this
            }
            return o(e, t), e.prototype.dispatch = function(t, e) {
                switch (t) {
                    case a.FETCH:
                        this.dispatchCartAction(a.FETCH);
                        break;
                    case a.UPDATE:
                        this.dispatchCartAction(a.UPDATE, e);
                        break;
                    case a.SET_CUSTOMER:
                        this.dispatchCartAction(a.SET_CUSTOMER, e);
                        break;
                    case a.REMOVE_CUSTOMER:
                        this.dispatchCartAction(a.REMOVE_CUSTOMER, e);
                        break;
                    case a.ADD_CUSTOMER_ADDRESS:
                        this.dispatchCartAction(a.ADD_CUSTOMER_ADDRESS, e);
                        break;
                    case a.UPDATE_CUSTOMER_ADDRESS:
                        this.dispatchCartAction(a.UPDATE_CUSTOMER_ADDRESS, e);
                        break;
                    case a.SET_DISCOUNT:
                        this.dispatchCartAction(a.SET_DISCOUNT, e);
                        break;
                    case a.REMOVE_DISCOUNT:
                        this.dispatchCartAction(a.REMOVE_DISCOUNT, e);
                        break;
                    case a.SET_PROPERTIES:
                        this.dispatchCartAction(a.SET_PROPERTIES, e);
                        break;
                    case a.REMOVE_PROPERTIES:
                        this.dispatchCartAction(a.REMOVE_PROPERTIES, e);
                        break;
                    case a.CLEAR:
                        this.dispatchCartAction(a.CLEAR, e);
                        break;
                    case a.ADD_LINE_ITEM:
                        this.dispatchCartAction(a.ADD_LINE_ITEM, e);
                        break;
                    case a.UPDATE_LINE_ITEM:
                        this.dispatchCartAction(a.UPDATE_LINE_ITEM, e);
                        break;
                    case a.REMOVE_LINE_ITEM:
                        this.dispatchCartAction(a.REMOVE_LINE_ITEM, e);
                        break;
                    case a.SET_LINE_ITEM_DISCOUNT:
                        this.dispatchCartAction(a.SET_LINE_ITEM_DISCOUNT, e);
                        break;
                    case a.REMOVE_LINE_ITEM_DISCOUNT:
                        this.dispatchCartAction(a.REMOVE_LINE_ITEM_DISCOUNT, e);
                        break;
                    case a.SET_LINE_ITEM_PROPERTIES:
                        this.dispatchCartAction(a.SET_LINE_ITEM_PROPERTIES, e);
                        break;
                    case a.REMOVE_LINE_ITEM_PROPERTIES:
                        this.dispatchCartAction(a.REMOVE_LINE_ITEM_PROPERTIES, e)
                }
                return this
            }, e.prototype.dispatchCartAction = function(t, e) {
                this.app.dispatch(u(t, i(i({}, e), {
                    id: this.id
                })))
            }, e
        }(s.ActionSet);
        e.Cart = p, e.create = function(t, e) {
            return new p(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.initialize = e.Action = void 0;
        var n, o = r(4),
            i = r(5);
        ! function(t) {
            t.INITIALIZE = "APP::CLIENT::INITIALIZE"
        }(n = e.Action || (e.Action = {})), e.initialize = function() {
            return i.actionWrapper({
                group: o.Group.Client,
                type: n.INITIALIZE
            })
        }
    }, function(t, e, r) {
        "use strict";
        var n = this && this.__createBinding || (Object.create ? function(t, e, r, n) {
                void 0 === n && (n = r), Object.defineProperty(t, n, {
                    enumerable: !0,
                    get: function() {
                        return e[r]
                    }
                })
            } : function(t, e, r, n) {
                void 0 === n && (n = r), t[n] = e[r]
            }),
            o = this && this.__exportStar || function(t, e) {
                for (var r in t) "default" === r || e.hasOwnProperty(r) || n(e, t, r)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), o(r(61), e)
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
            return (n = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                })(t, e)
        }, function(t, e) {
            function r() {
                this.constructor = t
            }
            n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
        });
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Flash = void 0;
        var i = r(16),
            a = r(16);
        Object.defineProperty(e, "clear", {
            enumerable: !0,
            get: function() {
                return a.clear
            }
        }), Object.defineProperty(e, "show", {
            enumerable: !0,
            get: function() {
                return a.show
            }
        });
        var s = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return o(e, t), e
        }(i.Toast);
        e.Flash = s, e.create = function(t, e) {
            return new s(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n = this && this.__createBinding || (Object.create ? function(t, e, r, n) {
                void 0 === n && (n = r), Object.defineProperty(t, n, {
                    enumerable: !0,
                    get: function() {
                        return e[r]
                    }
                })
            } : function(t, e, r, n) {
                void 0 === n && (n = r), t[n] = e[r]
            }),
            o = this && this.__exportStar || function(t, e) {
                for (var r in t) "default" === r || e.hasOwnProperty(r) || n(e, t, r)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), o(r(63), e), o(r(31), e)
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Features = void 0;
        var a = r(5),
            s = r(4),
            c = r(31),
            u = function(t) {
                function e(e, r) {
                    return t.call(this, e, s.Group.Features, s.Group.Features, r ? r.id : void 0) || this
                }
                return o(e, t), e.prototype.dispatch = function(t, e) {
                    switch (t) {
                        case c.Action.REQUEST:
                            this.dispatchFeaturesAction(c.Action.REQUEST, e)
                    }
                    return this
                }, e.prototype.dispatchFeaturesAction = function(t, e) {
                    this.app.dispatch(a.actionWrapper({
                        group: s.Group.Features,
                        type: t,
                        payload: i(i({}, e || {}), {
                            id: this.id
                        })
                    }))
                }, e
            }(a.ActionSet);
        e.Features = u, e.create = function(t, e) {
            return new u(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.FeedbackModal = e.close = e.open = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t) {
            return s.actionWrapper({
                group: c.Group.FeedbackModal,
                payload: t,
                type: a.OPEN
            })
        }

        function p(t) {
            return s.actionWrapper({
                group: c.Group.FeedbackModal,
                payload: t,
                type: a.CLOSE
            })
        }! function(t) {
            t.OPEN = "APP::FEEDBACK_MODAL::OPEN", t.CLOSE = "APP::FEEDBACK_MODAL::CLOSE"
        }(a = e.Action || (e.Action = {})), e.open = u, e.close = p;
        var f = function(t) {
            function e(e, r) {
                var n = t.call(this, e, c.Group.FeedbackModal, c.Group.FeedbackModal) || this;
                return n.options = r, n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i({
                        id: this.id
                    }, this.options)
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t) {
                return this.options = s.getMergedProps(this.options, t), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.OPEN:
                        var e = u(this.payload);
                        this.app.dispatch(e);
                        break;
                    case a.CLOSE:
                        var r = p(this.payload);
                        this.app.dispatch(r)
                }
                return this
            }, e
        }(s.ActionSet);
        e.FeedbackModal = f, e.create = function(t, e) {
            return new f(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
            return (n = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                })(t, e)
        }, function(t, e) {
            function r() {
                this.constructor = t
            }
            n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
        });
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Fullscreen = e.exit = e.enter = e.Action = void 0;
        var i, a = r(5),
            s = r(4);
        ! function(t) {
            t.ENTER = "APP::FULLSCREEN::ENTER", t.EXIT = "APP::FULLSCREEN::EXIT"
        }(i = e.Action || (e.Action = {})), e.enter = function() {
            return a.actionWrapper({
                group: s.Group.Fullscreen,
                type: i.ENTER
            })
        }, e.exit = function() {
            return a.actionWrapper({
                group: s.Group.Fullscreen,
                type: i.EXIT
            })
        };
        var c = function(t) {
            function e(e) {
                return t.call(this, e, s.Group.Fullscreen, s.Group.Fullscreen) || this
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return {
                        id: this.id
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.dispatch = function(t) {
                return this.app.dispatch(a.actionWrapper({
                    group: this.group,
                    type: t,
                    payload: this.payload
                })), this
            }, e
        }(a.ActionSet);
        e.Fullscreen = c, e.create = function(t) {
            return new c(t)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.LeaveConfirmation = e.confirm = e.disable = e.enable = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t) {
            return void 0 === t && (t = {}), s.actionWrapper({
                group: c.Group.LeaveConfirmation,
                payload: t,
                type: a.ENABLE
            })
        }

        function p(t) {
            return void 0 === t && (t = {}), s.actionWrapper({
                group: c.Group.LeaveConfirmation,
                payload: t,
                type: a.DISABLE
            })
        }

        function f(t) {
            return void 0 === t && (t = {}), s.actionWrapper({
                group: c.Group.LeaveConfirmation,
                payload: t,
                type: a.CONFIRM
            })
        }! function(t) {
            t.ENABLE = "APP::LEAVE_CONFIRMATION::ENABLE", t.DISABLE = "APP::LEAVE_CONFIRMATION::DISABLE", t.CONFIRM = "APP::LEAVE_CONFIRMATION::CONFIRM"
        }(a = e.Action || (e.Action = {})), e.enable = u, e.disable = p, e.confirm = f;
        var d = function(t) {
            function e(e, r) {
                void 0 === r && (r = {});
                var n = t.call(this, e, c.Group.LeaveConfirmation, c.Group.LeaveConfirmation) || this;
                return n.options = r, n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i({
                        id: this.id
                    }, this.options)
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t) {
                return this.options = s.getMergedProps(this.options, t), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.ENABLE:
                        var e = u(this.payload);
                        this.app.dispatch(e);
                        break;
                    case a.DISABLE:
                        var r = p(this.payload);
                        this.app.dispatch(r);
                        break;
                    case a.CONFIRM:
                        var n = f(this.payload);
                        this.app.dispatch(n)
                }
                return this
            }, e
        }(s.ActionSet);
        e.LeaveConfirmation = d, e.create = function(t, e) {
            return void 0 === e && (e = {}), new d(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
            return (n = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                })(t, e)
        }, function(t, e) {
            function r() {
                this.constructor = t
            }
            n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
        });
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Loading = e.stop = e.start = e.Action = void 0;
        var i, a = r(5),
            s = r(4);

        function c(t) {
            return a.actionWrapper({
                payload: t,
                group: s.Group.Loading,
                type: i.START
            })
        }

        function u(t) {
            return a.actionWrapper({
                payload: t,
                group: s.Group.Loading,
                type: i.STOP
            })
        }! function(t) {
            t.START = "APP::LOADING::START", t.STOP = "APP::LOADING::STOP"
        }(i = e.Action || (e.Action = {})), e.start = c, e.stop = u;
        var p = function(t) {
            function e(e) {
                return t.call(this, e, s.Group.Loading, s.Group.Loading) || this
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return {
                        id: this.id
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.dispatch = function(t) {
                switch (t) {
                    case i.START:
                        this.app.dispatch(c(this.payload));
                        break;
                    case i.STOP:
                        this.app.dispatch(u(this.payload))
                }
                return this
            }, e
        }(a.ActionSet);
        e.Loading = p, e.create = function(t) {
            return new p(t)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            },
            a = this && this.__awaiter || function(t, e, r, n) {
                return new(r || (r = Promise))((function(o, i) {
                    function a(t) {
                        try {
                            c(n.next(t))
                        } catch (t) {
                            i(t)
                        }
                    }

                    function s(t) {
                        try {
                            c(n.throw(t))
                        } catch (t) {
                            i(t)
                        }
                    }

                    function c(t) {
                        var e;
                        t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                            t(e)
                        }))).then(a, s)
                    }
                    c((n = n.apply(t, e || [])).next())
                }))
            },
            s = this && this.__generator || function(t, e) {
                var r, n, o, i, a = {
                    label: 0,
                    sent: function() {
                        if (1 & o[0]) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                };
                return i = {
                    next: s(0),
                    throw: s(1),
                    return: s(2)
                }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                    return this
                }), i;

                function s(i) {
                    return function(s) {
                        return function(i) {
                            if (r) throw new TypeError("Generator is already executing.");
                            for (; a;) try {
                                if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                                switch (n = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                    case 0:
                                    case 1:
                                        o = i;
                                        break;
                                    case 4:
                                        return a.label++, {
                                            value: i[1],
                                            done: !1
                                        };
                                    case 5:
                                        a.label++, n = i[1], i = [0];
                                        continue;
                                    case 7:
                                        i = a.ops.pop(), a.trys.pop();
                                        continue;
                                    default:
                                        if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                            a = 0;
                                            continue
                                        }
                                        if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                            a.label = i[1];
                                            break
                                        }
                                        if (6 === i[0] && a.label < o[1]) {
                                            a.label = o[1], o = i;
                                            break
                                        }
                                        if (o && a.label < o[2]) {
                                            a.label = o[2], a.ops.push(i);
                                            break
                                        }
                                        o[2] && a.ops.pop(), a.trys.pop();
                                        continue
                                }
                                i = e.call(t, a)
                            } catch (t) {
                                i = [6, t], n = 0
                            } finally {
                                r = o = 0
                            }
                            if (5 & i[0]) throw i[1];
                            return {
                                value: i[0] ? i[1] : void 0,
                                done: !0
                            }
                        }([i, s])
                    }
                }
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.ModalContent = e.Action = void 0;
        var c, u = r(5),
            p = r(4),
            f = r(32);
        ! function(t) {
            t.LOADING = "LOADING", t.LOADED = "LOADED"
        }(c = e.Action || (e.Action = {}));
        var d = function(t) {
            function e(e, r) {
                return t.call(this, e, p.Group.Modal, p.Group.Modal, r ? r.id : void 0) || this
            }
            return o(e, t), e.prototype.loaded = function() {
                this.dispatch(c.LOADED)
            }, e.prototype.loading = function() {
                this.dispatch(c.LOADING)
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case c.LOADED:
                        this.dispatchModalAction(f.Action.UPDATE_CONTENT, {
                            loading: !1
                        });
                        break;
                    case c.LOADING:
                        this.dispatchModalAction(f.Action.UPDATE_CONTENT, {
                            loading: !0
                        })
                }
                return this
            }, e.prototype.dispatchModalAction = function(t, e) {
                return a(this, void 0, void 0, (function() {
                    var r;
                    return s(this, (function(n) {
                        return r = u.actionWrapper({
                            type: t,
                            group: p.Group.Modal,
                            payload: i({}, e)
                        }), this.app.dispatch(r), [2]
                    }))
                }))
            }, e
        }(u.ActionSet);
        e.ModalContent = d, e.create = function(t, e) {
            return new d(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.History = e.replace = e.push = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Navigation,
                type: a.PUSH
            })
        }

        function p(t) {
            return s.actionWrapper({
                payload: t,
                group: c.Group.Navigation,
                type: a.REPLACE
            })
        }! function(t) {
            t.PUSH = "APP::NAVIGATION::HISTORY::PUSH", t.REPLACE = "APP::NAVIGATION::HISTORY::REPLACE"
        }(a = e.Action || (e.Action = {})), e.push = u, e.replace = p;
        var f = function(t) {
            function e(e) {
                return t.call(this, e, "History", c.Group.Navigation) || this
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return {
                        id: this.id
                    }
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.dispatch = function(t, e) {
                var r = i(i({}, this.payload), {
                    path: e
                });
                switch (t) {
                    case a.PUSH:
                        this.app.dispatch(u(r));
                        break;
                    case a.REPLACE:
                        this.app.dispatch(p(r))
                }
                return this
            }, e
        }(s.ActionSet);
        e.History = f, e.create = function(t) {
            return new f(t)
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.app = e.Action = void 0;
        var n, o = r(5),
            i = r(4);
        ! function(t) {
            t.APP = "APP::PRINT::APP"
        }(n = e.Action || (e.Action = {})), e.app = function() {
            return o.actionWrapper({
                group: i.Group.Print,
                type: n.APP
            })
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.ResourcePicker = e.update = e.close = e.cancel = e.open = e.select = e.ActionVerb = e.ResourceType = e.ProductStatus = e.ProductVariantInventoryManagement = e.ProductVariantInventoryPolicy = e.WeightUnit = e.FulfillmentServiceType = e.CollectionSortOrder = e.Action = void 0;
        var a, s, c, u = r(5),
            p = r(4);

        function f(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.ResourcePicker,
                type: a.SELECT
            })
        }

        function d(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.ResourcePicker,
                type: a.OPEN
            })
        }

        function l(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.ResourcePicker,
                type: a.CANCEL
            })
        }

        function h(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.ResourcePicker,
                type: a.UPDATE
            })
        }! function(t) {
            t.OPEN = "APP::RESOURCE_PICKER::OPEN", t.SELECT = "APP::RESOURCE_PICKER::SELECT", t.CLOSE = "APP::RESOURCE_PICKER::CLOSE", t.UPDATE = "APP::RESOURCE_PICKER::UPDATE", t.CANCEL = "APP::RESOURCE_PICKER::CANCEL"
        }(a = e.Action || (e.Action = {})),
        function(t) {
            t.Manual = "MANUAL", t.BestSelling = "BEST_SELLING", t.AlphaAsc = "ALPHA_ASC", t.AlphaDesc = "ALPHA_DESC", t.PriceDesc = "PRICE_DESC", t.PriceAsc = "PRICE_ASC", t.CreatedDesc = "CREATED_DESC", t.Created = "CREATED"
        }(e.CollectionSortOrder || (e.CollectionSortOrder = {})),
        function(t) {
            t.GiftCard = "GIFT_CARD", t.Manual = "MANUAL", t.ThirdParty = "THIRD_PARTY"
        }(e.FulfillmentServiceType || (e.FulfillmentServiceType = {})),
        function(t) {
            t.Kilograms = "KILOGRAMS", t.Grams = "GRAMS", t.Pounds = "POUNDS", t.Ounces = "OUNCES"
        }(e.WeightUnit || (e.WeightUnit = {})),
        function(t) {
            t.Deny = "DENY", t.Continue = "CONTINUE"
        }(e.ProductVariantInventoryPolicy || (e.ProductVariantInventoryPolicy = {})),
        function(t) {
            t.Shopify = "SHOPIFY", t.NotManaged = "NOT_MANAGED", t.FulfillmentService = "FULFILLMENT_SERVICE"
        }(e.ProductVariantInventoryManagement || (e.ProductVariantInventoryManagement = {})),
        function(t) {
            t.Active = "ACTIVE", t.Archived = "ARCHIVED", t.Draft = "DRAFT"
        }(e.ProductStatus || (e.ProductStatus = {})),
        function(t) {
            t.Product = "product", t.ProductVariant = "variant", t.Collection = "collection"
        }(s = e.ResourceType || (e.ResourceType = {})),
        function(t) {
            t.Add = "add", t.Select = "select"
        }(c = e.ActionVerb || (e.ActionVerb = {})), e.select = f, e.open = d, e.cancel = l, e.close = function(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.ResourcePicker,
                type: a.CANCEL
            })
        }, e.update = h;
        var y = function(t) {
            function e(e, r, n) {
                var o = t.call(this, e, p.Group.ResourcePicker, p.Group.ResourcePicker) || this;
                return o.initialSelectionIds = [], o.selection = [], o.resourceType = n, o.set(r, !1), o
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        id: this.id,
                        resourceType: this.resourceType
                    })
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    var t = {
                        initialQuery: this.initialQuery,
                        selectMultiple: this.selectMultiple,
                        initialSelectionIds: this.initialSelectionIds,
                        showHidden: this.showHidden,
                        actionVerb: this.actionVerb
                    };
                    return this.resourceType === s.Product ? i(i({}, t), {
                        showVariants: this.showVariants,
                        showDraft: this.showDraft,
                        showArchived: this.showArchived,
                        showDraftBadge: this.showDraftBadge,
                        showArchivedBadge: this.showArchivedBadge
                    }) : t
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = u.getMergedProps(this.options, t),
                    n = r.initialQuery,
                    o = r.initialSelectionIds,
                    i = void 0 === o ? [] : o,
                    a = r.showHidden,
                    s = void 0 === a || a,
                    p = r.showVariants,
                    f = void 0 === p || p,
                    d = r.showDraft,
                    l = void 0 === d || d,
                    h = r.showArchived,
                    y = void 0 === h || h,
                    A = r.showDraftBadge,
                    v = void 0 !== A && A,
                    E = r.showArchivedBadge,
                    O = void 0 !== E && E,
                    P = r.selectMultiple,
                    g = void 0 === P || P,
                    b = r.actionVerb,
                    _ = void 0 === b ? c.Add : b;
                return this.initialQuery = n, this.initialSelectionIds = i, this.showHidden = s, this.showVariants = f, this.showDraft = l, this.showArchived = y, this.showDraftBadge = v, this.showArchivedBadge = O, this.selectMultiple = g, this.actionVerb = _, e && this.update(), this
            }, e.prototype.dispatch = function(t, e) {
                return t === a.OPEN ? this.open() : t === a.UPDATE ? this.update() : t === a.CLOSE || t === a.CANCEL ? this.cancel() : t === a.SELECT && (this.selection = e, this.app.dispatch(f({
                    id: this.id,
                    selection: this.selection
                }))), this
            }, e.prototype.update = function() {
                this.app.dispatch(h(this.payload))
            }, e.prototype.open = function() {
                this.app.dispatch(d(this.payload))
            }, e.prototype.cancel = function() {
                this.app.dispatch(l({
                    id: this.id
                }))
            }, e.prototype.close = function() {
                this.cancel()
            }, e
        }(u.ActionSet);
        e.ResourcePicker = y, e.create = function(t, e) {
            var r = e.resourceType,
                n = e.options;
            return new y(t, void 0 === n ? {} : n, r)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
            return (n = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                })(t, e)
        }, function(t, e) {
            function r() {
                this.constructor = t
            }
            n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
        });
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.capture = e.openCamera = e.create = e.Scanner = e.Action = void 0;
        var i, a = r(5),
            s = r(4);
        ! function(t) {
            t.OPEN_CAMERA = "APP::SCANNER::OPEN::CAMERA", t.CAPTURE = "APP::SCANNER::CAPTURE"
        }(i = e.Action || (e.Action = {}));
        var c = function(t) {
            function e(e, r) {
                return t.call(this, e, s.Group.Scanner, s.Group.Scanner, r ? r.id : void 0) || this
            }
            return o(e, t), e.prototype.dispatch = function(t) {
                switch (t) {
                    case i.OPEN_CAMERA:
                        this.dispatchScannerAction(i.OPEN_CAMERA)
                }
                return this
            }, e.prototype.dispatchScannerAction = function(t) {
                this.app.dispatch(a.actionWrapper({
                    type: t,
                    group: s.Group.Scanner,
                    payload: {
                        id: this.id
                    }
                }))
            }, e
        }(a.ActionSet);
        e.Scanner = c, e.create = function(t, e) {
            return new c(t, e)
        }, e.openCamera = function() {
            return a.actionWrapper({
                group: s.Group.Scanner,
                type: i.OPEN_CAMERA
            })
        }, e.capture = function(t) {
            return a.actionWrapper({
                group: s.Group.Scanner,
                type: i.CAPTURE,
                payload: t
            })
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.respond = e.request = e.Action = void 0;
        var n, o = r(5),
            i = r(4);
        ! function(t) {
            t.REQUEST = "APP::SESSION_TOKEN::REQUEST", t.RESPOND = "APP::SESSION_TOKEN::RESPOND"
        }(n = e.Action || (e.Action = {})), e.request = function() {
            return o.actionWrapper({
                group: i.Group.SessionToken,
                type: n.REQUEST
            })
        }, e.respond = function(t) {
            return o.actionWrapper({
                payload: t,
                group: i.Group.SessionToken,
                type: n.RESPOND
            })
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.TitleBar = e.update = e.clickBreadcrumb = e.clickActionButton = e.Action = void 0;
        var a, s = r(9),
            c = r(15),
            u = r(75),
            p = r(11),
            f = r(5),
            d = r(4);
        ! function(t) {
            t.UPDATE = "APP::TITLEBAR::UPDATE", t.BUTTON_CLICK = "APP::TITLEBAR::BUTTONS::BUTTON::CLICK", t.BUTTON_UPDATE = "APP::TITLEBAR::BUTTONS::BUTTON::UPDATE", t.BUTTON_GROUP_UPDATE = "APP::TITLEBAR::BUTTONS::BUTTONGROUP::UPDATE", t.BREADCRUMBS_CLICK = "APP::TITLEBAR::BREADCRUMBS::BUTTON::CLICK", t.BREADCRUMBS_UPDATE = "APP::TITLEBAR::BREADCRUMBS::BUTTON::UPDATE"
        }(a = e.Action || (e.Action = {}));
        var l = {
                group: d.Group.TitleBar,
                subgroups: ["Buttons"]
            },
            h = {
                group: d.Group.TitleBar,
                subgroups: ["Breadcrumbs"],
                type: d.ComponentType.Button
            };

        function y(t) {
            return f.actionWrapper({
                payload: t,
                group: d.Group.TitleBar,
                type: a.UPDATE
            })
        }
        e.clickActionButton = function(t, e) {
            var r = d.ComponentType.Button,
                n = i({
                    id: t,
                    type: r
                }, l);
            return s.clickButton(d.Group.TitleBar, n, e)
        }, e.clickBreadcrumb = function(t, e) {
            var r = i({
                id: t
            }, h);
            return s.clickButton(d.Group.TitleBar, r, e)
        }, e.update = y;
        var A = function(t) {
            function e(e, r) {
                var n = t.call(this, e, d.Group.TitleBar, d.Group.TitleBar) || this;
                return n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "buttons", {
                get: function() {
                    if (this.primary || this.secondary) return {
                        primary: this.primary,
                        secondary: this.secondary
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "buttonsOptions", {
                get: function() {
                    if (this.primaryOptions || this.secondaryOptions) return {
                        primary: this.primaryOptions,
                        secondary: this.secondaryOptions
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        breadcrumbs: this.breadcrumbsOption,
                        buttons: this.buttonsOptions,
                        title: this.title
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        breadcrumbs: this.breadcrumb,
                        buttons: this.buttons,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = f.getMergedProps(this.options, t),
                    n = r.title,
                    o = r.buttons,
                    i = r.breadcrumbs;
                return this.title = n, this.setBreadcrumbs(i), this.setPrimaryButton(o ? o.primary : void 0), this.setSecondaryButton(o ? o.secondary : void 0), e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.UPDATE:
                        this.app.dispatch(y(this.payload))
                }
                return this
            }, e.prototype.getButton = function(t, e, r) {
                return t instanceof c.ButtonGroup ? u.getGroupedButton(this, t, e, r) : p.getSingleButton(this, t, e, r)
            }, e.prototype.updatePrimaryButton = function(t) {
                this.primary && f.updateActionFromPayload(this.primary, t) && this.dispatch(a.UPDATE)
            }, e.prototype.updateSecondaryButtons = function(t) {
                if (this.secondary) {
                    var e = this.secondary.find((function(e) {
                        return e.id === t.id
                    }));
                    if (e) {
                        (c.isGroupedButtonPayload(t), f.updateActionFromPayload(e, t)) && this.dispatch(a.UPDATE)
                    }
                }
            }, e.prototype.updateBreadcrumbButton = function(t) {
                this.breadcrumb && f.updateActionFromPayload(this.breadcrumb, t) && this.dispatch(a.UPDATE)
            }, e.prototype.setPrimaryButton = function(t) {
                this.primaryOptions = this.getChildButton(t, this.primaryOptions), this.primary = this.primaryOptions ? this.getButton(this.primaryOptions, l.subgroups, this.updatePrimaryButton) : void 0
            }, e.prototype.setSecondaryButton = function(t) {
                var e = this,
                    r = t || [],
                    n = this.secondaryOptions || [];
                this.secondaryOptions = this.getUpdatedChildActions(r, n), this.secondary = this.secondaryOptions ? this.secondaryOptions.map((function(t) {
                    return e.getButton(t, l.subgroups, e.updateSecondaryButtons)
                })) : void 0
            }, e.prototype.setBreadcrumbs = function(t) {
                this.breadcrumbsOption = this.getChildButton(t, this.breadcrumbsOption), this.breadcrumb = this.breadcrumbsOption ? this.getButton(this.breadcrumbsOption, h.subgroups, this.updateBreadcrumbButton) : void 0
            }, e.prototype.getChildButton = function(t, e) {
                var r = t ? [t] : [],
                    n = e ? [e] : [],
                    o = this.getUpdatedChildActions(r, n);
                return o ? o[0] : void 0
            }, e
        }(f.ActionSetWithChildren);
        e.TitleBar = A, e.create = function(t, e) {
            return new A(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.getGroupedButton = void 0;
        var n = r(15);
        e.getGroupedButton = function(t, e, r, o) {
            t.addChild(e, t.group, r);
            var i = e.id,
                a = e.label,
                s = e.disabled,
                c = e.buttons,
                u = e.plain;
            return t.subscribeToChild(e, n.Action.UPDATE, o), {
                id: i,
                label: a,
                buttons: c,
                disabled: s,
                plain: u
            }
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.ContextualSaveBar = e.discard = e.save = e.hide = e.show = e.Action = void 0;
        var a, s = r(5),
            c = r(4);

        function u(t, e) {
            return s.actionWrapper({
                group: c.Group.ContextualSaveBar,
                type: t,
                payload: e
            })
        }! function(t) {
            t.DISCARD = "APP::CONTEXTUAL_SAVE_BAR::DISCARD", t.SAVE = "APP::CONTEXTUAL_SAVE_BAR::SAVE", t.SHOW = "APP::CONTEXTUAL_SAVE_BAR::SHOW", t.HIDE = "APP::CONTEXTUAL_SAVE_BAR::HIDE", t.UPDATE = "APP::CONTEXTUAL_SAVE_BAR::UPDATE"
        }(a = e.Action || (e.Action = {})), e.show = function(t) {
            return u(a.SHOW, t)
        }, e.hide = function(t) {
            return u(a.HIDE, t)
        }, e.save = function(t) {
            return u(a.SAVE, t)
        }, e.discard = function(t) {
            return u(a.DISCARD, t)
        };
        var p = function(t) {
            function e(e, r) {
                void 0 === r && (r = {});
                var n = t.call(this, e, c.Group.ContextualSaveBar, c.Group.ContextualSaveBar) || this;
                return n.options = r, n.set(r, !1), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i({
                        id: this.id
                    }, this.options)
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = s.getMergedProps(this.options, t);
                return this.options = r, e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                return this.app.dispatch(u(t, this.payload)), this
            }, e
        }(s.ActionSet);
        e.ContextualSaveBar = p, e.create = function(t, e) {
            return new p(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.close = e.show = e.create = e.Share = e.Action = void 0;
        var a, s = r(4),
            c = r(5);
        ! function(t) {
            t.SHOW = "APP::SHARE::SHOW", t.CLOSE = "APP::SHARE::CLOSE"
        }(a = e.Action || (e.Action = {}));
        var u = function(t) {
            function e(e) {
                return t.call(this, e, s.Group.Share, s.Group.Share) || this
            }
            return o(e, t), e.prototype.dispatch = function(t, e) {
                switch (t) {
                    case a.SHOW:
                        this.dispatchShareAction(a.SHOW, e);
                        break;
                    default:
                        throw "Action: " + t + " not supported"
                }
                return this
            }, e.prototype.dispatchShareAction = function(t, e) {
                this.app.dispatch(c.actionWrapper({
                    type: t,
                    group: s.Group.Share,
                    payload: i({
                        id: this.id
                    }, e)
                }))
            }, e
        }(c.ActionSet);
        e.Share = u, e.create = function(t) {
            return new u(t)
        }, e.show = function() {
            return c.actionWrapper({
                group: s.Group.Share,
                type: a.SHOW
            })
        }, e.close = function() {
            return c.actionWrapper({
                group: s.Group.Share,
                type: a.CLOSE
            })
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.NavigationMenu = e.update = e.Action = void 0;
        var a, s = r(17),
            c = r(5),
            u = r(4),
            p = ["Navigation_Menu"];

        function f(t) {
            return c.actionWrapper({
                payload: t,
                group: u.Group.Menu,
                type: a.UPDATE
            })
        }! function(t) {
            t.UPDATE = "APP::MENU::NAVIGATION_MENU::UPDATE", t.LINK_UPDATE = "APP::MENU::NAVIGATION_MENU::LINK::UPDATE"
        }(a = e.Action || (e.Action = {})), e.update = f;
        var d = function(t) {
            function e(e, r) {
                var n = t.call(this, e, "Navigation_Menu", u.Group.Menu) || this;
                return n.items = [], n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        items: this.itemsOptions,
                        active: this.activeOptions
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        active: this.active,
                        items: this.items,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = c.getMergedProps(this.options, t),
                    n = r.items,
                    o = r.active;
                return this.setItems(n), this.activeOptions = o, this.active = o && o.id, e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.UPDATE:
                        this.app.dispatch(f(this.payload))
                }
                return this
            }, e.prototype.updateItem = function(t) {
                if (this.items) {
                    var e = this.items.find((function(e) {
                        return e.id === t.id
                    }));
                    e && c.updateActionFromPayload(e, t) && this.dispatch(a.UPDATE)
                }
            }, e.prototype.setItems = function(t) {
                var e = this,
                    r = t || [],
                    n = this.itemsOptions || [];
                this.itemsOptions = this.getUpdatedChildActions(r, n), this.items = this.itemsOptions ? this.itemsOptions.map((function(t) {
                    return e.addChild(t, e.group, p), e.subscribeToChild(t, s.Action.UPDATE, e.updateItem), t.payload
                })) : []
            }, e
        }(c.ActionSetWithChildren);
        e.NavigationMenu = d, e.create = function(t, e) {
            return new d(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.ChannelMenu = e.update = e.Action = void 0;
        var a, s = r(17),
            c = r(5),
            u = r(4),
            p = ["Channel_Menu"];

        function f(t) {
            return c.actionWrapper({
                payload: t,
                group: u.Group.Menu,
                type: a.UPDATE
            })
        }! function(t) {
            t.UPDATE = "APP::MENU::CHANNEL_MENU::UPDATE", t.LINK_UPDATE = "APP::MENU::CHANNEL_MENU::LINK::UPDATE"
        }(a = e.Action || (e.Action = {})), e.update = f;
        var d = function(t) {
            function e(e, r) {
                var n = t.call(this, e, "Channel_Menu", u.Group.Menu) || this;
                return n.items = [], n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        items: this.itemsOptions,
                        active: this.activeOptions
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        active: this.active,
                        items: this.items,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = c.getMergedProps(this.options, t),
                    n = r.items,
                    o = r.active;
                return this.setItems(n), this.activeOptions = o, this.active = o && o.id, e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.UPDATE:
                        this.app.dispatch(f(this.payload))
                }
                return this
            }, e.prototype.updateItem = function(t) {
                if (this.items) {
                    var e = this.items.find((function(e) {
                        return e.id === t.id
                    }));
                    e && c.updateActionFromPayload(e, t) && this.dispatch(a.UPDATE)
                }
            }, e.prototype.setItems = function(t) {
                var e = this,
                    r = t || [],
                    n = this.itemsOptions || [];
                this.itemsOptions = this.getUpdatedChildActions(r, n), this.items = this.itemsOptions ? this.itemsOptions.map((function(t) {
                    return e.addChild(t, e.group, p), e.subscribeToChild(t, s.Action.UPDATE, e.updateItem), t.payload
                })) : []
            }, e
        }(c.ActionSetWithChildren);
        e.ChannelMenu = d, e.create = function(t, e) {
            return new d(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
            return (n = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                })(t, e)
        }, function(t, e) {
            function r() {
                this.constructor = t
            }
            n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
        });
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.Pos = e.close = e.Action = void 0;
        var i, a = r(5),
            s = r(4);

        function c() {
            return a.actionWrapper({
                group: s.Group.Pos,
                type: i.CLOSE
            })
        }! function(t) {
            t.CLOSE = "APP::POS::CLOSE", t.LOCATION_UPDATE = "APP::POS::LOCATION::UPDATE", t.USER_UPDATE = "APP::POS::USER::UPDATE", t.DEVICE_UPDATE = "APP::POS::DEVICE::UPDATE"
        }(i = e.Action || (e.Action = {})), e.close = c;
        var u = function(t) {
            function e(e) {
                return t.call(this, e, s.Group.Pos, s.Group.Pos) || this
            }
            return o(e, t), e.prototype.dispatch = function(t) {
                switch (t) {
                    case i.CLOSE:
                        this.app.dispatch(c())
                }
                return this
            }, e
        }(a.ActionSet);
        e.Pos = u, e.create = function(t) {
            return new u(t)
        }
    }, function(t, e, r) {
        "use strict";
        var n, o = this && this.__extends || (n = function(t, e) {
                return (n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    })(t, e)
            }, function(t, e) {
                function r() {
                    this.constructor = t
                }
                n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r)
            }),
            i = this && this.__assign || function() {
                return (i = Object.assign || function(t) {
                    for (var e, r = 1, n = arguments.length; r < n; r++)
                        for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.create = e.MarketingExternalActivityTopBar = e.update = e.clickActionButton = e.MarketingActivityStatusBadgeType = e.Action = void 0;
        var a, s = r(9),
            c = r(11),
            u = r(5),
            p = r(4);
        ! function(t) {
            t.UPDATE = "APP::MARKETING_EXTERNAL_ACTIVITY_TOP_BAR::UPDATE", t.BUTTON_CLICK = "APP::MARKETING_EXTERNAL_ACTIVITY_TOP_BAR::BUTTONS::BUTTON::CLICK", t.BUTTON_UPDATE = "APP::MARKETING_EXTERNAL_ACTIVITY_TOP_BAR::BUTTONS::BUTTON::UPDATE"
        }(a = e.Action || (e.Action = {})),
        function(t) {
            t.Default = "DEFAULT", t.Success = "SUCCESS", t.Attention = "ATTENTION", t.Warning = "WARNING", t.Info = "INFO"
        }(e.MarketingActivityStatusBadgeType || (e.MarketingActivityStatusBadgeType = {}));
        var f = {
            group: p.Group.MarketingExternalActivityTopBar,
            subgroups: ["Buttons"]
        };

        function d(t) {
            return u.actionWrapper({
                payload: t,
                group: p.Group.MarketingExternalActivityTopBar,
                type: a.UPDATE
            })
        }
        e.clickActionButton = function(t, e) {
            var r = p.ComponentType.Button,
                n = i({
                    id: t,
                    type: r
                }, f);
            return s.clickButton(p.Group.MarketingExternalActivityTopBar, n, e)
        }, e.update = d;
        var l = function(t) {
            function e(e, r) {
                var n = t.call(this, e, p.Group.MarketingExternalActivityTopBar, p.Group.MarketingExternalActivityTopBar) || this;
                return n.set(r), n
            }
            return o(e, t), Object.defineProperty(e.prototype, "buttons", {
                get: function() {
                    if (this.primary || this.secondary) return {
                        primary: this.primary,
                        secondary: this.secondary
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "buttonsOptions", {
                get: function() {
                    if (this.primaryOptions || this.secondaryOptions) return {
                        primary: this.primaryOptions,
                        secondary: this.secondaryOptions
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return {
                        title: this.title,
                        status: this.status,
                        saving: this.saving,
                        saved: this.saved,
                        buttons: this.buttonsOptions
                    }
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "payload", {
                get: function() {
                    return i(i({}, this.options), {
                        buttons: this.buttons,
                        id: this.id
                    })
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.set = function(t, e) {
                void 0 === e && (e = !0);
                var r = u.getMergedProps(this.options, t),
                    n = r.title,
                    o = r.buttons,
                    i = r.saved,
                    s = r.saving,
                    c = r.status;
                return this.title = n, this.saving = s, this.saved = i, this.status = c, this.setPrimaryButton(o ? o.primary : void 0), this.setSecondaryButtons(o ? o.secondary : void 0), e && this.dispatch(a.UPDATE), this
            }, e.prototype.dispatch = function(t) {
                switch (t) {
                    case a.UPDATE:
                        this.app.dispatch(d(this.payload))
                }
                return this
            }, e.prototype.getButton = function(t, e, r) {
                return c.getSingleButton(this, t, e, r)
            }, e.prototype.updatePrimaryButton = function(t) {
                this.primary && u.updateActionFromPayload(this.primary, t) && this.dispatch(a.UPDATE)
            }, e.prototype.updateSecondaryButtons = function(t) {
                if (this.secondary) {
                    var e = this.secondary.find((function(e) {
                        return e.id === t.id
                    }));
                    if (e) u.updateActionFromPayload(e, t) && this.dispatch(a.UPDATE)
                }
            }, e.prototype.setPrimaryButton = function(t) {
                this.primaryOptions = this.getChildButton(t, this.primaryOptions), this.primary = this.primaryOptions ? this.getButton(this.primaryOptions, f.subgroups, this.updatePrimaryButton) : void 0
            }, e.prototype.setSecondaryButtons = function(t) {
                var e = this,
                    r = t || [],
                    n = this.secondaryOptions || [];
                this.secondaryOptions = this.getUpdatedChildActions(r, n), this.secondary = this.secondaryOptions ? this.secondaryOptions.map((function(t) {
                    return e.getButton(t, f.subgroups, e.updateSecondaryButtons)
                })) : void 0
            }, e.prototype.updateSaving = function(t) {
                this.saving = t, this.dispatch(a.UPDATE)
            }, e.prototype.updateSaved = function(t) {
                this.saved = t, this.dispatch(a.UPDATE)
            }, e.prototype.updateStatus = function(t) {
                this.status = t, this.dispatch(a.UPDATE)
            }, e.prototype.getChildButton = function(t, e) {
                var r = t ? [t] : [],
                    n = e ? [e] : [],
                    o = this.getUpdatedChildActions(r, n);
                return o ? o[0] : void 0
            }, e
        }(u.ActionSetWithChildren);
        e.MarketingExternalActivityTopBar = l, e.create = function(t, e) {
            return new l(t, e)
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.fullPageLoad = e.skeletonPageLoad = e.Action = void 0;
        var n, o = r(4),
            i = r(5);
        ! function(t) {
            t.SKELETON_PAGE_LOAD = "APP::PERFORMANCE::SKELETON_PAGE_LOAD", t.FULL_PAGE_LOAD = "APP::PERFORMANCE::FULL_PAGE_LOAD"
        }(n = e.Action || (e.Action = {})), e.skeletonPageLoad = function() {
            return i.actionWrapper({
                group: o.Group.Performance,
                type: n.SKELETON_PAGE_LOAD
            })
        }, e.fullPageLoad = function() {
            return i.actionWrapper({
                group: o.Group.Performance,
                type: n.FULL_PAGE_LOAD
            })
        }
    }, function(t, e, r) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.isAppMessage = e.isPermitted = e.getPermissionKey = e.isFromApp = e.isAppBridgeAction = void 0;
        var n = r(28),
            o = r(30),
            i = r(5);

        function a(t) {
            return t.replace(new RegExp("^" + o.PREFIX + o.SEPARATOR + "\\w+" + o.SEPARATOR), "")
        }
        e.isAppBridgeAction = function(t) {
            return t instanceof Object && t.hasOwnProperty("type") && t.type.toString().startsWith(o.PREFIX)
        }, e.isFromApp = function(t) {
            return "object" == typeof t && "object" == typeof t.source && "string" == typeof t.source.apiKey
        }, e.getPermissionKey = a, e.isPermitted = function(t, e, r) {
            var n = e.group,
                o = e.type;
            if (!n || !t.hasOwnProperty(n)) return !1;
            var i = t[n];
            if (!i) return !1;
            var s = a(o);
            return !!i[s] && !0 === i[s][r]
        }, e.isAppMessage = function(t) {
            if ("object" != typeof t || !t.data || "object" != typeof t.data) return !1;
            var e = t.data;
            return e.hasOwnProperty("type") && void 0 !== i.findMatchInEnum(n.MessageType, e.type)
        }
    }, function(t, e, r) {
        "use strict";
        r.r(e);
        var n = r(1),
            o = r.n(n),
            i = r(3);

        function a(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        }

        function s(t, e) {
            for (var r = 0; r < e.length; r++) {
                var n = e[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
            }
        }

        function c(t, e, r) {
            return e && s(t.prototype, e), r && s(t, r), t
        }
        var u = r(2),
            p = r(0);

        function f(t, e) {
            var r = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (!r) {
                if (Array.isArray(t) || (r = function(t, e) {
                        if (!t) return;
                        if ("string" == typeof t) return d(t, e);
                        var r = Object.prototype.toString.call(t).slice(8, -1);
                        "Object" === r && t.constructor && (r = t.constructor.name);
                        if ("Map" === r || "Set" === r) return Array.from(t);
                        if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return d(t, e)
                    }(t)) || e && t && "number" == typeof t.length) {
                    r && (t = r);
                    var n = 0,
                        o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return n >= t.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: t[n++]
                            }
                        },
                        e: function(t) {
                            throw t
                        },
                        f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var i, a = !0,
                s = !1;
            return {
                s: function() {
                    r = r.call(t)
                },
                n: function() {
                    var t = r.next();
                    return a = t.done, t
                },
                e: function(t) {
                    s = !0, i = t
                },
                f: function() {
                    try {
                        a || null == r.return || r.return()
                    } finally {
                        if (s) throw i
                    }
                }
            }
        }

        function d(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
            return n
        }

        function l(t) {
            var e = v(t);
            return p.l.GIFT_CARD_RE.test(e)
        }
        var h = function() {
                function t(e) {
                    var r = this;
                    a(this, t), Object(u.a)(this, "widgetPageConfig", void 0), Object(u.a)(this, "getAmount", (function() {
                        return afterpay_cart_total_price
                    })), Object(u.a)(this, "getNewAmount", Object(i.a)(o.a.mark((function t() {
                        var e;
                        return o.a.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.prev = 0, t.next = 3, r.getCartJson();
                                case 3:
                                    return e = t.sent, t.abrupt("return", e.total_price);
                                case 7:
                                    return t.prev = 7, t.t0 = t.catch(0), t.abrupt("return", r.getPriceFromHTML());
                                case 10:
                                case "end":
                                    return t.stop()
                            }
                        }), t, null, [
                            [0, 7]
                        ])
                    })))), Object(u.a)(this, "hasLiquidVariables", (function() {
                        var t;
                        return "number" == typeof(null === (t = window) || void 0 === t ? void 0 : t.afterpay_cart_total_price)
                    })), Object(u.a)(this, "shouldShow", (function() {
                        return r.hasLiquidVariables() && r.widgetPageConfig.status === p.i.ACTIVE
                    })), Object(u.a)(this, "getCartJson", (function() {
                        return fetch("/cart.json", {
                            method: "GET",
                            headers: {
                                "Content-Type": "application/json"
                            }
                        }).then((function(t) {
                            return t.json()
                        })).then((function(t) {
                            return t
                        }))
                    })), this.widgetPageConfig = e
                }
                var e;
                return c(t, [{
                    key: "isGiftCard",
                    value: (e = Object(i.a)(o.a.mark((function t() {
                        var e, r, n, i;
                        return o.a.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.prev = 0, t.next = 3, this.getCartJson();
                                case 3:
                                    e = t.sent, t.next = 9;
                                    break;
                                case 6:
                                    return t.prev = 6, t.t0 = t.catch(0), t.abrupt("return", !1);
                                case 9:
                                    if (!e || !e.items) {
                                        t.next = 27;
                                        break
                                    }
                                    r = f(e.items), t.prev = 11, r.s();
                                case 13:
                                    if ((n = r.n()).done) {
                                        t.next = 19;
                                        break
                                    }
                                    if (i = n.value, a = void 0, s = void 0, c = void 0, u = void 0, p = void 0, a = (o = i).title, s = o.product_title, c = o.product_type, u = o.gift_card, p = [a, s, c].filter(Boolean).some(l), !u && !p) {
                                        t.next = 17;
                                        break
                                    }
                                    return t.abrupt("return", !0);
                                case 17:
                                    t.next = 13;
                                    break;
                                case 19:
                                    t.next = 24;
                                    break;
                                case 21:
                                    t.prev = 21, t.t1 = t.catch(11), r.e(t.t1);
                                case 24:
                                    return t.prev = 24, r.f(), t.finish(24);
                                case 27:
                                    return t.abrupt("return", !1);
                                case 28:
                                case "end":
                                    return t.stop()
                            }
                            var o, a, s, c, u, p
                        }), t, this, [
                            [0, 6],
                            [11, 21, 24, 27]
                        ])
                    }))), function() {
                        return e.apply(this, arguments)
                    })
                }, {
                    key: "getPriceFromHTML",
                    value: function() {
                        var t, e, r = this.widgetPageConfig.mutationObserverSelector.observerTarget;
                        return e = r, 100 * (t = document.querySelector(e).innerText, Number(t.replace(/[^0-9.]/g, "")))
                    }
                }]), t
            }(),
            y = function() {
                function t(e) {
                    a(this, t), Object(u.a)(this, "widgetPageConfig", void 0), Object(u.a)(this, "hasLiquidVariables", (function() {
                        var t;
                        return Boolean(null === (t = window) || void 0 === t ? void 0 : t.afterpay_product)
                    })), this.widgetPageConfig = e
                }
                var e;
                return c(t, [{
                    key: "getAmount",
                    value: function() {
                        var t;
                        return this.getProductVariantPrice() || (null === (t = afterpay_product) || void 0 === t ? void 0 : t.price)
                    }
                }, {
                    key: "getNewAmount",
                    value: (e = Object(i.a)(o.a.mark((function t() {
                        return o.a.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.abrupt("return", this.getAmount());
                                case 1:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    }))), function() {
                        return e.apply(this, arguments)
                    })
                }, {
                    key: "isGiftCard",
                    value: function() {
                        var t, e;
                        return p.l.GIFT_CARD_RE.test(v(null === (t = afterpay_product) || void 0 === t ? void 0 : t.type)) || p.l.GIFT_CARD_RE.test(v(null === (e = afterpay_product) || void 0 === e ? void 0 : e.title))
                    }
                }, {
                    key: "shouldShow",
                    value: function() {
                        return this.hasLiquidVariables() && this.isAvailable() && this.widgetPageConfig.status === p.i.ACTIVE
                    }
                }, {
                    key: "isAvailable",
                    value: function() {
                        var t = this.getProductVariantId();
                        if (t) {
                            var e, r = f(afterpay_product.variants);
                            try {
                                for (r.s(); !(e = r.n()).done;) {
                                    var n = e.value;
                                    if (Number(t) === n.id) return n.available
                                }
                            } catch (t) {
                                r.e(t)
                            } finally {
                                r.f()
                            }
                        }
                        return afterpay_product.available
                    }
                }, {
                    key: "getProductVariantId",
                    value: function() {
                        return new URLSearchParams(window.location.search).get("variant")
                    }
                }, {
                    key: "getProductVariantPrice",
                    value: function() {
                        var t, e, r, n = this.getProductVariantId();
                        if (n) {
                            var o, i, a = f(null === (o = afterpay_product) || void 0 === o ? void 0 : o.variants);
                            try {
                                for (a.s(); !(i = a.n()).done;) {
                                    var s = i.value;
                                    if (Number(n) === (null == s ? void 0 : s.id)) return null == s ? void 0 : s.price
                                }
                            } catch (t) {
                                a.e(t)
                            } finally {
                                a.f()
                            }
                        }
                        return null !== (t = null === (e = window) || void 0 === e || null === (r = e.afterpay_product_variant) || void 0 === r ? void 0 : r.price) && void 0 !== t ? t : null
                    }
                }]), t
            }(),
            A = r(7),
            v = function(t) {
                return t.replace(/\s/g, "").toLowerCase()
            };

        function E() {
            var t = window,
                e = t.location,
                r = t.innerWidth,
                n = e.pathname,
                o = r < 600,
                i = function(t) {
                    return /^\/s|(collections|products|srcdoc)/i.test(t)
                }(n),
                a = function(t) {
                    return /^\/s|(cart|srcdoc)/i.test(t)
                }(n),
                s = null;
            return i ? s = o ? p.h.MOBILE_PRODUCT : p.h.PRODUCT : a && (s = o ? p.h.MOBILE_STATIC_CART : p.h.STATIC_CART), s
        }

        function O(t) {
            return t.currency.active
        }

        function P(t) {
            return g.apply(this, arguments)
        }

        function g() {
            return (g = Object(i.a)(o.a.mark((function t(e) {
                var r, n, i;
                return o.a.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return r = e || Shopify.theme.id, n = "".concat(p.g, "/theme-id/").concat(r, ".json"), t.next = 4, fetch(n, {
                                cache: "no-cache"
                            });
                        case 4:
                            return i = t.sent, t.abrupt("return", !!i.ok && i.json());
                        case 6:
                        case "end":
                            return t.stop()
                    }
                }), t)
            })))).apply(this, arguments)
        }

        function b(t) {
            return function(t) {
                var e = t.status,
                    r = t.priceSelector,
                    n = e === p.i.DRAFT && Boolean(r),
                    o = e === p.i.DRAFT && !r;
                if (n) return p.i.DRAFT;
                if (o || e === p.i.INITIAL) return p.i.INITIAL;
                if (e === p.i.ACTIVE) return p.i.ACTIVE;
                return null
            }(t) === p.i.ACTIVE
        }

        function _(t, e) {
            var r = null;
            return Object(A.d)(t) ? r = new y(e) : Object(A.c)(t) && (r = new h(e)), r
        }

        function T(t) {
            var e = t.locale,
                r = t.country;
            return "".concat(e, "-").concat(r)
        }
        r(14), r(18);
        var m = r(12),
            S = r(8),
            I = function() {
                function t(e) {
                    var r = e.src,
                        n = e.global,
                        o = e.protocol,
                        i = void 0 === o ? document.location.protocol : o,
                        s = e.targetWindow;
                    a(this, t), Object(u.a)(this, "src", void 0), Object(u.a)(this, "protocol", void 0), Object(u.a)(this, "global", void 0), Object(u.a)(this, "targetWindow", void 0), Object(u.a)(this, "isLoaded", void 0), this.src = r, this.global = n, this.protocol = i, this.targetWindow = s, this.isLoaded = !1
                }
                return c(t, [{
                    key: "loadScript",
                    value: function() {
                        var t = this,
                            e = this.targetWindow.document;
                        return new Promise((function(r, n) {
                            var o = e.createElement("script");
                            o.type = "text/javascript", o.async = !0, o.src = "".concat(t.protocol, "//").concat(t.src), e.body.appendChild(o), o.addEventListener("load", (function() {
                                t.isLoaded = !0, r(o)
                            })), o.addEventListener("error", (function() {
                                n(new Error("".concat(t.src, " failed to load.")))
                            }))
                        }))
                    }
                }, {
                    key: "load",
                    value: function() {
                        var t = this;
                        return new Promise((function(e, r) {
                            t.isLoaded ? e(t.targetWindow[t.global]) : (window.addEventListener("Square.Marketplace.ready", (function() {
                                e(t.targetWindow[t.global])
                            })), t.loadScript().catch(r))
                        }))
                    }
                }]), t
            }();

        function C(t, e) {
            var r = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t);
                e && (n = n.filter((function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }))), r.push.apply(r, n)
            }
            return r
        }

        function R(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = null != arguments[e] ? arguments[e] : {};
                e % 2 ? C(Object(r), !0).forEach((function(e) {
                    Object(u.a)(t, e, r[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : C(Object(r)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                }))
            }
            return t
        }

        function N(t) {
            return w.apply(this, arguments)
        }

        function w() {
            return (w = Object(i.a)(o.a.mark((function t(e) {
                var r, n;
                return o.a.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return r = new I({
                                src: "js.squarecdn.com/square-marketplace.js",
                                global: "Afterpay",
                                targetWindow: e
                            }), t.next = 3, r.load();
                        case 3:
                            return n = t.sent, t.abrupt("return", n);
                        case 5:
                        case "end":
                            return t.stop()
                    }
                }), t)
            })))).apply(this, arguments)
        }

        function D(t) {
            var e = t.myshopifyDomain,
                r = t.currency,
                n = t.isGiftCard,
                o = t.isPaymentAmountBold,
                i = t.locale,
                a = t.logoOptions,
                s = t.price,
                c = t.platform,
                p = function(t, e) {
                    var r;
                    return (r = {}, Object(u.a)(r, m.a.COLOR, {
                        logoType: t.logoType.COMPACT_BADGE,
                        badgeTheme: t.theme.badge.BLACK_ON_MINT
                    }), Object(u.a)(r, m.a.BLACK, {
                        logoType: t.logoType.LOCKUP,
                        lockupTheme: t.theme.lockup.BLACK
                    }), Object(u.a)(r, m.a.WHITE, {
                        logoType: t.logoType.LOCKUP,
                        lockupTheme: t.theme.lockup.WHITE
                    }), r)[e]
                }(t.implementation, a.color),
                f = s / 100;
            return {
                targetSelector: "",
                attributes: R(R({
                    currency: r,
                    platform: c,
                    mpid: e,
                    consumerLocale: i.replace("-", "_"),
                    amount: f,
                    paymentAmountIsBold: o,
                    isEligible: !n
                }, p), {}, {
                    showLowerLimit: M
                })
            }
        }
        var M = !0;

        function L(t, e, r) {
            for (var n = e, o = Object.entries(r), i = r.fontSize, a = 0, s = o; a < s.length; a++) {
                var c = Object(S.a)(s[a], 2),
                    u = c[0],
                    p = c[1];
                n.style[u] = p
            }
            var f = n.shadowRoot.querySelector(".afterpay-paragraph");
            if (f && (f.style.fontSize = i), i.endsWith("px")) {
                var d = function(t) {
                    var e = parseInt(t, 10);
                    return "".concat(5 * e + 8, "px")
                }(i);
                t.documentElement.style.setProperty("--logo-badge-width", d)
            }
        }

        function j(t, e) {
            var r = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t);
                e && (n = n.filter((function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }))), r.push.apply(r, n)
            }
            return r
        }

        function U(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = null != arguments[e] ? arguments[e] : {};
                e % 2 ? j(Object(r), !0).forEach((function(e) {
                    Object(u.a)(t, e, r[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : j(Object(r)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                }))
            }
            return t
        }
        var B, G = {
            isGiftCard: !1,
            isPaymentAmountBold: !1,
            logoOptions: {
                color: m.a.COLOR
            }
        };

        function x(t) {
            var e = null,
                r = U(U({}, G), t);

            function n() {
                var t = r,
                    n = t.attachElement,
                    o = t.messagingStyles,
                    i = t.targetDocument;
                e = function(t) {
                    var e = D(t).attributes,
                        r = t.targetDocument.createElement("square-placement");
                    return Object.keys(e).forEach((function(t) {
                        r.dataset[t] = e[t]
                    })), r
                }(r), n.insertAdjacentElement("afterend", e), L(i, e, o)
            }
            return {
                render: n,
                getPrice: function() {
                    return r.price
                },
                hide: function() {
                    e.style.display = "none"
                },
                show: function() {
                    e.style.display = "block"
                },
                update: function(t) {
                    var o;
                    r = U(U({}, r), t), null === (o = e) || void 0 === o || o.remove(), n()
                }
            }
        }! function(t) {
            t.EN_AU = "en-AU", t.EN_CA = "en-CA", t.EN_ES = "en-ES", t.EN_FR = "en-FR", t.EN_GB = "en-GB", t.EN_IT = "en-IT", t.EN_NZ = "en-NZ", t.EN_US = "en-US", t.ES_ES = "es-ES", t.FR_CA = "fr-CA", t.FR_FR = "fr-FR", t.IT_IT = "it-IT"
        }(B || (B = {}));
        B.EN_US, B.EN_GB;
        var k, F, V = Object.values(B);
        B.EN_AU, B.EN_NZ, B.EN_CA, B.FR_CA, B.EN_US, B.EN_ES, B.EN_FR, B.EN_GB, B.EN_IT, B.ES_ES, B.FR_FR, B.IT_IT;
        ! function(t) {
            t.US = "US", t.CA = "CA", t.AU = "AU", t.NZ = "NZ", t.GB = "GB", t.ES = "ES", t.FR = "FR", t.IT = "IT"
        }(k || (k = {})),
        function(t) {
            t.NA = "NA", t.OC = "OC", t.EU = "EU"
        }(F || (F = {}));
        var W, H = {
                name: "Australia",
                code: k.AU
            },
            K = {
                name: "Canada",
                code: k.CA
            },
            q = (k.FR, k.IT, {
                name: "New Zealand",
                code: k.NZ
            });
        k.ES, k.GB, k.US;
        ! function(t) {
            t.AUD = "AUD", t.CAD = "CAD", t.EUR = "EUR", t.GBP = "GBP", t.NZD = "NZD", t.USD = "USD"
        }(W || (W = {}));
        var z = Object.values(W);

        function X(t, e) {
            var r = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t);
                e && (n = n.filter((function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }))), r.push.apply(r, n)
            }
            return r
        }

        function Y(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = null != arguments[e] ? arguments[e] : {};
                e % 2 ? X(Object(r), !0).forEach((function(e) {
                    Object(u.a)(t, e, r[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : X(Object(r)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                }))
            }
            return t
        }
        var Q = function() {
            function t() {
                a(this, t), Object(u.a)(this, "messaging", void 0), Object(u.a)(this, "widgetConfig", void 0), Object(u.a)(this, "pageProperties", void 0), Object(u.a)(this, "Shopify", void 0), Object(u.a)(this, "widgetPage", void 0), this.messaging = null, this.widgetConfig = null, this.pageProperties = null, this.Shopify = null, this.widgetPage = null
            }
            var e, r, n, s, p;
            return c(t, [{
                key: "init",
                value: (p = Object(i.a)(o.a.mark((function t() {
                    return o.a.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (t.prev = 0, !this.isValidShopifyEnvironment()) {
                                    t.next = 4;
                                    break
                                }
                                return t.next = 4, this._init({
                                    Shopify: window.Shopify,
                                    widgetPage: E()
                                });
                            case 4:
                                t.next = 9;
                                break;
                            case 6:
                                t.prev = 6, t.t0 = t.catch(0), console.warn("Afterpay: messaging couldn't be initialized: ", t.t0);
                            case 9:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [0, 6]
                    ])
                }))), function() {
                    return p.apply(this, arguments)
                })
            }, {
                key: "isValidShopifyEnvironment",
                value: function() {
                    if (!window.Shopify) return console.warn("Afterpay: messaging should be loaded onto a Shopify store"), !1;
                    if (null === E()) return console.log("Afterpay: messaging cannot be shown on this page"), !1;
                    if (t = O(window.Shopify), !z.includes(t)) return console.log("Afterpay: store's currency is not supported, it must be one of these: ", z), !1;
                    var t, e, r = T(window.Shopify);
                    return e = r, !!V.includes(e) || (console.log("Afterpay: the locale, ".concat(r, ", is not supported")), !1)
                }
            }, {
                key: "_init",
                value: (s = Object(i.a)(o.a.mark((function t(e) {
                    var r, n, i, a;
                    return o.a.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return r = e.Shopify, n = e.widgetPage, this.Shopify = r, this.widgetPage = n, t.next = 5, this.fetchWidgetConfig();
                            case 5:
                                if (i = t.sent) {
                                    t.next = 9;
                                    break
                                }
                                return console.log("Afterpay: we couldn't find configurations for this theme"), t.abrupt("return");
                            case 9:
                                if (this.widgetConfig = i, b(this.getPageConfig())) {
                                    t.next = 13;
                                    break
                                }
                                return console.log("Afterpay: messaging has not been published for this page"), t.abrupt("return");
                            case 13:
                                return this.pageProperties = _(this.widgetPage, this.getPageConfig()), t.next = 16, this.getInitialRenderContext();
                            case 16:
                                a = t.sent, this.messaging = x(a), this.messaging.render(), o = void 0, s = void 0, c = void 0, (c = document.createElement("style")).innerHTML = "\n    .afterpay-paragraph {\n      display: none !important;\n      visibility: hidden !important;\n    }\n  ", null === (o = document) || void 0 === o || null === (s = o.head) || void 0 === s || s.appendChild(c), this.shouldUseObserver() && this.initializeObserver(), this.pageProperties.shouldShow() || this.messaging.hide();
                            case 22:
                            case "end":
                                return t.stop()
                        }
                        var o, s, c
                    }), t, this)
                }))), function(t) {
                    return s.apply(this, arguments)
                })
            }, {
                key: "getPageConfig",
                value: function() {
                    return this.widgetConfig[this.widgetPage]
                }
            }, {
                key: "fetchWidgetConfig",
                value: (n = Object(i.a)(o.a.mark((function t() {
                    var e;
                    return o.a.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = this.Shopify.theme.id, t.abrupt("return", P(e));
                            case 2:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return n.apply(this, arguments)
                })
            }, {
                key: "getAttachElement",
                value: function() {
                    var t = this.getPageConfig().priceSelector;
                    return document.querySelector(t)
                }
            }, {
                key: "getInitialRenderContext",
                value: (r = Object(i.a)(o.a.mark((function t() {
                    var e, r, n, i, a, s, c, u, p;
                    return o.a.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, N(window);
                            case 2:
                                return e = t.sent, r = this.getAttachElement(), n = T(this.Shopify), i = O(this.Shopify), a = this.Shopify.shop, s = "shopify-app-vintage", c = this.pageProperties.getAmount(), t.next = 11, this.pageProperties.isGiftCard();
                            case 11:
                                return u = t.sent, o = this.getPageConfig(), f = void 0, f = Object(A.b)(o), p = {
                                    messagingStyles: function(t) {
                                        var e = t.afterpayFontFamily,
                                            r = t.afterpayTextAlign,
                                            n = t.afterpayTextColor,
                                            o = t.afterpayTextSize,
                                            i = t.afterpayMarginBottom,
                                            a = t.afterpayMarginLeft,
                                            s = t.afterpayMarginRight;
                                        return {
                                            color: n,
                                            fontFamily: e,
                                            fontSize: o,
                                            textAlign: r,
                                            marginTop: t.afterpayMarginTop,
                                            marginRight: s,
                                            marginBottom: i,
                                            marginLeft: a
                                        }
                                    }(f),
                                    logoOptions: {
                                        color: f.afterpayLogoColor
                                    },
                                    isPaymentAmountBold: f.afterpayBoldInstallmentAmount
                                }, t.abrupt("return", Y({
                                    targetDocument: window.document,
                                    implementation: e,
                                    attachElement: r,
                                    myshopifyDomain: a,
                                    locale: n,
                                    currency: i,
                                    price: c,
                                    isGiftCard: u,
                                    platform: s
                                }, p));
                            case 14:
                            case "end":
                                return t.stop()
                        }
                        var o, f
                    }), t, this)
                }))), function() {
                    return r.apply(this, arguments)
                })
            }, {
                key: "getMerchant",
                value: function() {
                    return this.widgetConfig.shop
                }
            }, {
                key: "shouldUseObserver",
                value: function() {
                    var t = this.getPageConfig().mutationObserverSelector,
                        e = t.activated,
                        r = t.observerTarget,
                        n = Boolean(r);
                    return e && n
                }
            }, {
                key: "initializeObserver",
                value: (e = Object(i.a)(o.a.mark((function t() {
                    var e, r, n, a, s, c, u = this;
                    return o.a.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                e = function() {
                                    var t = Object(i.a)(o.a.mark((function t() {
                                        var e, r;
                                        return o.a.wrap((function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return t.next = 2, u.pageProperties.getNewAmount();
                                                case 2:
                                                    if ((e = t.sent) && u.messaging.getPrice() !== e) {
                                                        t.next = 6;
                                                        break
                                                    }
                                                    return t.abrupt("return");
                                                case 6:
                                                    return t.next = 8, u.pageProperties.isGiftCard();
                                                case 8:
                                                    r = t.sent, u.messaging.update({
                                                        price: e,
                                                        isGiftCard: r
                                                    }), u.pageProperties.shouldShow() ? u.messaging.show() : u.messaging.hide();
                                                case 11:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t)
                                    })));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }(), r = this.getPageConfig(), n = r.mutationObserverSelector, a = n.observerTarget, s = document.querySelector(a), c = {
                                    attributes: !1,
                                    childList: !0,
                                    subtree: !0,
                                    characterData: !0
                                }, "undefined" != typeof MutationObserver && s ? new MutationObserver(e).observe(s, c) : console.warn("Afterpay: we couldn't initialize an observer, price updates won't be reflected");
                            case 6:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return e.apply(this, arguments)
                })
            }]), t
        }();
        Object(i.a)(o.a.mark((function t() {
            var e;
            return o.a.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (e = function() {
                                "preview" !== window.name && (window.currentAfterpayAttractWidget = new Q, window.currentAfterpayAttractWidget.init(), window.afterpayAttractWidget = Q)
                            }, "loading" !== document.readyState) {
                            t.next = 5;
                            break
                        }
                        document.addEventListener("DOMContentLoaded", e), t.next = 7;
                        break;
                    case 5:
                        return t.next = 7, e();
                    case 7:
                    case "end":
                        return t.stop()
                }
            }), t)
        })))()
    }])
}));