import {
    g as e,
    T as n
} from "./jsxRuntime.module-s_rKrABX.js";
const l = e("installments-fields"),
    o = e("user");

function t() {
    return n((() => {
        var e;
        return {
            userFound: Boolean(o && Object.keys(o).length > 0),
            prequalifiedAmount: null == (e = null == l ? void 0 : l.prequalification) ? void 0 : e.prequalified_amount,
            userInstallmentsOnboarded: Boolean(null == o ? void 0 : o.installments_onboarded)
        }
    }), [])
}
export {
    t as u
};