var e, n, t, _, r, o, u, i, l, c, a, f, s, p = {},
    d = [],
    h = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
    v = Array.isArray;

function m(e, n) {
    for (var t in n) e[t] = n[t];
    return e
}

function y(e) {
    e && e.parentNode && e.parentNode.removeChild(e)
}

function b(n, t, _) {
    var r, o, u, i = {};
    for (u in t) "key" == u ? r = t[u] : "ref" == u ? o = t[u] : i[u] = t[u];
    if (arguments.length > 2 && (i.children = arguments.length > 3 ? e.call(arguments, 2) : _), "function" == typeof n && null != n.defaultProps)
        for (u in n.defaultProps) null == i[u] && (i[u] = n.defaultProps[u]);
    return g(n, i, r, o, null)
}

function g(e, _, r, o, u) {
    var i = {
        type: e,
        props: _,
        key: r,
        ref: o,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __c: null,
        constructor: void 0,
        __v: null == u ? ++t : u,
        __i: -1,
        __u: 0
    };
    return null == u && null != n.vnode && n.vnode(i), i
}

function k() {
    return {
        current: null
    }
}

function C(e) {
    return e.children
}

function w(e, n) {
    this.props = e, this.context = n
}

function E(e, n) {
    if (null == n) return e.__ ? E(e.__, e.__i + 1) : null;
    for (var t; n < e.__k.length; n++)
        if (null != (t = e.__k[n]) && null != t.__e) return t.__e;
    return "function" == typeof e.type ? E(e) : null
}

function S(e) {
    var n, t;
    if (null != (e = e.__) && null != e.__c) {
        for (e.__e = e.__c.base = null, n = 0; n < e.__k.length; n++)
            if (null != (t = e.__k[n]) && null != t.__e) {
                e.__e = e.__c.base = t.__e;
                break
            }
        return S(e)
    }
}

function P(e) {
    (!e.__d && (e.__d = !0) && r.push(e) && !x.__r++ || o != n.debounceRendering) && ((o = n.debounceRendering) || u)(x)
}

function x() {
    for (var e, t, _, o, u, l, c, a = 1; r.length;) r.length > a && r.sort(i), e = r.shift(), a = r.length, e.__d && (_ = void 0, u = (o = (t = e).__v).__e, l = [], c = [], t.__P && ((_ = m({}, o)).__v = o.__v + 1, n.vnode && n.vnode(_), M(t.__P, _, o, t.__n, t.__P.namespaceURI, 32 & o.__u ? [u] : null, l, null == u ? E(o) : u, !!(32 & o.__u), c), _.__v = o.__v, _.__.__k[_.__i] = _, A(l, _, c), _.__e != u && S(_)));
    x.__r = 0
}

function N(e, n, t, _, r, o, u, i, l, c, a) {
    var f, s, h, m, y, b, k = _ && _.__k || d,
        w = n.length;
    for (l = function(e, n, t, _, r) {
            var o, u, i, l, c, a = t.length,
                f = a,
                s = 0;
            for (e.__k = new Array(r), o = 0; o < r; o++) null != (u = n[o]) && "boolean" != typeof u && "function" != typeof u ? (l = o + s, (u = e.__k[o] = "string" == typeof u || "number" == typeof u || "bigint" == typeof u || u.constructor == String ? g(null, u, null, null, null) : v(u) ? g(C, {
                children: u
            }, null, null, null) : null == u.constructor && u.__b > 0 ? g(u.type, u.props, u.key, u.ref ? u.ref : null, u.__v) : u).__ = e, u.__b = e.__b + 1, i = null, -1 != (c = u.__i = R(u, t, l, f)) && (f--, (i = t[c]) && (i.__u |= 2)), null == i || null == i.__v ? (-1 == c && (r > a ? s-- : r < a && s++), "function" != typeof u.type && (u.__u |= 4)) : c != l && (c == l - 1 ? s-- : c == l + 1 ? s++ : (c > l ? s-- : s++, u.__u |= 4))) : e.__k[o] = null;
            if (f)
                for (o = 0; o < a; o++) null != (i = t[o]) && !(2 & i.__u) && (i.__e == _ && (_ = E(i)), I(i, i));
            return _
        }(t, n, k, l, w), f = 0; f < w; f++) null != (h = t.__k[f]) && (s = -1 == h.__i ? p : k[h.__i] || p, h.__i = f, b = M(e, h, s, r, o, u, i, l, c, a), m = h.__e, h.ref && s.ref != h.ref && (s.ref && F(s.ref, null, h), a.push(h.ref, h.__c || m, h)), null == y && null != m && (y = m), 4 & h.__u || s.__k === h.__k ? l = O(h, l, e) : "function" == typeof h.type && void 0 !== b ? l = b : m && (l = m.nextSibling), h.__u &= -7);
    return t.__e = y, l
}

function O(e, n, t) {
    var _, r;
    if ("function" == typeof e.type) {
        for (_ = e.__k, r = 0; _ && r < _.length; r++) _[r] && (_[r].__ = e, n = O(_[r], n, t));
        return n
    }
    e.__e != n && (n && e.type && !t.contains(n) && (n = E(e)), t.insertBefore(e.__e, n || null), n = e.__e);
    do {
        n = n && n.nextSibling
    } while (null != n && 8 == n.nodeType);
    return n
}

function U(e, n) {
    return n = n || [], null == e || "boolean" == typeof e || (v(e) ? e.some((function(e) {
        U(e, n)
    })) : n.push(e)), n
}

function R(e, n, t, _) {
    var r, o, u = e.key,
        i = e.type,
        l = n[t];
    if (null === l && null == e.key || l && u == l.key && i == l.type && !(2 & l.__u)) return t;
    if (_ > (null == l || 2 & l.__u ? 0 : 1))
        for (r = t - 1, o = t + 1; r >= 0 || o < n.length;) {
            if (r >= 0) {
                if ((l = n[r]) && !(2 & l.__u) && u == l.key && i == l.type) return r;
                r--
            }
            if (o < n.length) {
                if ((l = n[o]) && !(2 & l.__u) && u == l.key && i == l.type) return o;
                o++
            }
        }
    return -1
}

function T(e, n, t) {
    "-" == n[0] ? e.setProperty(n, null == t ? "" : t) : e[n] = null == t ? "" : "number" != typeof t || h.test(n) ? t : t + "px"
}

function H(e, n, t, _, r) {
    var o;
    e: if ("style" == n)
        if ("string" == typeof t) e.style.cssText = t;
        else {
            if ("string" == typeof _ && (e.style.cssText = _ = ""), _)
                for (n in _) t && n in t || T(e.style, n, "");
            if (t)
                for (n in t) _ && t[n] == _[n] || T(e.style, n, t[n])
        }
    else if ("o" == n[0] && "n" == n[1]) o = n != (n = n.replace(l, "$1")), n = n.toLowerCase() in e || "onFocusOut" == n || "onFocusIn" == n ? n.toLowerCase().slice(2) : n.slice(2), e.l || (e.l = {}), e.l[n + o] = t, t ? _ ? t.u = _.u : (t.u = c, e.addEventListener(n, o ? f : a, o)) : e.removeEventListener(n, o ? f : a, o);
    else {
        if ("http://www.w3.org/2000/svg" == r) n = n.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" != n && "height" != n && "href" != n && "list" != n && "form" != n && "tabIndex" != n && "download" != n && "rowSpan" != n && "colSpan" != n && "role" != n && "popover" != n && n in e) try {
            e[n] = null == t ? "" : t;
            break e
        } catch (u) {}
        "function" == typeof t || (null == t || !1 === t && "-" != n[4] ? e.removeAttribute(n) : e.setAttribute(n, "popover" == n && 1 == t ? "" : t))
    }
}

function D(e) {
    return function(t) {
        if (this.l) {
            var _ = this.l[t.type + e];
            if (null == t.t) t.t = c++;
            else if (t.t < _.u) return;
            return _(n.event ? n.event(t) : t)
        }
    }
}

function M(t, _, r, o, u, i, l, c, a, f) {
    var s, d, h, b, g, k, S, P, x, O, U, R, T, D, M, A, F, I = _.type;
    if (null != _.constructor) return null;
    128 & r.__u && (a = !!(32 & r.__u), i = [c = _.__e = r.__e]), (s = n.__b) && s(_);
    e: if ("function" == typeof I) try {
        if (P = _.props, x = "prototype" in I && I.prototype.render, O = (s = I.contextType) && o[s.__c], U = s ? O ? O.props.value : s.__ : o, r.__c ? S = (d = _.__c = r.__c).__ = d.__E : (x ? _.__c = d = new I(P, U) : (_.__c = d = new w(P, U), d.constructor = I, d.render = W), O && O.sub(d), d.props = P, d.state || (d.state = {}), d.context = U, d.__n = o, h = d.__d = !0, d.__h = [], d._sb = []), x && null == d.__s && (d.__s = d.state), x && null != I.getDerivedStateFromProps && (d.__s == d.state && (d.__s = m({}, d.__s)), m(d.__s, I.getDerivedStateFromProps(P, d.__s))), b = d.props, g = d.state, d.__v = _, h) x && null == I.getDerivedStateFromProps && null != d.componentWillMount && d.componentWillMount(), x && null != d.componentDidMount && d.__h.push(d.componentDidMount);
        else {
            if (x && null == I.getDerivedStateFromProps && P !== b && null != d.componentWillReceiveProps && d.componentWillReceiveProps(P, U), !d.__e && null != d.shouldComponentUpdate && !1 === d.shouldComponentUpdate(P, d.__s, U) || _.__v == r.__v) {
                for (_.__v != r.__v && (d.props = P, d.state = d.__s, d.__d = !1), _.__e = r.__e, _.__k = r.__k, _.__k.some((function(e) {
                        e && (e.__ = _)
                    })), R = 0; R < d._sb.length; R++) d.__h.push(d._sb[R]);
                d._sb = [], d.__h.length && l.push(d);
                break e
            }
            null != d.componentWillUpdate && d.componentWillUpdate(P, d.__s, U), x && null != d.componentDidUpdate && d.__h.push((function() {
                d.componentDidUpdate(b, g, k)
            }))
        }
        if (d.context = U, d.props = P, d.__P = t, d.__e = !1, T = n.__r, D = 0, x) {
            for (d.state = d.__s, d.__d = !1, T && T(_), s = d.render(d.props, d.state, d.context), M = 0; M < d._sb.length; M++) d.__h.push(d._sb[M]);
            d._sb = []
        } else
            do {
                d.__d = !1, T && T(_), s = d.render(d.props, d.state, d.context), d.state = d.__s
            } while (d.__d && ++D < 25);
        d.state = d.__s, null != d.getChildContext && (o = m(m({}, o), d.getChildContext())), x && !h && null != d.getSnapshotBeforeUpdate && (k = d.getSnapshotBeforeUpdate(b, g)), A = s, null != s && s.type === C && null == s.key && (A = L(s.props.children)), c = N(t, v(A) ? A : [A], _, r, o, u, i, l, c, a, f), d.base = _.__e, _.__u &= -161, d.__h.length && l.push(d), S && (d.__E = d.__ = null)
    } catch (V) {
        if (_.__v = null, a || null != i)
            if (V.then) {
                for (_.__u |= a ? 160 : 128; c && 8 == c.nodeType && c.nextSibling;) c = c.nextSibling;
                i[i.indexOf(c)] = null, _.__e = c
            } else
                for (F = i.length; F--;) y(i[F]);
        else _.__e = r.__e, _.__k = r.__k;
        n.__e(V, _, r)
    } else null == i && _.__v == r.__v ? (_.__k = r.__k, _.__e = r.__e) : c = _.__e = function(t, _, r, o, u, i, l, c, a) {
        var f, s, d, h, m, b, g, k = r.props,
            C = _.props,
            w = _.type;
        if ("svg" == w ? u = "http://www.w3.org/2000/svg" : "math" == w ? u = "http://www.w3.org/1998/Math/MathML" : u || (u = "http://www.w3.org/1999/xhtml"), null != i)
            for (f = 0; f < i.length; f++)
                if ((m = i[f]) && "setAttribute" in m == !!w && (w ? m.localName == w : 3 == m.nodeType)) {
                    t = m, i[f] = null;
                    break
                }
        if (null == t) {
            if (null == w) return document.createTextNode(C);
            t = document.createElementNS(u, w, C.is && C), c && (n.__m && n.__m(_, i), c = !1), i = null
        }
        if (null == w) k === C || c && t.data == C || (t.data = C);
        else {
            if (i = i && e.call(t.childNodes), k = r.props || p, !c && null != i)
                for (k = {}, f = 0; f < t.attributes.length; f++) k[(m = t.attributes[f]).name] = m.value;
            for (f in k)
                if (m = k[f], "children" == f);
                else if ("dangerouslySetInnerHTML" == f) d = m;
            else if (!(f in C)) {
                if ("value" == f && "defaultValue" in C || "checked" == f && "defaultChecked" in C) continue;
                H(t, f, null, m, u)
            }
            for (f in C) m = C[f], "children" == f ? h = m : "dangerouslySetInnerHTML" == f ? s = m : "value" == f ? b = m : "checked" == f ? g = m : c && "function" != typeof m || k[f] === m || H(t, f, m, k[f], u);
            if (s) c || d && (s.__html == d.__html || s.__html == t.innerHTML) || (t.innerHTML = s.__html), _.__k = [];
            else if (d && (t.innerHTML = ""), N("template" == _.type ? t.content : t, v(h) ? h : [h], _, r, o, "foreignObject" == w ? "http://www.w3.org/1999/xhtml" : u, i, l, i ? i[0] : r.__k && E(r, 0), c, a), null != i)
                for (f = i.length; f--;) y(i[f]);
            c || (f = "value", "progress" == w && null == b ? t.removeAttribute("value") : null != b && (b !== t[f] || "progress" == w && !b || "option" == w && b != k[f]) && H(t, f, b, k[f], u), f = "checked", null != g && g != t[f] && H(t, f, g, k[f], u))
        }
        return t
    }(r.__e, _, r, o, u, i, l, a, f);
    return (s = n.diffed) && s(_), 128 & _.__u ? void 0 : c
}

function A(e, t, _) {
    for (var r = 0; r < _.length; r++) F(_[r], _[++r], _[++r]);
    n.__c && n.__c(t, e), e.some((function(t) {
        try {
            e = t.__h, t.__h = [], e.some((function(e) {
                e.call(t)
            }))
        } catch (_) {
            n.__e(_, t.__v)
        }
    }))
}

function L(e) {
    return "object" != typeof e || null == e || e.__b && e.__b > 0 ? e : v(e) ? e.map(L) : m({}, e)
}

function F(e, t, _) {
    try {
        if ("function" == typeof e) {
            var r = "function" == typeof e.__u;
            r && e.__u(), r && null == t || (e.__u = e(t))
        } else e.current = t
    } catch (o) {
        n.__e(o, _)
    }
}

function I(e, t, _) {
    var r, o;
    if (n.unmount && n.unmount(e), (r = e.ref) && (r.current && r.current != e.__e || F(r, null, t)), null != (r = e.__c)) {
        if (r.componentWillUnmount) try {
            r.componentWillUnmount()
        } catch (u) {
            n.__e(u, t)
        }
        r.base = r.__P = null
    }
    if (r = e.__k)
        for (o = 0; o < r.length; o++) r[o] && I(r[o], t, _ || "function" != typeof e.type);
    _ || y(e.__e), e.__c = e.__ = e.__e = void 0
}

function W(e, n, t) {
    return this.constructor(e, t)
}

function V(t, _, r) {
    var o, u, i, l;
    _ == document && (_ = document.documentElement), n.__ && n.__(t, _), u = (o = "function" == typeof r) ? null : r && r.__k || _.__k, i = [], l = [], M(_, t = (!o && r || _).__k = b(C, null, [t]), u || p, p, _.namespaceURI, !o && r ? [r] : u ? null : _.firstChild ? e.call(_.childNodes) : null, i, !o && r ? r : u ? u.__e : _.firstChild, o, l), A(i, t, l)
}

function j(e, n) {
    V(e, n, j)
}

function B(n, t, _) {
    var r, o, u, i, l = m({}, n.props);
    for (u in n.type && n.type.defaultProps && (i = n.type.defaultProps), t) "key" == u ? r = t[u] : "ref" == u ? o = t[u] : l[u] = null == t[u] && null != i ? i[u] : t[u];
    return arguments.length > 2 && (l.children = arguments.length > 3 ? e.call(arguments, 2) : _), g(n.type, l, r || n.key, o || n.ref, null)
}

function $(e) {
    function n(e) {
        var t, _;
        return this.getChildContext || (t = new Set, (_ = {})[n.__c] = this, this.getChildContext = function() {
            return _
        }, this.componentWillUnmount = function() {
            t = null
        }, this.shouldComponentUpdate = function(e) {
            this.props.value != e.value && t.forEach((function(e) {
                e.__e = !0, P(e)
            }))
        }, this.sub = function(e) {
            t.add(e);
            var n = e.componentWillUnmount;
            e.componentWillUnmount = function() {
                t && t.delete(e), n && n.call(e)
            }
        }), e.children
    }
    return n.__c = "__cC" + s++, n.__ = e, n.Provider = n.__l = (n.Consumer = function(e, n) {
        return e.children(n)
    }).contextType = n, n
}
e = d.slice, n = {
    __e: function(e, n, t, _) {
        for (var r, o, u; n = n.__;)
            if ((r = n.__c) && !r.__) try {
                if ((o = r.constructor) && null != o.getDerivedStateFromError && (r.setState(o.getDerivedStateFromError(e)), u = r.__d), null != r.componentDidCatch && (r.componentDidCatch(e, _ || {}), u = r.__d), u) return r.__E = r
            } catch (i) {
                e = i
            }
        throw e
    }
}, t = 0, _ = function(e) {
    return null != e && null == e.constructor
}, w.prototype.setState = function(e, n) {
    var t;
    t = null != this.__s && this.__s != this.state ? this.__s : this.__s = m({}, this.state), "function" == typeof e && (e = e(m({}, t), this.props)), e && m(t, e), null != e && this.__v && (n && this._sb.push(n), P(this))
}, w.prototype.forceUpdate = function(e) {
    this.__v && (this.__e = !0, e && this.__h.push(e), P(this))
}, w.prototype.render = C, r = [], u = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, i = function(e, n) {
    return e.__v.__b - n.__v.__b
}, x.__r = 0, l = /(PointerCapture)$|Capture$/i, c = 0, a = D(!1), f = D(!0), s = 0;
var z, q, Y, Z, J = 0,
    K = [],
    G = n,
    Q = G.__b,
    X = G.__r,
    ee = G.diffed,
    ne = G.__c,
    te = G.unmount,
    _e = G.__;

function re(e, n) {
    G.__h && G.__h(q, e, J || n), J = 0;
    var t = q.__H || (q.__H = {
        __: [],
        __h: []
    });
    return e >= t.__.length && t.__.push({}), t.__[e]
}

function oe(e) {
    return J = 1, ue(Ce, e)
}

function ue(e, n, t) {
    var _ = re(z++, 2);
    if (_.t = e, !_.__c && (_.__ = [t ? t(n) : Ce(void 0, n), function(e) {
            var n = _.__N ? _.__N[0] : _.__[0],
                t = _.t(n, e);
            n !== t && (_.__N = [t, _.__[1]], _.__c.setState({}))
        }], _.__c = q, !q.__f)) {
        var r = function(e, n, t) {
            if (!_.__c.__H) return !0;
            var r = _.__c.__H.__.filter((function(e) {
                return !!e.__c
            }));
            if (r.every((function(e) {
                    return !e.__N
                }))) return !o || o.call(this, e, n, t);
            var u = _.__c.props !== e;
            return r.forEach((function(e) {
                if (e.__N) {
                    var n = e.__[0];
                    e.__ = e.__N, e.__N = void 0, n !== e.__[0] && (u = !0)
                }
            })), o && o.call(this, e, n, t) || u
        };
        q.__f = !0;
        var o = q.shouldComponentUpdate,
            u = q.componentWillUpdate;
        q.componentWillUpdate = function(e, n, t) {
            if (this.__e) {
                var _ = o;
                o = void 0, r(e, n, t), o = _
            }
            u && u.call(this, e, n, t)
        }, q.shouldComponentUpdate = r
    }
    return _.__N || _.__
}

function ie(e, n) {
    var t = re(z++, 3);
    !G.__s && ke(t.__H, n) && (t.__ = e, t.u = n, q.__H.__h.push(t))
}

function le(e, n) {
    var t = re(z++, 4);
    !G.__s && ke(t.__H, n) && (t.__ = e, t.u = n, q.__h.push(t))
}

function ce(e) {
    return J = 5, fe((function() {
        return {
            current: e
        }
    }), [])
}

function ae(e, n, t) {
    J = 6, le((function() {
        if ("function" == typeof e) {
            var t = e(n());
            return function() {
                e(null), t && "function" == typeof t && t()
            }
        }
        if (e) return e.current = n(),
            function() {
                return e.current = null
            }
    }), null == t ? t : t.concat(e))
}

function fe(e, n) {
    var t = re(z++, 7);
    return ke(t.__H, n) && (t.__ = e(), t.__H = n, t.__h = e), t.__
}

function se(e, n) {
    return J = 8, fe((function() {
        return e
    }), n)
}

function pe(e) {
    var n = q.context[e.__c],
        t = re(z++, 9);
    return t.c = e, n ? (null == t.__ && (t.__ = !0, n.sub(q)), n.props.value) : e.__
}

function de(e, n) {
    G.useDebugValue && G.useDebugValue(n ? n(e) : e)
}

function he() {
    var e = re(z++, 11);
    if (!e.__) {
        for (var n = q.__v; null !== n && !n.__m && null !== n.__;) n = n.__;
        var t = n.__m || (n.__m = [0, 0]);
        e.__ = "P" + t[0] + "-" + t[1]++
    }
    return e.__
}

function ve() {
    for (var e; e = K.shift();)
        if (e.__P && e.__H) try {
            e.__H.__h.forEach(be), e.__H.__h.forEach(ge), e.__H.__h = []
        } catch (n) {
            e.__H.__h = [], G.__e(n, e.__v)
        }
}
G.__b = function(e) {
    q = null, Q && Q(e)
}, G.__ = function(e, n) {
    e && n.__k && n.__k.__m && (e.__m = n.__k.__m), _e && _e(e, n)
}, G.__r = function(e) {
    X && X(e), z = 0;
    var n = (q = e.__c).__H;
    n && (Y === q ? (n.__h = [], q.__h = [], n.__.forEach((function(e) {
        e.__N && (e.__ = e.__N), e.u = e.__N = void 0
    }))) : (n.__h.forEach(be), n.__h.forEach(ge), n.__h = [], z = 0)), Y = q
}, G.diffed = function(e) {
    ee && ee(e);
    var n = e.__c;
    n && n.__H && (n.__H.__h.length && (1 !== K.push(n) && Z === G.requestAnimationFrame || ((Z = G.requestAnimationFrame) || ye)(ve)), n.__H.__.forEach((function(e) {
        e.u && (e.__H = e.u), e.u = void 0
    }))), Y = q = null
}, G.__c = function(e, n) {
    n.some((function(e) {
        try {
            e.__h.forEach(be), e.__h = e.__h.filter((function(e) {
                return !e.__ || ge(e)
            }))
        } catch (t) {
            n.some((function(e) {
                e.__h && (e.__h = [])
            })), n = [], G.__e(t, e.__v)
        }
    })), ne && ne(e, n)
}, G.unmount = function(e) {
    te && te(e);
    var n, t = e.__c;
    t && t.__H && (t.__H.__.forEach((function(e) {
        try {
            be(e)
        } catch (t) {
            n = t
        }
    })), t.__H = void 0, n && G.__e(n, t.__v))
};
var me = "function" == typeof requestAnimationFrame;

function ye(e) {
    var n, t = function() {
            clearTimeout(_), me && cancelAnimationFrame(n), setTimeout(e)
        },
        _ = setTimeout(t, 100);
    me && (n = requestAnimationFrame(t))
}

function be(e) {
    var n = q,
        t = e.__c;
    "function" == typeof t && (e.__c = void 0, t()), q = n
}

function ge(e) {
    var n = q;
    e.__c = e.__(), q = n
}

function ke(e, n) {
    return !e || e.length !== n.length || n.some((function(n, t) {
        return n !== e[t]
    }))
}

function Ce(e, n) {
    return "function" == typeof n ? n(e) : n
}

function we(e, n) {
    for (var t in n) e[t] = n[t];
    return e
}

function Ee(e, n) {
    for (var t in e)
        if ("__source" !== t && !(t in n)) return !0;
    for (var _ in n)
        if ("__source" !== _ && e[_] !== n[_]) return !0;
    return !1
}

function Se(e, n) {
    var t = n(),
        _ = oe({
            t: {
                __: t,
                u: n
            }
        }),
        r = _[0].t,
        o = _[1];
    return le((function() {
        r.__ = t, r.u = n, Pe(r) && o({
            t: r
        })
    }), [e, t, n]), ie((function() {
        return Pe(r) && o({
            t: r
        }), e((function() {
            Pe(r) && o({
                t: r
            })
        }))
    }), [e]), t
}

function Pe(e) {
    var n, t, _ = e.u,
        r = e.__;
    try {
        var o = _();
        return !((n = r) === (t = o) && (0 !== n || 1 / n == 1 / t) || n != n && t != t)
    } catch (u) {
        return !0
    }
}

function xe(e) {
    e()
}

function Ne(e) {
    return e
}

function Oe() {
    return [!1, xe]
}
var Ue = le;

function Re(e, n) {
    this.props = e, this.context = n
}

function Te(e, n) {
    function t(e) {
        var t = this.props.ref,
            _ = t == e.ref;
        return !_ && t && (t.call ? t(null) : t.current = null), n ? !n(this.props, e) || !_ : Ee(this.props, e)
    }

    function _(n) {
        return this.shouldComponentUpdate = t, b(e, n)
    }
    return _.displayName = "Memo(" + (e.displayName || e.name) + ")", _.prototype.isReactComponent = !0, _.__f = !0, _
}(Re.prototype = new w).isPureReactComponent = !0, Re.prototype.shouldComponentUpdate = function(e, n) {
    return Ee(this.props, e) || Ee(this.state, n)
};
var He = n.__b;
n.__b = function(e) {
    e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), He && He(e)
};
var De = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;

function Me(e) {
    function n(n) {
        var t = we({}, n);
        return delete t.ref, e(t, n.ref || null)
    }
    return n.$$typeof = De, n.render = n, n.prototype.isReactComponent = n.__f = !0, n.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", n
}
var Ae = function(e, n) {
        return null == e ? null : U(U(e).map(n))
    },
    Le = {
        map: Ae,
        forEach: Ae,
        count: function(e) {
            return e ? U(e).length : 0
        },
        only: function(e) {
            var n = U(e);
            if (1 !== n.length) throw "Children.only";
            return n[0]
        },
        toArray: U
    },
    Fe = n.__e;
n.__e = function(e, n, t, _) {
    if (e.then)
        for (var r, o = n; o = o.__;)
            if ((r = o.__c) && r.__c) return null == n.__e && (n.__e = t.__e, n.__k = t.__k), r.__c(e, n);
    Fe(e, n, t, _)
};
var Ie = n.unmount;

function We(e, n, t) {
    return e && (e.__c && e.__c.__H && (e.__c.__H.__.forEach((function(e) {
        "function" == typeof e.__c && e.__c()
    })), e.__c.__H = null), null != (e = we({}, e)).__c && (e.__c.__P === t && (e.__c.__P = n), e.__c.__e = !0, e.__c = null), e.__k = e.__k && e.__k.map((function(e) {
        return We(e, n, t)
    }))), e
}

function Ve(e, n, t) {
    return e && t && (e.__v = null, e.__k = e.__k && e.__k.map((function(e) {
        return Ve(e, n, t)
    })), e.__c && e.__c.__P === n && (e.__e && t.appendChild(e.__e), e.__c.__e = !0, e.__c.__P = t)), e
}

function je() {
    this.__u = 0, this.o = null, this.__b = null
}

function Be(e) {
    var n = e.__.__c;
    return n && n.__a && n.__a(e)
}

function $e(e) {
    var n, t, _;

    function r(r) {
        if (n || (n = e()).then((function(e) {
                t = e.default || e
            }), (function(e) {
                _ = e
            })), _) throw _;
        if (!t) throw n;
        return b(t, r)
    }
    return r.displayName = "Lazy", r.__f = !0, r
}

function ze() {
    this.i = null, this.l = null
}
n.unmount = function(e) {
    var n = e.__c;
    n && n.__R && n.__R(), n && 32 & e.__u && (e.type = null), Ie && Ie(e)
}, (je.prototype = new w).__c = function(e, n) {
    var t = n.__c,
        _ = this;
    null == _.o && (_.o = []), _.o.push(t);
    var r = Be(_.__v),
        o = !1,
        u = function() {
            o || (o = !0, t.__R = null, r ? r(i) : i())
        };
    t.__R = u;
    var i = function() {
        if (!--_.__u) {
            if (_.state.__a) {
                var e = _.state.__a;
                _.__v.__k[0] = Ve(e, e.__c.__P, e.__c.__O)
            }
            var n;
            for (_.setState({
                    __a: _.__b = null
                }); n = _.o.pop();) n.forceUpdate()
        }
    };
    _.__u++ || 32 & n.__u || _.setState({
        __a: _.__b = _.__v.__k[0]
    }), e.then(u, u)
}, je.prototype.componentWillUnmount = function() {
    this.o = []
}, je.prototype.render = function(e, n) {
    if (this.__b) {
        if (this.__v.__k) {
            var t = document.createElement("div"),
                _ = this.__v.__k[0].__c;
            this.__v.__k[0] = We(this.__b, t, _.__O = _.__P)
        }
        this.__b = null
    }
    var r = n.__a && b(C, null, e.fallback);
    return r && (r.__u &= -33), [b(C, null, n.__a ? null : e.children), r]
};
var qe = function(e, n, t) {
    if (++t[1] === t[0] && e.l.delete(n), e.props.revealOrder && ("t" !== e.props.revealOrder[0] || !e.l.size))
        for (t = e.i; t;) {
            for (; t.length > 3;) t.pop()();
            if (t[1] < t[0]) break;
            e.i = t = t[2]
        }
};

function Ye(e) {
    return this.getChildContext = function() {
        return e.context
    }, e.children
}

function Ze(e) {
    var n = this,
        t = e.h;
    n.componentWillUnmount = function() {
        V(null, n.v), n.v = null, n.h = null
    }, n.h && n.h !== t && n.componentWillUnmount(), n.v || (n.h = t, n.v = {
        nodeType: 1,
        parentNode: t,
        childNodes: [],
        contains: function() {
            return !0
        },
        appendChild: function(e) {
            this.childNodes.push(e), n.h.appendChild(e)
        },
        insertBefore: function(e, t) {
            this.childNodes.push(e), n.h.insertBefore(e, t)
        },
        removeChild: function(e) {
            this.childNodes.splice(this.childNodes.indexOf(e) >>> 1, 1), n.h.removeChild(e)
        }
    }), V(b(Ye, {
        context: n.context
    }, e.__v), n.v)
}

function Je(e, n) {
    var t = b(Ze, {
        __v: e,
        h: n
    });
    return t.containerInfo = n, t
}(ze.prototype = new w).__a = function(e) {
    var n = this,
        t = Be(n.__v),
        _ = n.l.get(e);
    return _[0]++,
        function(r) {
            var o = function() {
                n.props.revealOrder ? (_.push(r), qe(n, e, _)) : r()
            };
            t ? t(o) : o()
        }
}, ze.prototype.render = function(e) {
    this.i = null, this.l = new Map;
    var n = U(e.children);
    e.revealOrder && "b" === e.revealOrder[0] && n.reverse();
    for (var t = n.length; t--;) this.l.set(n[t], this.i = [1, 0, this.i]);
    return e.children
}, ze.prototype.componentDidUpdate = ze.prototype.componentDidMount = function() {
    var e = this;
    this.l.forEach((function(n, t) {
        qe(e, t, n)
    }))
};
var Ke = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103,
    Ge = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    Qe = /^on(Ani|Tra|Tou|BeforeInp|Compo)/,
    Xe = /[A-Z0-9]/g,
    en = "undefined" != typeof document,
    nn = function(e) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(e)
    };

function tn(e, n, t) {
    return null == n.__k && (n.textContent = ""), V(e, n), "function" == typeof t && t(), e ? e.__c : null
}

function _n(e, n, t) {
    return j(e, n), "function" == typeof t && t(), e ? e.__c : null
}
w.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach((function(e) {
    Object.defineProperty(w.prototype, e, {
        configurable: !0,
        get: function() {
            return this["UNSAFE_" + e]
        },
        set: function(n) {
            Object.defineProperty(this, e, {
                configurable: !0,
                writable: !0,
                value: n
            })
        }
    })
}));
var rn = n.event;

function on() {}

function un() {
    return this.cancelBubble
}

function ln() {
    return this.defaultPrevented
}
n.event = function(e) {
    return rn && (e = rn(e)), e.persist = on, e.isPropagationStopped = un, e.isDefaultPrevented = ln, e.nativeEvent = e
};
var cn, an = {
        enumerable: !1,
        configurable: !0,
        get: function() {
            return this.class
        }
    },
    fn = n.vnode;
n.vnode = function(e) {
    "string" == typeof e.type && function(e) {
        var n = e.props,
            t = e.type,
            _ = {},
            r = -1 === t.indexOf("-");
        for (var o in n) {
            var u = n[o];
            if (!("value" === o && "defaultValue" in n && null == u || en && "children" === o && "noscript" === t || "class" === o || "className" === o)) {
                var i = o.toLowerCase();
                "defaultValue" === o && "value" in n && null == n.value ? o = "value" : "download" === o && !0 === u ? u = "" : "translate" === i && "no" === u ? u = !1 : "o" === i[0] && "n" === i[1] ? "ondoubleclick" === i ? o = "ondblclick" : "onchange" !== i || "input" !== t && "textarea" !== t || nn(n.type) ? "onfocus" === i ? o = "onfocusin" : "onblur" === i ? o = "onfocusout" : Qe.test(o) && (o = i) : i = o = "oninput" : r && Ge.test(o) ? o = o.replace(Xe, "-$&").toLowerCase() : null === u && (u = void 0), "oninput" === i && _[o = i] && (o = "oninputCapture"), _[o] = u
            }
        }
        "select" == t && _.multiple && Array.isArray(_.value) && (_.value = U(n.children).forEach((function(e) {
            e.props.selected = -1 != _.value.indexOf(e.props.value)
        }))), "select" == t && null != _.defaultValue && (_.value = U(n.children).forEach((function(e) {
            e.props.selected = _.multiple ? -1 != _.defaultValue.indexOf(e.props.value) : _.defaultValue == e.props.value
        }))), n.class && !n.className ? (_.class = n.class, Object.defineProperty(_, "className", an)) : (n.className && !n.class || n.class && n.className) && (_.class = _.className = n.className), e.props = _
    }(e), e.$$typeof = Ke, fn && fn(e)
};
var sn = n.__r;
n.__r = function(e) {
    sn && sn(e), cn = e.__c
};
var pn = n.diffed;
n.diffed = function(e) {
    pn && pn(e);
    var n = e.props,
        t = e.__e;
    null != t && "textarea" === e.type && "value" in n && n.value !== t.value && (t.value = null == n.value ? "" : n.value), cn = null
};
var dn = {
    ReactCurrentDispatcher: {
        current: {
            readContext: function(e) {
                return cn.__n[e.__c].props.value
            },
            useCallback: se,
            useContext: pe,
            useDebugValue: de,
            useDeferredValue: Ne,
            useEffect: ie,
            useId: he,
            useImperativeHandle: ae,
            useInsertionEffect: Ue,
            useLayoutEffect: le,
            useMemo: fe,
            useReducer: ue,
            useRef: ce,
            useState: oe,
            useSyncExternalStore: Se,
            useTransition: Oe
        }
    }
};

function hn(e) {
    return b.bind(null, e)
}

function vn(e) {
    return !!e && e.$$typeof === Ke
}

function mn(e) {
    return vn(e) && e.type === C
}

function yn(e) {
    return !!e && !!e.displayName && ("string" == typeof e.displayName || e.displayName instanceof String) && e.displayName.startsWith("Memo(")
}

function bn(e) {
    return vn(e) ? B.apply(null, arguments) : e
}

function gn(e) {
    return !!e.__k && (V(null, e), !0)
}

function kn(e) {
    return e && (e.base || 1 === e.nodeType && e) || null
}
var Cn = function(e, n) {
        return e(n)
    },
    wn = function(e, n) {
        return e(n)
    },
    En = C,
    Sn = vn,
    Pn = {
        useState: oe,
        useId: he,
        useReducer: ue,
        useEffect: ie,
        useLayoutEffect: le,
        useInsertionEffect: Ue,
        useTransition: Oe,
        useDeferredValue: Ne,
        useSyncExternalStore: Se,
        startTransition: xe,
        useRef: ce,
        useImperativeHandle: ae,
        useMemo: fe,
        useCallback: se,
        useContext: pe,
        useDebugValue: de,
        version: "18.3.1",
        Children: Le,
        render: tn,
        hydrate: _n,
        unmountComponentAtNode: gn,
        createPortal: Je,
        createElement: b,
        createContext: $,
        createFactory: hn,
        cloneElement: bn,
        createRef: k,
        Fragment: C,
        isValidElement: vn,
        isElement: Sn,
        isFragment: mn,
        isMemo: yn,
        findDOMNode: kn,
        Component: w,
        PureComponent: Re,
        memo: Te,
        forwardRef: Me,
        flushSync: wn,
        unstable_batchedUpdates: Cn,
        StrictMode: En,
        Suspense: je,
        SuspenseList: ze,
        lazy: $e,
        __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: dn
    };
const xn = Object.freeze(Object.defineProperty({
    __proto__: null,
    Children: Le,
    Component: w,
    Fragment: C,
    PureComponent: Re,
    StrictMode: En,
    Suspense: je,
    SuspenseList: ze,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: dn,
    cloneElement: bn,
    createContext: $,
    createElement: b,
    createFactory: hn,
    createPortal: Je,
    createRef: k,
    default: Pn,
    findDOMNode: kn,
    flushSync: wn,
    forwardRef: Me,
    hydrate: _n,
    isElement: Sn,
    isFragment: mn,
    isMemo: yn,
    isValidElement: vn,
    lazy: $e,
    memo: Te,
    render: tn,
    startTransition: xe,
    unmountComponentAtNode: gn,
    unstable_batchedUpdates: Cn,
    useCallback: se,
    useContext: pe,
    useDebugValue: de,
    useDeferredValue: Ne,
    useEffect: ie,
    useErrorBoundary: function(e) {
        var n = re(z++, 10),
            t = oe();
        return n.__ = e, q.componentDidCatch || (q.componentDidCatch = function(e, _) {
            n.__ && n.__(e, _), t[1](e)
        }), [t[0], function() {
            t[1](void 0)
        }]
    },
    useId: he,
    useImperativeHandle: ae,
    useInsertionEffect: Ue,
    useLayoutEffect: le,
    useMemo: fe,
    useReducer: ue,
    useRef: ce,
    useState: oe,
    useSyncExternalStore: Se,
    useTransition: Oe,
    version: "18.3.1"
}, Symbol.toStringTag, {
    value: "Module"
}));

function Nn(e, n = {}) {
    const t = document.querySelector(`meta[name="${e}"]`);
    if (!t) return n;
    const _ = t.getAttribute("content");
    try {
        return JSON.parse(_)
    } catch (r) {
        return _
    }
}

function On(e) {
    if (null == e || e instanceof Date) return e;
    if ("object" != typeof e && !Array.isArray(e)) return e;
    if (Array.isArray(e)) return e.map(On);
    const n = {};
    return Object.entries(e).forEach((([e, t]) => {
        const _ = e.replace(/[-_]([a-z0-9])/g, ((e, n) => n.toUpperCase()));
        n[_] = On(t)
    })), n
}

function Un(e = window.navigator.userAgent) {
    return /iPad|iPhone/i.test(e)
}

function Rn() {
    const e = navigator.userAgent;
    let n = !1;
    if ("maxTouchPoints" in navigator) n = navigator.maxTouchPoints > 0;
    else {
        const t = Boolean(window.matchMedia) && matchMedia("(pointer:coarse)");
        n = t && "(pointer:coarse)" === t.media ? Boolean(t.matches) : "orientation" in window || (/\b(BlackBerry|webOS|iPhone|IEMobile)\b/i.test(e) || /\b(Android|Windows Phone|iPad|iPod)\b/i.test(e))
    }
    return n
}
var Tn = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

function Hn(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}

function Dn(e) {
    if (e.__esModule) return e;
    var n = e.default;
    if ("function" == typeof n) {
        var t = function e() {
            return this instanceof e ? Reflect.construct(n, arguments, this.constructor) : n.apply(this, arguments)
        };
        t.prototype = n.prototype
    } else t = {};
    return Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.keys(e).forEach((function(n) {
        var _ = Object.getOwnPropertyDescriptor(e, n);
        Object.defineProperty(t, n, _.get ? _ : {
            enumerable: !0,
            get: function() {
                return e[n]
            }
        })
    })), t
}
var Mn = 0;

function An(e, t, _, r, o, u) {
    t || (t = {});
    var i, l, c = t;
    if ("ref" in c)
        for (l in c = {}, t) "ref" == l ? i = t[l] : c[l] = t[l];
    var a = {
        type: e,
        props: c,
        key: _,
        ref: i,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __c: null,
        constructor: void 0,
        __v: --Mn,
        __i: -1,
        __u: 0,
        __source: o,
        __self: u
    };
    if ("function" == typeof e && (i = e.defaultProps))
        for (l in i) void 0 === c[l] && (c[l] = i[l]);
    return n.vnode && n.vnode(a), a
}
export {
    Je as $, ce as A, Me as D, wn as E, ae as F, $ as K, Te as M, Re as N, Le as O, Pn as R, fe as T, b as _, Rn as a, bn as b, he as c, oe as d, k as e, Hn as f, Nn as g, ue as h, Un as i, w as j, C as k, le as l, Dn as m, xn as n, Tn as o, vn as p, se as q, n as r, _ as s, On as t, An as u, tn as v, gn as w, pe as x, ie as y
};