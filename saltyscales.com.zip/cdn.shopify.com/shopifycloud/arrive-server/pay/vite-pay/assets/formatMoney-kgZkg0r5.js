const a = /\{\{\s*(\w+)\s*\}\}/,
    o = /(\d)(?=(\d{3})+\b)/g,
    r = {
        amount: {
            precision: 2
        },
        amount_no_decimals: {
            precision: 0
        },
        amount_with_comma_separator: {
            precision: 2,
            thousands_separator: ".",
            decimal_mark: ","
        },
        amount_with_space_separator: {
            precision: 2,
            thousands_separator: " ",
            decimal_mark: ","
        },
        amount_with_period_and_space_separator: {
            precision: 2,
            thousands_separator: " ",
            decimal_mark: "."
        },
        amount_no_decimals_with_comma_separator: {
            precision: 0,
            thousands_separator: ".",
            decimal_mark: ","
        },
        amount_no_decimals_with_space_separator: {
            precision: 0,
            thousands_separator: " "
        },
        amount_with_apostrophe_separator: {
            precision: 2,
            thousands_separator: "'",
            decimal_mark: "."
        }
    };

function s(s, t) {
    const e = t.format.match(a);
    if (!e) return "";
    const n = e[1],
        i = r[n];
    if (!i) return "";
    const {
        precision: _,
        ...c
    } = i, p = function(a, r, s) {
        const {
            decimal_mark: t,
            thousands_separator: e
        } = s, n = a.toFixed(0 === a ? 0 : r).split(".");
        return n[0] = n[0].replace(o, `$1${e}`), n.join(t)
    }(s, _, { ...t,
        ...c
    });
    return t.format.replace(a, p)
}
export {
    s as f
};