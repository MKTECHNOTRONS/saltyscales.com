var e = (e => (e.Sms = "sms", e.Email = "email", e.Webauthn = "webauthn", e))(e || {}),
    a = (e => (e.Payment = "payment", e.Orders = "orders", e))(a || {}),
    n = (e => (e.Accepted = "ENABLED", e.Declined = "DISABLED", e.Unset = "UNSET", e))(n || {});
const o = {
    RECORD_NOT_FOUND: "record_not_found",
    CAPTCHA_NEEDED: "further_authorization_required",
    CAPTCHA_FAILED: "captcha_failed",
    PERSONALIZATION_CONSENT_REQUIRED: "personalization_consent_required",
    THROTTLED: "limit_exceeded",
    INVALID_TOKEN: "invalid_token",
    INVALID_CODE: "invalid_code",
    INVALID_EMAIL: "invalid_email",
    INVALID_PHONE: "invalid_phone",
    BLOCKED_PHONE: "phone_blocked",
    PHONE_LIMIT_REACHED: "phone_limit_reached",
    EXPIRED_TOKEN: "token_expired",
    EMAIL_USER_NOT_CREATED: "email_user_not_created",
    SERVER: "server_error",
    REQUEST_ABORTED: "request_aborted"
};
var r = (e => (e.Loading = "loading", e.Success = "success", e.Error = "error", e))(r || {}),
    t = (e => (e.ServerError = "server_error", e.UserBlocked = "user_blocked", e.NoDiscountReceived = "no_discount_received", e.InvalidAnalyticsContext = "invalid_analytics_context", e.InstallmentsIneligible = "installments_ineligible", e.CaptchaChallenge = "captcha_challenge", e.CannotProcess = "cannot_process", e.PreqaulAmountError = "prequal_amount_error", e))(t || {}),
    i = (e => (e.CaptchaChallenge = "User encountered captcha challenge.", e.InvalidDiscount = "Discount code is not valid.", e.DiscountSaveFailed = "Failed to save discount.", e.PersonalizationConsentStatusSaveFailed = "Failed to save personalization consent status", e.SaveStoreFollowFailed = "Failed to save store follow", e))(i || {});
export {
    n as A, t as S, e as V, a, o as b, i as c, r as d
};