import {
    v as n,
    w as o
} from "./jsxRuntime.module-s_rKrABX.js";

function t(t) {
    return {
        render: function(o) {
            n(o, t)
        },
        unmount: function() {
            o(t)
        }
    }
}
export {
    t as c
};