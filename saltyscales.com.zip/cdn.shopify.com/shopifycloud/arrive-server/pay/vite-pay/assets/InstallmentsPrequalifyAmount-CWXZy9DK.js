var e, t;
import {
    c as o
} from "./client-BR6hF_L2.js";
import {
    y as n,
    A as r,
    q as a,
    T as s,
    u as i,
    g as l
} from "./jsxRuntime.module-s_rKrABX.js";
import {
    U as u,
    A as m
} from "./AnalyticsProvider-CYuWXem_.js";
import {
    u as c
} from "./useResizeObserver-DOmnB32n.js";
import {
    S as d
} from "./account-Yv65gCKY.js";
import {
    u as f
} from "./usePostMessage-D7Rz2y04.js";
import {
    M as p
} from "./Money-C_OBdG3O.js";
import {
    u as y
} from "./usePrequalMetaData-DtuOxgf3.js";
import "./notifier-O9x9Qeiy.js";
import "./checkout-D6TL_3JE.js";
import "./constants-BNBWRhWe.js";
import "./formatMoney-kgZkg0r5.js";
const g = "_Container_1u0wo_103";
const v = {
    format: "${{amount_no_decimals}}",
    decimal_mark: ".",
    thousands_separator: ","
};

function h({
    targetOrigin: e,
    error: t
}) {
    const {
        userFound: o,
        prequalifiedAmount: l,
        userInstallmentsOnboarded: u
    } = y(), m = r(null), {
        messageResized: h,
        messageLoaded: S,
        messageError: F,
        messageCustomFlowSideEffect: j
    } = f(e, !1), w = a((e => j({
        flow: "prequal",
        shopPayInstallmentsOnboarded: Boolean(u),
        fontAssetLoaded: e
    })), [j, u]);
    c({
        ref: m,
        onResize: ({
            width: e,
            height: t
        }) => {
            e && t && h({
                width: e,
                height: t
            })
        }
    });
    const _ = s((() => t ? {
        message: t,
        code: d.PreqaulAmountError
    } : (null == l ? void 0 : l.value) ? null : {
        message: "no_prequalification_amount_available",
        code: d.PreqaulAmountError
    }), [t, null == l ? void 0 : l.value]);
    n((() => {
        o && u && (_ ? F(_) : S({
            userFound: o
        }))
    }), [F, S, _, o, u]);
    return function({
        onSetComponentStyle: e
    }) {
        n((() => {
            function t(t) {
                const {
                    type: o,
                    ...n
                } = t.data, {
                    style: r
                } = n;
                "setcomponentstyle" === o && (null == e || e({
                    style: r
                }))
            }
            return window.addEventListener("message", t), () => window.removeEventListener("message", t)
        }), [e])
    }({
        onSetComponentStyle: a((({
            style: e
        }) => {
            const {
                fontFace: t
            } = e;
            if (_) return;
            m.current && (m.current.style.letterSpacing = e.letterSpacing, m.current.style.fontSize = e.fontSize, m.current.style.color = e.color);
            t && t.length > 0 ? Promise.all(t.map((e => {
                const t = e.src,
                    o = new FontFace(e.fontFamily, t, e.fontFaceDescriptors);
                return document.fonts.add(o), o.load()
            }))).then((() => {
                document.fonts.check(`${e.fontSize} ${e.fontFamily}`) && m.current && (m.current.style.fontFamily = e.fontFamily)
            })).finally((() => {
                var t;
                return w((null == (t = m.current) ? void 0 : t.style.fontFamily) === e.fontFamily)
            })).catch((e => {})) : w(!1)
        }), [_, w])
    }), !(null == l ? void 0 : l.value) || _ ? null : i("div", {
        ref: m,
        className: g,
        "data-testid": "prequal-amount-output",
        children: i(p, {
            amount: l.value.toString(),
            currencyFormat: v
        })
    })
}
const S = null == (e = l("target-origin-url")) ? void 0 : e.toString(),
    F = null == (t = l("analytics-trace-id")) ? void 0 : t.toString();
var j;
j = document.getElementById("app"), o(j).render(i(m, {
    analyticsTraceId: F,
    uiSection: u.InstallmentsPrequalAmount,
    children: i(h, {
        targetOrigin: S
    })
}));