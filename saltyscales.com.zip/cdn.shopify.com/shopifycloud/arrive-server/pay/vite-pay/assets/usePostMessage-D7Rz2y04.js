import {
    q as e,
    T as s
} from "./jsxRuntime.module-s_rKrABX.js";

function t(t, o) {
    const a = e((e => {
        if (!t) return;
        const s = o ? window.opener : window.parent;
        null == s || s.postMessage(e, t)
    }), [t, o]);
    return s((() => function(e) {
        return s => a({
            type: e,
            ...s
        })
    }), [a])
}

function o(e, o) {
    const a = t(e, o),
        n = s((() => a("verification_step_changed")), [a]),
        r = s((() => a("authorize_step_changed")), [a]);
    return s((() => ({
        messageCloseRequested: a("close_requested"),
        messageContent: a("content"),
        messageRestarted: a("restarted"),
        messageEmailChangeRequested: a("email_change_requested"),
        messageEmailSubmitted: a("email_submitted"),
        messageError: a("error"),
        messageLoaded: a("loaded"),
        messageLoginComplete: a("completed"),
        messageCustomFlowSideEffect: a("custom_flow_side_effect"),
        messageProcessing: a("processing_status_updated"),
        messageResized: a("resize_iframe"),
        messageShopUserMatched: a("shop_user_matched"),
        messageShopUserNotMatched: a("shop_user_not_matched"),
        messageVerificationSuccess: a("user_verified"),
        messageAuthorizeStepChanged: e => {
            n(e), r(e)
        },
        messagePopUpOpened: a("pop_up_opened"),
        messagePromptChange: a("prompt_change"),
        messagePromptContinue: a("prompt_continue")
    })), [a, r, n])
}
export {
    t as a, o as u
};