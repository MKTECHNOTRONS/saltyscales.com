var t, e = (t, e, i) => {
    if (!e.has(t)) throw TypeError("Cannot " + i)
};

function i(t) {
    return null !== window.location.href.match(new RegExp(`^https://${t}/`))
}

function r(t) {
    return i(`[0-9a-z.-]+.${t}`)
}

function n() {
    return r("spin.dev") || r("tunnel.shopifycloud.tech") || r("shop.dev") || i("arrive-server-staging(|-lqmn).shopifycloud.com")
}

function s() {
    return !n() && (!!window.ShopifyPay && window.ShopifyPay.Config.isProduction)
}
var a = 0;

function o(t) {
    return "__private_" + a++ + "_" + t
}

function u(t, e) {
    if (!Object.prototype.hasOwnProperty.call(t, e)) throw new TypeError("attempted to use private field on non-instance");
    return t
}

function c(t) {
    return Object.entries(t).map((([t, e]) => ({
        key: t,
        value: {
            stringValue: String(e)
        }
    })))
}
const l = function(t, e, i) {
    const r = [0];
    for (let n = 0; n < i; n++) {
        const i = Math.floor(t * e ** n);
        r.push(i)
    }
    return r
}(5, 2, 12);
var h = o("exporter"),
    m = o("attributes"),
    p = o("metrics");
class d {
    constructor({
        exporter: t,
        attributes: e
    }) {
        Object.defineProperty(this, h, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, m, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, p, {
            writable: !0,
            value: []
        }), u(this, h)[h] = t, u(this, m)[m] = null != e ? e : {}
    }
    addAttributes(t) {
        u(this, m)[m] = { ...u(this, m)[m],
            ...t
        }
    }
    histogram({
        name: t,
        value: e,
        unit: i,
        bounds: r,
        attributes: n
    }) {
        const s = 1e6 * Date.now();
        u(this, p)[p].push({
            name: t,
            type: "histogram",
            value: e,
            unit: i,
            timeUnixNano: s,
            attributes: n,
            bounds: r
        })
    }
    counter({
        name: t,
        value: e,
        unit: i,
        attributes: r
    }) {
        const n = 1e6 * Date.now();
        u(this, p)[p].push({
            name: t,
            type: "counter",
            value: e,
            unit: i,
            timeUnixNano: n,
            attributes: r
        })
    }
    gauge({
        name: t,
        value: e,
        unit: i,
        attributes: r
    }) {
        const n = 1e6 * Date.now();
        u(this, p)[p].push({
            name: t,
            type: "gauge",
            value: e,
            unit: i,
            timeUnixNano: n,
            attributes: r
        })
    }
    async exportMetrics() {
        const t = {};
        u(this, p)[p].forEach((e => {
            switch (e.attributes = { ...u(this, m)[m],
                ...e.attributes
            }, e.type) {
                case "histogram":
                    ! function(t, e) {
                        var i;
                        const {
                            name: r,
                            value: n,
                            unit: s,
                            timeUnixNano: a,
                            attributes: o
                        } = e, u = null !== (i = e.bounds) && void 0 !== i ? i : l, h = new Array(u.length + 1).fill(0);
                        t[r] || (t[r] = {
                            name: r,
                            unit: s || "1",
                            histogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        });
                        for (let c = 0; c < h.length; c++) {
                            const t = u[c];
                            if (void 0 === t) h[c] = 1;
                            else if (n <= t) {
                                h[c] = 1;
                                break
                            }
                        }
                        t[r].histogram.dataPoints.push({
                            startTimeUnixNano: a,
                            timeUnixNano: a,
                            count: 1,
                            sum: n,
                            min: n,
                            max: n,
                            bucketCounts: h,
                            explicitBounds: u,
                            attributes: c(null != o ? o : {})
                        })
                    }(t, e);
                    break;
                case "counter":
                    ! function(t, e) {
                        const {
                            name: i,
                            value: r,
                            unit: n,
                            timeUnixNano: s,
                            attributes: a
                        } = e;
                        t[i] || (t[i] = {
                            name: i,
                            unit: n || "1",
                            sum: {
                                aggregationTemporality: 1,
                                isMonotonic: !0,
                                dataPoints: []
                            }
                        }), t[i].sum.dataPoints.push({
                            startTimeUnixNano: s,
                            timeUnixNano: s,
                            asDouble: r,
                            attributes: c(null != a ? a : {})
                        })
                    }(t, e);
                    break;
                case "gauge":
                    ! function(t, e) {
                        const {
                            name: i,
                            value: r,
                            unit: n,
                            timeUnixNano: s,
                            attributes: a
                        } = e;
                        t[i] || (t[i] = {
                            name: i,
                            unit: n || "1",
                            gauge: {
                                dataPoints: []
                            }
                        }), t[i].gauge.dataPoints.push({
                            startTimeUnixNano: s,
                            timeUnixNano: s,
                            asDouble: r,
                            attributes: c(null != a ? a : {})
                        })
                    }(t, e)
            }
        }));
        const e = Object.values(t);
        0 !== e.length && (u(this, p)[p] = [], await u(this, h)[h].exportMetrics(e))
    }
}
var v = o("url"),
    f = o("serviceName"),
    w = o("logger");
class b extends Error {
    constructor(t, e) {
        super(t), this.metadata = void 0, this.name = "OpenTelemetryClientError", this.metadata = e
    }
}
t = new WeakMap;
class g {
    constructor(t, e) {
        this.telemetry = t, this.metric = e, this.startTime = window.performance.now()
    }
    end(t) {
        const e = window.performance.now();
        this.telemetry.histogram({ ...this.metric,
            ...t,
            value: e - this.startTime
        })
    }
}
const y = new class {
        constructor(t, e, i) {
            Object.defineProperty(this, v, {
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, f, {
                writable: !0,
                value: void 0
            }), Object.defineProperty(this, w, {
                writable: !0,
                value: void 0
            }), u(this, v)[v] = t, u(this, f)[f] = e, u(this, w)[w] = null == i ? void 0 : i.logger
        }
        async exportMetrics(t) {
            var e;
            const i = {
                    resourceMetrics: [{
                        resource: {
                            attributes: [{
                                key: "service.name",
                                value: {
                                    stringValue: u(this, f)[f]
                                }
                            }]
                        },
                        scopeMetrics: [{
                            scope: {
                                name: "open-telemetry-mini-client",
                                version: "0.3.3",
                                attributes: []
                            },
                            metrics: t
                        }]
                    }]
                },
                r = await fetch(u(this, v)[v], {
                    method: "POST",
                    keepalive: !0,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(i)
                });
            if (null === (e = u(this, w)[w]) || void 0 === e || e.log({
                    status: r.status
                }), !r.ok) {
                if (400 === r.status) {
                    const t = await r.text();
                    throw new b(`Invalid OpenTelemetry Metrics: ${t}`)
                }
                if (429 === r.status || 503 === r.status) {
                    const e = await r.json(),
                        i = r.headers.get("Retry-After"),
                        n = i ? {
                            seconds: Number(i)
                        } : void 0;
                    throw new b("Server did not accept metrics", {
                        errorData: e,
                        retryAfter: n,
                        metrics: t
                    })
                }
                throw new b(`Server responded with ${r.status}`)
            }
        }
    }("https://otlp-http-production.shopifysvc.com/v1/metrics", "shop-server-js"),
    x = {
        exportMetrics: async t => (console.log("[36m [Log: metrics]: [0m", JSON.stringify(t)), Promise.resolve())
    },
    P = n() ? x : new class {
        constructor(i) {
            var r, n, s, a;
            ((t, e, i) => {
                if (e.has(t)) throw TypeError("Cannot add the same private member more than once");
                e instanceof WeakSet ? e.add(t) : e.set(t, i)
            })(this, t, void 0), s = i, e(r = this, n = t, "write to private field"), a ? a.call(r, s) : n.set(r, s)
        }
        async exportMetrics(i) {
            var r, n, s, a;
            try {
                await (n = this, s = t, e(n, s, "read from private field"), a ? a.call(n) : s.get(n)).exportMetrics(i)
            } catch (o) {
                if (o instanceof b) {
                    const t = null == (r = o.metadata) ? void 0 : r.retryAfter;
                    if (t) return void(await new Promise((e => {
                        setTimeout((() => this.exportMetrics(i).finally(e)), 1e3 * t.seconds)
                    })))
                }
                throw o
            }
        }
    }(y),
    N = new class extends d {
        counter(t) {
            super.counter(t), this.exportMetrics()
        }
        histogram(t) {
            super.histogram(t), this.exportMetrics()
        }
        timing(t) {
            return new g(this, t)
        }
    }({
        exporter: P
    });
export {
    n as a, s as i, N as o
};