import {
    x as e,
    K as t,
    T as o,
    q as n,
    u as r
} from "./jsxRuntime.module-s_rKrABX.js";
import {
    B as a
} from "./notifier-O9x9Qeiy.js";
import {
    C as i
} from "./checkout-D6TL_3JE.js";
import {
    i as s,
    a as c,
    o as u
} from "./constants-BNBWRhWe.js";
const d = [];
for (let fe = 0; fe < 256; ++fe) d.push((fe + 256).toString(16).slice(1));
let l;
const p = new Uint8Array(16);
const h = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};

function f(e, t, o) {
    var n;
    if (h.randomUUID && !t && !e) return h.randomUUID();
    const r = (e = e || {}).random ? ? (null == (n = e.rng) ? void 0 : n.call(e)) ? ? function() {
        if (!l) {
            if ("undefined" == typeof crypto || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            l = crypto.getRandomValues.bind(crypto)
        }
        return l(p)
    }();
    if (r.length < 16) throw new Error("Random bytes length must be >= 16");
    if (r[6] = 15 & r[6] | 64, r[8] = 63 & r[8] | 128, t) {
        if ((o = o || 0) < 0 || o + 16 > t.length) throw new RangeError(`UUID byte range ${o}:${o+15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) t[o + e] = r[e];
        return t
    }
    return function(e, t = 0) {
        return (d[e[t + 0]] + d[e[t + 1]] + d[e[t + 2]] + d[e[t + 3]] + "-" + d[e[t + 4]] + d[e[t + 5]] + "-" + d[e[t + 6]] + d[e[t + 7]] + "-" + d[e[t + 8]] + d[e[t + 9]] + "-" + d[e[t + 10]] + d[e[t + 11]] + d[e[t + 12]] + d[e[t + 13]] + d[e[t + 14]] + d[e[t + 15]]).toLowerCase()
    }(r)
}

function m(e, t, o) {
    return (t = function(e) {
        var t = function(e, t) {
            if ("object" != typeof e || !e) return e;
            var o = e[Symbol.toPrimitive];
            if (void 0 !== o) {
                var n = o.call(e, t);
                if ("object" != typeof n) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === t ? String : Number)(e)
        }(e, "string");
        return "symbol" == typeof t ? t : t + ""
    }(t)) in e ? Object.defineProperty(e, t, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = o, e
}

function g(e, t) {
    var o = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter((function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        }))), o.push.apply(o, n)
    }
    return o
}

function y(e) {
    for (var t = 1; t < arguments.length; t++) {
        var o = null != arguments[t] ? arguments[t] : {};
        t % 2 ? g(Object(o), !0).forEach((function(t) {
            m(e, t, o[t])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : g(Object(o)).forEach((function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t))
        }))
    }
    return e
}
const v = "http://localhost:8082",
    w = "https://monorail-edge.shopifysvc.com",
    b = "/v1/produce";

function _(e) {
    return void 0 !== e.schemaId
}
class E {
    constructor(e) {
        this.producer = e
    }
    do(e, t) {
        return _(e) ? this.producer.produce(e) : this.producer.produceBatch(e)
    }
}

function I() {
    if ("undefined" != typeof crypto && crypto && "function" == typeof crypto.randomUUID) return crypto.randomUUID();
    const e = new Array(36);
    for (let t = 0; t < 36; t++) e[t] = Math.floor(16 * Math.random());
    return e[14] = 4, e[19] = e[19] &= -5, e[19] = e[19] |= 8, e[8] = e[13] = e[18] = e[23] = "-", e.map((e => e.toString(16))).join("")
}

function M(e) {
    if (e.metadata || e.consent) return y(y({}, e.metadata), e.consent && {
        consent: e.consent,
        consent_provider: e.consent_provider,
        consent_version: e.consent_version
    })
}

function P(e, t = !0) {
    return e && Object.keys(e).length && t ? Object.keys(e).map((t => ({
        [O(t)]: e[t]
    }))).reduce(((e, t) => y(y({}, e), t))) : e
}

function O(e) {
    return e.split(/(?=[A-Z])/).join("_").toLowerCase()
}

function C(e) {
    return e.events.map((e => {
        let t = !0,
            o = !0;
        e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (t = Boolean(e.options.convertEventCase)), e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertMetaDataCase") && (o = Boolean(e.options.convertMetaDataCase));
        const n = M(e);
        return y({
            schema_id: e.schemaId,
            payload: P(e.payload, t)
        }, n && {
            metadata: P(n, o)
        })
    }))
}
class k extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), m(this, "name", "MonorailUnableToProduceError"), this.response = e, Object.setPrototypeOf(this, k.prototype)
    }
}
class j extends Error {
    constructor(e) {
        super(`Response not from Monorail Edge. Response received: ${JSON.stringify(e)}`), m(this, "name", "MonorailInterceptedProduceError"), this.response = e, Object.setPrototypeOf(this, j.prototype)
    }
}
class A extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), m(this, "name", "MonorailBatchProduceError"), Object.setPrototypeOf(this, A.prototype), this.response = e
    }
}
class S extends Error {
    constructor(e, t) {
        super(`Error completing request. A network failure may have prevented the request from completing. Error: ${e}. Schemas: ${Array.from(new Set(t)).join(", ")}`), m(this, "name", "MonorailRequestError"), Object.setPrototypeOf(this, S.prototype)
    }
}
class U {
    static withEndpoint(e) {
        return new U(`https://${new URL(e).hostname}`)
    }
    constructor(e = v, t = {}) {
        var o, n;
        if (this.edgeDomain = e, this.optionsOrKeepalive = t, "boolean" == typeof t) return this.keepalive = t, void(this.detectInterceptedErrorEnabled = !1);
        this.keepalive = null !== (o = t.keepalive) && void 0 !== o && o, this.detectInterceptedErrorEnabled = null !== (n = t.detectInterceptedErrorEnabled) && void 0 !== n && n
    }
    async produceBatch(e) {
        const t = {
            events: C(e),
            metadata: P(e.metadata)
        };
        let o;
        try {
            o = await fetch(this.produceBatchEndpoint(), {
                method: "post",
                headers: D(e.metadata),
                body: JSON.stringify(t),
                keepalive: this.keepalive
            })
        } catch (n) {
            throw new S(n, e.events.map((e => e.schemaId)))
        }
        if (207 === o.status) {
            const e = await o.json();
            throw new A(e)
        }
        if (!o.ok) {
            if (!Boolean(o.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new j({
                status: o.status,
                message: await o.text()
            });
            throw new k({
                status: o.status,
                message: await o.text()
            })
        }
        return {
            status: o.status
        }
    }
    async produce(e) {
        let t, o = !0;
        e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (o = Boolean(e.options.convertEventCase));
        try {
            t = await async function({
                endpoint: e,
                event: t,
                keepalive: o
            }) {
                var n, r;
                const a = t.metadata ? {
                        clientMessageId: null === (n = t.metadata) || void 0 === n ? void 0 : n.clientMessageId,
                        eventCreatedAtMs: null === (r = t.metadata) || void 0 === r ? void 0 : r.eventCreatedAtMs
                    } : {},
                    i = M(y(y({}, t), {}, {
                        metadata: a
                    }));
                return fetch(null != e ? e : w + b, {
                    method: "post",
                    headers: D(t.metadata),
                    body: JSON.stringify(y({
                        schema_id: t.schemaId,
                        payload: t.payload
                    }, i && {
                        metadata: P(i, !0)
                    })),
                    keepalive: o
                })
            }({
                endpoint: this.produceEndpoint(),
                keepalive: this.keepalive,
                event: y(y({}, e), {}, {
                    payload: P(e.payload, o)
                })
            })
        } catch (n) {
            throw new S(n, [e.schemaId])
        }
        if (!t) throw new k({
            message: "No response from edge"
        });
        if (!t.ok) {
            if (!Boolean(t.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new j({
                status: t.status,
                message: await t.text()
            });
            throw new k({
                status: t.status,
                message: await t.text()
            })
        }
        return {
            status: t.status
        }
    }
    produceBatchEndpoint() {
        return this.edgeDomain + "/unstable/produce_batch"
    }
    produceEndpoint() {
        return this.edgeDomain + b
    }
}

function D(e) {
    const t = {
        "Content-Type": "application/json; charset=utf-8",
        "X-Monorail-Edge-Event-Created-At-Ms": (e && e.eventCreatedAtMs || Date.now()).toString(),
        "X-Monorail-Edge-Event-Sent-At-Ms": Date.now().toString(),
        "X-Monorail-Edge-Client-Message-Id": (e && e.clientMessageId || I()).toString()
    };
    return e && e.userAgent && (t["User-Agent"] = e.userAgent), e && e.remoteIp && (t["X-Forwarded-For"] = e.remoteIp), e && e.deviceInstallId && (t["X-Monorail-Edge-Device-Install-Id"] = e.deviceInstallId), e && e.client && (t["X-Monorail-Edge-Client"] = e.client), e && e.clientOs && (t["X-Monorail-Edge-Client-OS"] = e.clientOs), t
}
class x {
    static printWelcomeMessage(e) {
        console.log(`%c👋 from Monorail%c\n\nWe've noticed that you're${e?"":" not"} running in debug mode. As such, we will ${e?"produce":"not produce"} Monorail events to the console. \n\nIf you want Monorail events to ${e?"stop":"start"} appearing here, %cset debugMode=${(!e).toString()}%c, for the Monorail Log Producer in your code.`, "font-size: large;", "font-size: normal;", "font-weight: bold;", "font-weight: normal;")
    }
    constructor(e) {
        this.sendToConsole = e, e && x.printWelcomeMessage(e)
    }
    async produce(e) {
        return this.sendToConsole && console.log("Monorail event produced", e), new Promise((t => {
            t(e)
        }))
    }
    produceBatch(e) {
        return this.sendToConsole && console.log("Monorail Batch event produced", e), new Promise((t => {
            t(e)
        }))
    }
}
class z {
    static createLogProducer(e) {
        return new z(new x(e.debugMode), e.middleware || [])
    }
    static createHttpProducerWithEndpoint(e, t = []) {
        return new z(U.withEndpoint(e), t)
    }
    static createHttpProducer(e) {
        return new z(e.production ? new U(w, e.options) : new U(v, e.options), e.middleware || [])
    }
    static buildMiddlewareChain(e, t = 0) {
        return t === e.length ? this.identityFn : o => e[t].do(o, this.buildMiddlewareChain(e, t + 1))
    }
    constructor(e, t) {
        this.producer = e, this.middleware = t, this.executeChain = z.buildMiddlewareChain(this.middleware.concat(new E(e)))
    }
    produce(e) {
        return e.metadata = y({
            eventCreatedAtMs: Date.now(),
            clientMessageId: I()
        }, e.metadata), this.executeChain(e)
    }
    produceBatch(e) {
        return this.executeChain(e)
    }
}
class T {
    constructor(e) {
        this.version = e.version
    }
}
class q {
    constructor(e) {
        if ((null == e ? void 0 : e.provider) instanceof T == !1) throw new B("ConsentTrackingMiddleware requires an instance of ConsentTrackingProvider");
        this.provider = e.provider
    }
    async do(e, t) {
        if (_(e)) return t(await this.provider.annotateEvent(e));
        const o = await Promise.all(e.events.map((e => this.provider.annotateEvent(e))));
        return t(y(y({}, e), {}, {
            events: o
        }))
    }
}
class B extends Error {
    constructor(e) {
        super(e), Object.setPrototypeOf(this, B.prototype)
    }
}
const R = "",
    $ = "1",
    L = "0",
    N = "p",
    V = "a",
    X = "m",
    J = "t",
    F = "m",
    W = "a",
    H = "p",
    K = "s";

function Z(e) {
    try {
        return decodeURIComponent(e)
    } catch (t) {
        return ""
    }
}

function G(e, t = !1) {
    const o = document.cookie ? document.cookie.split("; ") : [];
    for (let n = 0; n < o.length; n++) {
        const [t, r] = o[n].split("=");
        if (e === Z(t)) {
            return Z(r)
        }
    }
    if (t && "_tracking_consent" === e && !window.localStorage.getItem("tracking_consent_fetched")) {
        if ("undefined" != typeof __CtaTestEnv__ && "true" === __CtaTestEnv__) return;
        return console.debug("_tracking_consent missing"),
            function(e = "/") {
                const t = new XMLHttpRequest;
                t.open("HEAD", e, !1), t.withCredentials = !0, t.send()
            }(), window.localStorage.setItem("tracking_consent_fetched", "true"), G(e, !1)
    }
}

function Q() {
    const e = new URLSearchParams(window.location.search).get("_cs") || G("_tracking_consent");
    if (void 0 !== e) return function(e) {
        const t = e.slice(0, 1);
        if ("{" == t) return function(e) {
            var t;
            let o;
            try {
                o = JSON.parse(e)
            } catch {
                return
            }
            if ("2.1" !== o.v) return;
            if (null === (t = o.con) || void 0 === t || !t.CMP) return;
            return o
        }(e);
        if ("3" == t) return function(e) {
            const t = e.slice(1).split("_"),
                [o, n, r, a, i] = t;
            let s, c;
            try {
                s = t[5] ? JSON.parse(t.slice(5).join("_")) : void 0
            } catch {}
            if (i) {
                const e = i.replace(/\*/g, "/").replace(/-/g, "+"),
                    t = Array.from(atob(e)).map((e => e.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                c = [8, 13, 18, 23].reduce(((e, t) => e.slice(0, t) + "-" + e.slice(t)), t)
            }

            function u(e) {
                const t = o.split(".")[0];
                return t.includes(e.toLowerCase()) ? L : t.includes(e.toUpperCase()) ? $ : R
            }

            function d(e) {
                return o.includes(e.replace("t", "s").toUpperCase())
            }
            return {
                v: "3",
                con: {
                    CMP: {
                        [W]: u(W),
                        [H]: u(H),
                        [F]: u(F),
                        [K]: u(K)
                    }
                },
                region: n || "",
                cus: s,
                purposes: {
                    [V]: d(V),
                    [N]: d(N),
                    [X]: d(X),
                    [J]: d(J)
                },
                sale_of_data_region: "t" == a,
                display_banner: "t" == r,
                consent_id: c
            }
        }(e);
        return
    }(e)
}

function Y(e) {
    const t = Q();
    if (!t || !t.purposes) return !0;
    const o = t.purposes[e];
    return "boolean" != typeof o || o
}

function ee() {
    return Y(V)
}

function te() {
    return Y(N)
}

function oe() {
    return Y(X)
}

function ne() {
    return Y(J)
}

function re() {
    const e = [];
    return ee() && e.push("analytics"), oe() && e.push("marketing"), ne() && e.push("sale_of_data"), te() && e.push("preferences"), e
}
class ae extends T {
    async annotateEvent(e) {
        return Promise.resolve(function(e, t) {
            if ("v1" === t) {
                const o = re();
                return { ...e,
                    metadata: { ...null == e ? void 0 : e.metadata,
                        consent: o,
                        consent_provider: "consent-tracking-api",
                        consent_version: t
                    }
                }
            }
            throw new ie(t || "unknown")
        }(e, this.version))
    }
}
class ie extends Error {
    constructor(e) {
        super(`Version ${e} is not supported by the consent-tracking-api provider`), this.name = "MonorailConsentTrackingApiProviderVersionError", Object.setPrototypeOf(this, ie.prototype)
    }
}
class se extends Error {
    constructor(e, t) {
        super(`${e} must be used within a <${t}>`), this.name = "ContextWithoutProviderError"
    }
}

function ce(t, o, n) {
    const r = e(t);
    if (void 0 === r) throw new se(o, n);
    return r
}
const ue = "shop_accounts_identity_verification_ui_event/2.4";
var de = (e => (e.Account = "account", e.AccountLogin = "account_login", e.AuthorizeDefault = "authorize_default", e.AuthorizeDiscount = "authorize_discount", e.AuthorizeFollow = "authorize_follow", e.AuthorizePopUp = "authorize_pop_up", e.AuthorizePrequal = "authorize_prequal", e.AuthorizeThirdParty = "authorize_third_party", e.ChangeEmail = "change_email", e.InstallmentsIframe = "installments_iframe", e.InstallmentsPrequal = "installments_prequal", e.InstallmentsPrequalAmount = "installments_prequal_amount", e.Login = "login", e.LoginSeamless = "loginSeamless", e.Modal = "modal", e.PaymentPage = "payment_page", e.ShopAuthInput = "shop_auth_input", e.Webauthn = "webauthn", e))(de || {});
const le = t(void 0);

function pe({
    analyticsTraceId: e,
    authorizationFlowId: t,
    checkoutVersion: d = i.Classic,
    children: l,
    clientUuid: p,
    parentPageLoadId: h,
    publicId: m,
    shopAccountUuid: g,
    shopId: y,
    shopifyDomain: v = "",
    token: w,
    uiSection: b
}) {
    const _ = o((() => {
            const e = [];
            return d === i.CheckoutOne && w && "undefined" != typeof window && e.push(function() {
                const e = new ae({
                    version: "v1"
                });
                return new q({
                    provider: e
                })
            }()), e
        }), [d, w]),
        E = o((() => s() ? z.createHttpProducer({
            production: !0,
            middleware: _
        }) : z.createLogProducer({
            debugMode: c(),
            middleware: _
        })), [_]),
        I = o((() => e ? ? f()), [e]),
        M = o((() => ({
            analyticsTraceId: I,
            ...t && {
                authorizationFlowId: t
            },
            ...w && {
                checkoutToken: w
            },
            ...d && {
                checkoutVersion: d
            },
            ...p && {
                clientUuid: p
            },
            ...m && {
                publicId: m
            },
            ...g && {
                shopAccountUuid: g
            },
            ...y && {
                shopId: y
            },
            ...v && {
                shopifyDomain: v
            }
        })), [I, t, w, d, p, m, g, y, v]),
        P = n((e => [e === ue, null != p && "authorize_default" === b, "authorize_discount" === b, "authorize_follow" === b, "authorize_prequal" === b, "authorize_pop_up" === b, "shop_auth_input" === b, "installments_prequal" === b, null != w, null != p && null != t, null != m || "account_login" === b].some(Boolean)), [t, w, p, m, b]),
        O = n((e => {
            if (!E) return;
            if (!P(e.schemaId)) return void a.notify("Unexpected params for trackMonorail", (t => {
                t.addMetadata("monorail", {
                    schemaId: e.schemaId,
                    payload: e.payload,
                    globalPayload: M,
                    uiSection: b
                })
            }));
            try {
                E.produce({
                    schemaId: e.schemaId,
                    payload: { ...M,
                        ...e.payload
                    }
                })
            } catch (t) {
                (e => !e.message.includes("Cannot read property 'randomUUID' of undefined"))(t) ? a.notify("Error producing monorail event", (t => {
                    t.addMetadata("monorail", {
                        schemaId: e.schemaId,
                        payload: e.payload,
                        globalPayload: M,
                        uiSection: b
                    })
                })): console.error("Error producing monorail event", t)
            }
        }), [M, P, E, b]),
        C = o((() => ({
            checkoutVersion: d,
            openTelemetryClient: u,
            parentPageLoadId: h,
            trackMonorail: O,
            analyticsTraceId: I
        })), [d, h, O, I]);
    return r(le.Provider, {
        value: C,
        children: l
    })
}

function he() {
    return ce(le, "useAnalyticsContext", "AnalyticsProvider")
}
export {
    pe as A, se as C, ue as S, de as U, he as a, le as b, ce as u, f as v
};