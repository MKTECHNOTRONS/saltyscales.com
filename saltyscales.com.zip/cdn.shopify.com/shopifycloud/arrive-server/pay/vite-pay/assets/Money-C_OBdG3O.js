import {
    f as r
} from "./formatMoney-kgZkg0r5.js";
import {
    u as e
} from "./jsxRuntime.module-s_rKrABX.js";

function m({
    amount: m,
    currencyFormat: t,
    invoicingLabel: a = ""
}) {
    const n = a.trim(),
        o = Number(m) < 0,
        i = Math.abs(Number(m)),
        s = `${o?"−":""}${0===Math.abs(Number(m.replace(/[^0-9]+/g,"")))&&n.length>0?n:!t||Number.isNaN(i)?m:r(i,t)}`;
    return e("span", {
        children: s
    })
}
export {
    m as M
};