var e = (e => (e.Pending = "pending", e.Complete = "complete", e.Error = "error", e.NotApplicable = "not_applicable", e))(e || {}),
    a = (e => (e.Interest = "interest", e.SplitPay = "split_pay", e.ZeroPercent = "zero_percent", e))(a || {}),
    t = (e => (e.All = "all", e.None = "none", e.Interest = "interest", e.SplitPay = "split_pay", e))(t || {}),
    l = (e => (e.AlreadyApplied = "discount_already_applied", e.Invalid = "invalid", e.NotApplicable = "not_applicable", e.GiftCardAlreadyApplied = "gift_card_already_applied", e.GiftCardDepleted = "gift_card_depleted", e))(l || {}),
    p = (e => (e.CheckoutOne = "checkout_one", e.Classic = "classic", e.PaymentRequest = "payment_request", e.ShopPayExternal = "shop_pay_external", e))(p || {});
export {
    a as A, p as C, l as D, e as L, t as S
};