import {
    A as e,
    d as t,
    y as n,
    q as r,
    T as i
} from "./jsxRuntime.module-s_rKrABX.js";
var o, s, c = [],
    u = "ResizeObserver loop completed with undelivered notifications.";
(s = o || (o = {})).BORDER_BOX = "border-box", s.CONTENT_BOX = "content-box", s.DEVICE_PIXEL_CONTENT_BOX = "device-pixel-content-box";
var a, h = function(e) {
        return Object.freeze(e)
    },
    d = function() {
        return function(e, t) {
            this.inlineSize = e, this.blockSize = t, h(this)
        }
    }(),
    f = function() {
        function e(e, t, n, r) {
            return this.x = e, this.y = t, this.width = n, this.height = r, this.top = this.y, this.left = this.x, this.bottom = this.top + this.height, this.right = this.left + this.width, h(this)
        }
        return e.prototype.toJSON = function() {
            var e = this;
            return {
                x: e.x,
                y: e.y,
                top: e.top,
                right: e.right,
                bottom: e.bottom,
                left: e.left,
                width: e.width,
                height: e.height
            }
        }, e.fromRect = function(t) {
            return new e(t.x, t.y, t.width, t.height)
        }, e
    }(),
    v = function(e) {
        return e instanceof SVGElement && "getBBox" in e
    },
    l = function(e) {
        if (v(e)) {
            var t = e.getBBox(),
                n = t.width,
                r = t.height;
            return !n && !r
        }
        var i = e,
            o = i.offsetWidth,
            s = i.offsetHeight;
        return !(o || s || e.getClientRects().length)
    },
    p = function(e) {
        var t;
        if (e instanceof Element) return !0;
        var n = null === (t = null == e ? void 0 : e.ownerDocument) || void 0 === t ? void 0 : t.defaultView;
        return !!(n && e instanceof n.Element)
    },
    b = "undefined" != typeof window ? window : {},
    g = new WeakMap,
    x = /auto|scroll/,
    w = /^tb|vertical/,
    m = /msie|trident/i.test(b.navigator && b.navigator.userAgent),
    z = function(e) {
        return parseFloat(e || "0")
    },
    E = function(e, t, n) {
        return void 0 === e && (e = 0), void 0 === t && (t = 0), void 0 === n && (n = !1), new d((n ? t : e) || 0, (n ? e : t) || 0)
    },
    T = h({
        devicePixelContentBoxSize: E(),
        borderBoxSize: E(),
        contentBoxSize: E(),
        contentRect: new f(0, 0, 0, 0)
    }),
    S = function(e, t) {
        if (void 0 === t && (t = !1), g.has(e) && !t) return g.get(e);
        if (l(e)) return g.set(e, T), T;
        var n = getComputedStyle(e),
            r = v(e) && e.ownerSVGElement && e.getBBox(),
            i = !m && "border-box" === n.boxSizing,
            o = w.test(n.writingMode || ""),
            s = !r && x.test(n.overflowY || ""),
            c = !r && x.test(n.overflowX || ""),
            u = r ? 0 : z(n.paddingTop),
            a = r ? 0 : z(n.paddingRight),
            d = r ? 0 : z(n.paddingBottom),
            p = r ? 0 : z(n.paddingLeft),
            b = r ? 0 : z(n.borderTopWidth),
            S = r ? 0 : z(n.borderRightWidth),
            y = r ? 0 : z(n.borderBottomWidth),
            B = p + a,
            R = u + d,
            O = (r ? 0 : z(n.borderLeftWidth)) + S,
            C = b + y,
            k = c ? e.offsetHeight - C - e.clientHeight : 0,
            N = s ? e.offsetWidth - O - e.clientWidth : 0,
            D = i ? B + O : 0,
            M = i ? R + C : 0,
            P = r ? r.width : z(n.width) - D - N,
            _ = r ? r.height : z(n.height) - M - k,
            F = P + B + N + O,
            I = _ + R + k + C,
            L = h({
                devicePixelContentBoxSize: E(Math.round(P * devicePixelRatio), Math.round(_ * devicePixelRatio), o),
                borderBoxSize: E(F, I, o),
                contentBoxSize: E(P, _, o),
                contentRect: new f(p, u, P, _)
            });
        return g.set(e, L), L
    },
    y = function(e, t, n) {
        var r = S(e, n),
            i = r.borderBoxSize,
            s = r.contentBoxSize,
            c = r.devicePixelContentBoxSize;
        switch (t) {
            case o.DEVICE_PIXEL_CONTENT_BOX:
                return c;
            case o.BORDER_BOX:
                return i;
            default:
                return s
        }
    },
    B = function() {
        return function(e) {
            var t = S(e);
            this.target = e, this.contentRect = t.contentRect, this.borderBoxSize = h([t.borderBoxSize]), this.contentBoxSize = h([t.contentBoxSize]), this.devicePixelContentBoxSize = h([t.devicePixelContentBoxSize])
        }
    }(),
    R = function(e) {
        if (l(e)) return 1 / 0;
        for (var t = 0, n = e.parentNode; n;) t += 1, n = n.parentNode;
        return t
    },
    O = function() {
        var e = 1 / 0,
            t = [];
        c.forEach((function(n) {
            if (0 !== n.activeTargets.length) {
                var r = [];
                n.activeTargets.forEach((function(t) {
                    var n = new B(t.target),
                        i = R(t.target);
                    r.push(n), t.lastReportedSize = y(t.target, t.observedBox), i < e && (e = i)
                })), t.push((function() {
                    n.callback.call(n.observer, r, n.observer)
                })), n.activeTargets.splice(0, n.activeTargets.length)
            }
        }));
        for (var n = 0, r = t; n < r.length; n++) {
            (0, r[n])()
        }
        return e
    },
    C = function(e) {
        c.forEach((function(t) {
            t.activeTargets.splice(0, t.activeTargets.length), t.skippedTargets.splice(0, t.skippedTargets.length), t.observationTargets.forEach((function(n) {
                n.isActive() && (R(n.target) > e ? t.activeTargets.push(n) : t.skippedTargets.push(n))
            }))
        }))
    },
    k = function() {
        var e, t = 0;
        for (C(t); c.some((function(e) {
                return e.activeTargets.length > 0
            }));) t = O(), C(t);
        return c.some((function(e) {
            return e.skippedTargets.length > 0
        })) && ("function" == typeof ErrorEvent ? e = new ErrorEvent("error", {
            message: u
        }) : ((e = document.createEvent("Event")).initEvent("error", !1, !1), e.message = u), window.dispatchEvent(e)), t > 0
    },
    N = [],
    D = function(e) {
        if (!a) {
            var t = 0,
                n = document.createTextNode("");
            new MutationObserver((function() {
                return N.splice(0).forEach((function(e) {
                    return e()
                }))
            })).observe(n, {
                characterData: !0
            }), a = function() {
                n.textContent = "".concat(t ? t-- : t++)
            }
        }
        N.push(e), a()
    },
    M = 0,
    P = {
        attributes: !0,
        characterData: !0,
        childList: !0,
        subtree: !0
    },
    _ = ["resize", "load", "transitionend", "animationend", "animationstart", "animationiteration", "keyup", "keydown", "mouseup", "mousedown", "mouseover", "mouseout", "blur", "focus"],
    F = function(e) {
        return void 0 === e && (e = 0), Date.now() + e
    },
    I = !1,
    L = new(function() {
        function e() {
            var e = this;
            this.stopped = !0, this.listener = function() {
                return e.schedule()
            }
        }
        return e.prototype.run = function(e) {
            var t = this;
            if (void 0 === e && (e = 250), !I) {
                I = !0;
                var n, r = F(e);
                n = function() {
                    var n = !1;
                    try {
                        n = k()
                    } finally {
                        if (I = !1, e = r - F(), !M) return;
                        n ? t.run(1e3) : e > 0 ? t.run(e) : t.start()
                    }
                }, D((function() {
                    requestAnimationFrame(n)
                }))
            }
        }, e.prototype.schedule = function() {
            this.stop(), this.run()
        }, e.prototype.observe = function() {
            var e = this,
                t = function() {
                    return e.observer && e.observer.observe(document.body, P)
                };
            document.body ? t() : b.addEventListener("DOMContentLoaded", t)
        }, e.prototype.start = function() {
            var e = this;
            this.stopped && (this.stopped = !1, this.observer = new MutationObserver(this.listener), this.observe(), _.forEach((function(t) {
                return b.addEventListener(t, e.listener, !0)
            })))
        }, e.prototype.stop = function() {
            var e = this;
            this.stopped || (this.observer && this.observer.disconnect(), _.forEach((function(t) {
                return b.removeEventListener(t, e.listener, !0)
            })), this.stopped = !0)
        }, e
    }()),
    W = function(e) {
        !M && e > 0 && L.start(), !(M += e) && L.stop()
    },
    X = function() {
        function e(e, t) {
            this.target = e, this.observedBox = t || o.CONTENT_BOX, this.lastReportedSize = {
                inlineSize: 0,
                blockSize: 0
            }
        }
        return e.prototype.isActive = function() {
            var e, t = y(this.target, this.observedBox, !0);
            return e = this.target, v(e) || function(e) {
                switch (e.tagName) {
                    case "INPUT":
                        if ("image" !== e.type) break;
                    case "VIDEO":
                    case "AUDIO":
                    case "EMBED":
                    case "OBJECT":
                    case "CANVAS":
                    case "IFRAME":
                    case "IMG":
                        return !0
                }
                return !1
            }(e) || "inline" !== getComputedStyle(e).display || (this.lastReportedSize = t), this.lastReportedSize.inlineSize !== t.inlineSize || this.lastReportedSize.blockSize !== t.blockSize
        }, e
    }(),
    A = function() {
        return function(e, t) {
            this.activeTargets = [], this.skippedTargets = [], this.observationTargets = [], this.observer = e, this.callback = t
        }
    }(),
    V = new WeakMap,
    q = function(e, t) {
        for (var n = 0; n < e.length; n += 1)
            if (e[n].target === t) return n;
        return -1
    },
    j = function() {
        function e() {}
        return e.connect = function(e, t) {
            var n = new A(e, t);
            V.set(e, n)
        }, e.observe = function(e, t, n) {
            var r = V.get(e),
                i = 0 === r.observationTargets.length;
            q(r.observationTargets, t) < 0 && (i && c.push(r), r.observationTargets.push(new X(t, n && n.box)), W(1), L.schedule())
        }, e.unobserve = function(e, t) {
            var n = V.get(e),
                r = q(n.observationTargets, t),
                i = 1 === n.observationTargets.length;
            r >= 0 && (i && c.splice(c.indexOf(n), 1), n.observationTargets.splice(r, 1), W(-1))
        }, e.disconnect = function(e) {
            var t = this,
                n = V.get(e);
            n.observationTargets.slice().forEach((function(n) {
                return t.unobserve(e, n.target)
            })), n.activeTargets.splice(0, n.activeTargets.length)
        }, e
    }(),
    G = function() {
        function e(e) {
            if (0 === arguments.length) throw new TypeError("Failed to construct 'ResizeObserver': 1 argument required, but only 0 present.");
            if ("function" != typeof e) throw new TypeError("Failed to construct 'ResizeObserver': The callback provided as parameter 1 is not a function.");
            j.connect(this, e)
        }
        return e.prototype.observe = function(e, t) {
            if (0 === arguments.length) throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': 1 argument required, but only 0 present.");
            if (!p(e)) throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': parameter 1 is not of type 'Element");
            j.observe(this, e, t)
        }, e.prototype.unobserve = function(e) {
            if (0 === arguments.length) throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': 1 argument required, but only 0 present.");
            if (!p(e)) throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': parameter 1 is not of type 'Element");
            j.unobserve(this, e)
        }, e.prototype.disconnect = function() {
            j.disconnect(this)
        }, e.toString = function() {
            return "function ResizeObserver () { [polyfill code] }"
        }, e
    }();

function H(e, t, n) {
    return e[t] ? e[t][0] ? e[t][0][n] : e[t][n] : "contentBoxSize" === t ? e.contentRect["inlineSize" === n ? "width" : "height"] : void 0
}

function J(o) {
    void 0 === o && (o = {});
    var s = o.onResize,
        c = e(void 0);
    c.current = s;
    var u = o.round || Math.round,
        a = e(),
        h = t({
            width: void 0,
            height: void 0
        }),
        d = h[0],
        f = h[1],
        v = e(!1);
    n((function() {
        return v.current = !1,
            function() {
                v.current = !0
            }
    }), []);
    var l = e({
            width: void 0,
            height: void 0
        }),
        p = function(t, i) {
            var o = e(null),
                s = e(null);
            s.current = i;
            var c = e(null);
            n((function() {
                u()
            }));
            var u = r((function() {
                var e = c.current,
                    n = s.current,
                    r = e || (n ? n instanceof Element ? n : n.current : null);
                o.current && o.current.element === r && o.current.subscriber === t || (o.current && o.current.cleanup && o.current.cleanup(), o.current = {
                    element: r,
                    subscriber: t,
                    cleanup: r ? t(r) : void 0
                })
            }), [t]);
            return n((function() {
                return function() {
                    o.current && o.current.cleanup && (o.current.cleanup(), o.current = null)
                }
            }), []), r((function(e) {
                c.current = e, u()
            }), [u])
        }(r((function(e) {
            return a.current && a.current.box === o.box && a.current.round === u || (a.current = {
                    box: o.box,
                    round: u,
                    instance: new ResizeObserver((function(e) {
                        var t = e[0],
                            n = "border-box" === o.box ? "borderBoxSize" : "device-pixel-content-box" === o.box ? "devicePixelContentBoxSize" : "contentBoxSize",
                            r = H(t, n, "inlineSize"),
                            i = H(t, n, "blockSize"),
                            s = r ? u(r) : void 0,
                            a = i ? u(i) : void 0;
                        if (l.current.width !== s || l.current.height !== a) {
                            var h = {
                                width: s,
                                height: a
                            };
                            l.current.width = s, l.current.height = a, c.current ? c.current(h) : v.current || f(h)
                        }
                    }))
                }), a.current.instance.observe(e, {
                    box: o.box
                }),
                function() {
                    a.current && a.current.instance.unobserve(e)
                }
        }), [o.box, u]), o.ref);
    return i((function() {
        return {
            ref: p,
            width: d.width,
            height: d.height
        }
    }), [p, d.width, d.height])
}
window.ResizeObserver || (window.ResizeObserver = G);
export {
    J as u
};