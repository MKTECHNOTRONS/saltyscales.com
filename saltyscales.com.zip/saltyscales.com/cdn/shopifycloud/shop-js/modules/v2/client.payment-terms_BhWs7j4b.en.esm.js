import {
    au as e,
    av as n,
    v as t,
    h as a,
    q as r,
    E as i,
    T as l,
    k as s,
    i as o,
    u as c,
    g as p,
    aw as m,
    j as d,
    s as u,
    A as y,
    ax as h,
    a7 as f,
    a5 as g,
    y as v,
    P as b,
    p as P,
    _,
    r as T,
    M as k,
    at as w,
    V as C,
    Y as I,
    $ as x,
    b as N,
    B as S,
    H as O,
    n as M,
    w as q,
    ay as L,
    az as E,
    G as A,
    aA as F,
    aB as B,
    a3 as R,
    J as j,
    R as $
} from "./chunk.common_Dy4FpwmR.esm.js";
import {
    A as Z,
    M as z
} from "./chunk.modal_CSDrTnGs.esm.js";
const W = {
        backgroundColor: "#fff",
        bannerContent: "pay_in_4",
        canShowSamplePlanModalContent: !1,
        cartDetails: void 0,
        cartPermalink: void 0,
        checkoutUrl: null,
        countryCode: "US",
        currencyCode: "USD",
        dataLoaded: !1,
        eligible: !1,
        financingTermForBanner: null,
        fullPrice: "",
        hasZeroInterestLoanType: !1,
        installmentPlans: [],
        installmentsBuyerPrequalificationEnabled: !1,
        isEligibleForPrequalification: !1,
        isInAdaptiveRangeWithoutZeroInterest: !1,
        isLegacyBanner: !1,
        loanTypes: [],
        maxPrice: "$3000",
        metaType: "product",
        minIneligibleMessageType: void 0,
        minPrice: "$50",
        modalOpen: !1,
        modalToken: "",
        modalVariant: "splitPay",
        numberOfPaymentTerms: 4,
        pricePerTerm: "",
        samplePlans: [],
        sellerId: void 0,
        setModalOpen: () => {
            throw new Error("Invalid attempt to call setModalOpen from outside of context")
        },
        variantAvailable: !1,
        variantId: void 0,
        variantInfo: void 0
    },
    V = e(W),
    D = () => n(V),
    H = "1.0.32-beta",
    U = () => {
        const {
            analyticsData: {
                analyticsTraceId: e
            },
            produceMonorailEvent: n,
            getTrekkieAttributes: s
        } = t(), [o] = a(new Set), c = r((t => i(void 0, [t], void 0, (function*({
            bannerContent: t,
            bannerTemplateCodeSignature: a,
            eligible: r,
            hasPrequalLink: i,
            origin: l,
            price: c,
            variantId: p
        }) {
            const m = p ? String(p) : "cart";
            if (o.has(m)) return;
            o.add(m);
            const d = yield s("uniqToken", "visitToken", "shopId", "microSessionId", "contentLanguage", "currency"), u = Object.assign(Object.assign({}, d), {
                origin: l,
                bannerContent: t,
                eligible: r,
                bannerTemplateCodeSignature: a,
                price: c,
                shopJsVersion: H,
                hasPrequalLink: i,
                analyticsTraceId: e
            });
            n({
                event: {
                    schemaId: "shop_pay_installments_banner_ui_impression/3.0",
                    payload: u
                },
                trekkieAttributes: d,
                onError: () => {
                    o.delete(m)
                }
            })
        }))), [e, s, n, o]), p = r((e => i(void 0, [e], void 0, (function*({
            elementType: e,
            elementName: t
        }) {
            const a = `element-${e}-${t}`;
            if (o.has(a)) return;
            o.add(a);
            const r = yield s("uniqToken", "visitToken", "microSessionId", "microSessionCount", "shopId", "themeId", "themeCityHash", "contentLanguage", "referer"), i = Object.assign(Object.assign({}, r), {
                elementName: t,
                elementType: e,
                shopJsVersion: H
            });
            n({
                event: {
                    schemaId: "shop_js_ui_impression/1.1",
                    payload: i
                },
                onError: () => {
                    o.delete(a)
                },
                trekkieAttributes: r
            })
        }))), [s, n, o]), m = r((e => i(void 0, [e], void 0, (function*({
            cartPermalink: e,
            eligibleSpiPlanType: t,
            modalToken: a,
            origin: r,
            price: i,
            spiPlanDetails: l,
            variantId: c
        }) {
            let p;
            if (p = "cart" === r ? `${r}-open` : `${a}-open`, o.has(p)) return;
            o.add(p);
            const m = yield s("uniqToken", "visitToken", "microSessionId", "microSessionCount", "shopId", "currency"), d = Object.assign(Object.assign({}, m), {
                origin: r,
                modalToken: a,
                eligibleSpiPlanType: t,
                price: i,
                cartPermalink: e,
                spiPlanDetails: l,
                variantId: c,
                shopJsVersion: H
            });
            n({
                event: {
                    schemaId: "shop_pay_installments_dynamic_modal_impression/1.0",
                    payload: d
                },
                onError: () => {
                    o.delete(p)
                },
                trekkieAttributes: m
            })
        }))), [s, o, n]), d = r((e => i(void 0, [e], void 0, (function*({
            modalToken: e,
            action: t,
            cartPermalink: a
        }) {
            const r = `${e}-${t}`;
            if (o.has(r)) return;
            o.add(r);
            const i = yield s("uniqToken", "visitToken", "microSessionId", "microSessionCount", "shopId"), l = Object.assign(Object.assign({}, i), {
                modalToken: e,
                action: t,
                cartPermalink: a,
                shopJsVersion: H
            });
            n({
                event: {
                    schemaId: "shop_pay_installments_dynamic_modal_user_actions/1.0",
                    payload: l
                },
                onError: () => {
                    o.delete(r)
                },
                trekkieAttributes: i
            })
        }))), [s, n, o]), u = r(((...e) => i(void 0, [...e], void 0, (function*(e = "product", t) {
            if (o.has("invalidBannerMetadata")) return;
            o.add("invalidBannerMetadata");
            const a = yield s("uniqToken", "visitToken", "microSessionId", "microSessionCount", "shopId"), r = Object.assign(Object.assign({}, a), {
                origin: e,
                metadata: t,
                shopJsVersion: H
            });
            n({
                event: {
                    schemaId: "shop_pay_installments_banner_invalid_metadata/1.0",
                    payload: r
                },
                onError: () => {
                    o.delete("invalidBannerMetadata")
                },
                trekkieAttributes: a
            })
        }))), [s, n, o]), y = r((t => i(void 0, [t], void 0, (function*({
            bannerContent: t,
            eligible: a,
            origin: r,
            prequalLinkClicked: i,
            price: l
        }) {
            if (o.has("bannerPrequalInteraction")) return;
            o.add("bannerPrequalInteraction");
            const c = yield s("uniqToken", "visitToken", "shopId", "microSessionId", "contentLanguage", "currency"), p = Object.assign(Object.assign({}, c), {
                origin: r,
                bannerContent: t,
                eligible: a,
                price: l,
                shopJsVersion: H,
                prequalLinkClicked: i,
                analyticsTraceId: e
            });
            n({
                event: {
                    schemaId: "shop_pay_installments_banner_prequal_interaction/3.0",
                    payload: p
                },
                onError: () => {
                    o.delete("bannerPrequalInteraction")
                },
                trekkieAttributes: c
            })
        }))), [e, s, n, o]), h = r((t => i(void 0, [t], void 0, (function*({
            sellerId: t,
            pageType: a
        }) {
            if (o.has(a)) return;
            o.add(a);
            n({
                event: {
                    schemaId: "shop_pay_installments_prequal_popup_page_impression/3.0",
                    payload: {
                        analyticsTraceId: e,
                        sellerId: t,
                        pageType: a
                    }
                },
                onError: () => {
                    o.delete(a)
                },
                trekkieAttributes: void 0
            })
        }))), [e, o, n]);
        return l((() => ({
            trackElementImpression: p,
            trackInstallmentsBannerImpression: c,
            trackInstallmentsBannerPrequalInteraction: y,
            trackInvalidInstallmentBannerMetadata: u,
            trackInstallmentsPrequalPopupPageImpression: h,
            trackModalAction: d,
            trackModalOpened: m
        })), [p, c, y, u, h, d, m])
    },
    J = e => {
        const n = new Map([
                ["font-weight", "weight"],
                ["font-display", "display"],
                ["font-style", "style"],
                ["font-stretch", "stretch"],
                ["ascent-override", "ascentOverride"],
                ["descent-override", "descentOverride"],
                ["font-feature-settings", "featureSettings"],
                ["line-gap-override", "lineGapOverride"],
                ["unicode-range", "unicodeRange"]
            ]),
            t = {};
        return n.forEach(((n, a) => {
            e[a] && (t[n] = e[a])
        })), t
    };

function G(e) {
    var n;
    if (!e || "" === e.trim()) return [];
    const t = e => "CSSFontFaceRule" === e.constructor.name;
    try {
        const n = [...s.styleSheets].filter((e => Boolean(e.cssRules))).flatMap((e => [...e.cssRules].filter(t))).filter((n => e.includes(n.style.getPropertyValue("font-family")))).map((e => {
            const n = {};
            for (let t = e.style.length; t--;) {
                const a = e.style[t];
                "src" !== a ? n[a] = e.style.getPropertyValue(a) : n.src = e.style.getPropertyValue("src").replace(/url\((["']?)([^"')]+)\1\)/gm, ((n, t, a) => {
                    var r, i;
                    if (a.match(/^(https?:)?\/\//)) return n;
                    const l = null !== (i = null === (r = e.parentStyleSheet) || void 0 === r ? void 0 : r.href) && void 0 !== i ? i : location.href;
                    return `url("${new URL(a,l)}")`
                }))
            }
            return n
        }));
        return n.map((e => ({
            src: e.src,
            fontFamily: e["font-family"].replace(/["']/g, ""),
            fontFaceDescriptors: J(e)
        })))
    } catch (e) {
        return null === (n = console.warn) || void 0 === n || n.call(console, "Error while extracting font-face declaration", e), []
    }
}

function K(e, n) {
    const t = X(e),
        a = X(n);
    return (Math.max(t, a) + .05) / (Math.min(t, a) + .05)
}

function Y(e) {
    var n;
    if (!e) return "#ffffff";
    const t = null === (n = o.getComputedStyle(e).getPropertyValue("--color-background")) || void 0 === n ? void 0 : n.trim();
    if (t) return t;
    for (const n of function*(e) {
            let n = e;
            for (; n;) {
                if (n.parentElement) n = n.parentElement;
                else if (n instanceof ShadowRoot) n = n.host;
                else {
                    if (!(n instanceof Element)) break; {
                        const e = n.getRootNode();
                        if (!(e instanceof ShadowRoot)) break;
                        n = e.host
                    }
                }
                if (yield n, n === s.body) break
            }
        }(e)) {
        const e = o.getComputedStyle(n).getPropertyValue("background-color");
        if (e && "rgba(0, 0, 0, 0)" !== e) return e
    }
    return "#ffffff"
}

function X(e) {
    const n = [e[0], e[1], e[2]].map((function(e) {
        const n = e / 255;
        return n <= .03928 ? n / 12.92 : Math.pow((n + .055) / 1.055, 2.4)
    }));
    return .2126 * n[0] + .7152 * n[1] + .0722 * n[2]
}
const Q = e => {
        const n = [255, 255, 255],
            t = e.startsWith("#") ? function(e) {
                let n = 0,
                    t = 0,
                    a = 0;
                return 4 === e.length ? (n = Number(`0x${e[1]}${e[1]}`), t = Number(`0x${e[2]}${e[2]}`), a = Number(`0x${e[3]}${e[3]}`)) : 7 === e.length && (n = Number(`0x${e[1]}${e[2]}`), t = Number(`0x${e[3]}${e[4]}`), a = Number(`0x${e[5]}${e[6]}`)), [n, t, a]
            }(e) : function(e) {
                const n = e.match(/\d+/g) || [],
                    [t = 0, a = 0, r = 0] = n.map((e => Number(e)));
                return [t, a, r]
            }(e),
            a = t.length >= 3 ? t : n;
        return K(a, [90, 49, 244]) > K(a, n) ? "text-purple-primary" : "text-white"
    },
    ee = [{
        key: "affirmCanadaHelpLink",
        href: "https://www.affirm.ca/help",
        text: "affirm.ca/help"
    }, {
        key: "lendersLink",
        href: "https://www.affirm.com/lenders",
        text: "affirm.com/lenders"
    }, {
        key: "licensesLink",
        href: "https://www.affirm.com/licenses",
        text: "affirm.com/licenses"
    }],
    ne = ["BIF", "CLP", "DJF", "GNF", "HUF", "ISK", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "TWD", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"],
    te = e => {
        const n = e.trim().replace(/[^0-9,.]/g, "");
        return "," === n[n.length - 3] ? parseFloat(n.replace(/\./g, "").replace(/,([^,]*)$/, ".$1")) : parseFloat(n.replace(/,/g, ""))
    },
    ae = ({
        currencyCode: e = "USD",
        price: n
    }) => {
        const t = ne.includes(e) ? 0 : 2,
            a = {
                style: "currency",
                currency: e,
                minimumFractionDigits: t,
                maximumFractionDigits: t
            };
        try {
            return a.currencyDisplay = "narrowSymbol", new Intl.NumberFormat(void 0, a).format(n)
        } catch (e) {
            return a.currencyDisplay = "symbol", new Intl.NumberFormat(void 0, a).format(n)
        }
    },
    re = () => l((() => ee.reduce(((e, {
        key: n,
        href: t,
        text: a
    }) => Object.assign(Object.assign({}, e), {
        [n]: c("a", {
            href: t,
            target: "_blank",
            "aria-describedby": "shopify-payment-terms-modal-warning-text",
            rel: "noreferrer",
            className: "text-grayscale-d0 underline hover_text-black focus_text-black active_text-black",
            children: a
        })
    })), {})), []),
    ie = () => c("div", {
        className: "relative inline-block",
        children: c("svg", {
            className: "block",
            fill: "none",
            height: 22,
            role: "img",
            viewBox: "0 0 52 58",
            width: 22,
            xmlns: "http://www.w3.org/2000/svg",
            children: c("path", {
                className: "animate-reveal stroke-white stroke-dasharray-reveal",
                d: "M3 13C5 11.75 10.4968 6.92307 21.5 6.4999C34.5 5.99993 42 13 45 23C48.3 34 42.9211 48.1335 30.5 51C17.5 54 6.6 46 6 37C5.46667 29 10.5 25 14 23",
                strokeWidth: 11
            })
        })
    }),
    le = () => c("svg", {
        "aria-labelledby": "shopify-payment-terms-modal-affirm",
        xmlns: "http://www.w3.org/2000/svg",
        height: "16",
        width: "39",
        fill: "none",
        children: [c("path", {
            fill: "#000",
            d: "M3.058 14.543c-.482 0-.724-.236-.724-.623 0-.72.812-.965 2.292-1.121 0 .962-.656 1.744-1.569 1.744zm.638-5.413c-1.058 0-2.275.495-2.936 1.017l.604 1.26c.53-.48 1.386-.892 2.159-.892.734 0 1.14.243 1.14.734 0 .33-.269.497-.777.563C1.99 12.056.5 12.575.5 14.026c0 1.15.826 1.846 2.116 1.846.92 0 1.74-.507 2.129-1.176v.99H6.46v-4.148c0-1.712-1.2-2.408-2.764-2.408zm17.224.188v6.367h1.837v-3.068c0-1.458.89-1.886 1.51-1.886.243 0 .57.07.785.23l.334-1.684a2.104 2.104 0 0 0-.822-.147c-.944 0-1.538.415-1.929 1.258v-1.07h-1.714zm12.979-.188c-.971 0-1.697.57-2.075 1.118-.35-.709-1.093-1.118-1.983-1.118-.971 0-1.643.535-1.954 1.15v-.962h-1.77v6.367h1.838v-3.277c0-1.177.621-1.742 1.201-1.742.525 0 1.007.337 1.007 1.207v3.812h1.835v-3.277c0-1.19.606-1.742 1.213-1.742.486 0 .998.35.998 1.193v3.826h1.834v-4.401c0-1.431-.971-2.154-2.144-2.154zm-17.447.187h-1.664v-.648c0-.842.485-1.083.903-1.083.462 0 .822.203.822.203l.566-1.284s-.573-.372-1.617-.372c-1.173 0-2.508.656-2.508 2.716v.468h-2.785v-.648c0-.842.485-1.083.903-1.083.238 0 .557.054.822.203l.566-1.284c-.338-.196-.88-.372-1.617-.372-1.173 0-2.508.656-2.508 2.716v.468H7.269v1.405h1.066v4.963h1.834v-4.963h2.785v4.963h1.834v-4.963h1.664V9.317zm1.095 6.367h1.832V9.317h-1.832v6.367z"
        }), c("path", {
            fill: "#5A31F4",
            d: "M28.24.434c-4.956 0-9.372 3.413-10.625 7.8h1.795C20.457 4.968 24.012 2.1 28.24 2.1c5.14 0 9.582 3.882 9.582 9.925 0 1.356-.177 2.58-.513 3.66h1.743l.017-.059c.286-1.115.431-2.326.431-3.6 0-6.74-4.95-11.59-11.26-11.59z"
        })]
    });

function se({
    className: e
}) {
    return c("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 99 25",
        children: [c("path", {
            fill: "currentColor",
            d: "M70.842 7.915h2.25c1.561 0 2.328.642 2.328 1.715 0 1.074-.739 1.715-2.259 1.715h-2.32v-3.43ZM80.525 16.142c-.879 0-1.227-.474-1.227-.948 0-.642.725-.935 2.147-1.102l1.115-.125c-.07 1.227-.892 2.175-2.035 2.175Z"
        }), c("path", {
            fill: "currentColor",
            "fill-rule": "evenodd",
            d: "M65.645.5a3.64 3.64 0 0 0-3.64 3.64V20.7a3.64 3.64 0 0 0 3.64 3.64h29.668a3.64 3.64 0 0 0 3.64-3.64V4.14A3.64 3.64 0 0 0 95.314.5H65.645Zm5.197 16.674v-4.197h2.64c2.412 0 3.695-1.353 3.695-3.402 0-2.05-1.283-3.277-3.695-3.277h-4.341v10.876h1.7Zm9.334.223c1.297 0 2.147-.572 2.538-1.548.112 1.088.767 1.645 2.189 1.269l.014-1.157c-.572.055-.683-.154-.683-.753v-2.845c0-1.673-1.102-2.663-3.138-2.663-2.008 0-3.165 1.004-3.165 2.705h1.562c0-.809.572-1.297 1.576-1.297 1.06 0 1.547.46 1.534 1.255v.363l-1.8.195c-2.021.223-3.137.99-3.137 2.329 0 1.101.781 2.147 2.51 2.147Zm9.906.32c-.711 1.73-1.855 2.245-3.64 2.245h-.766V18.54h.822c.977 0 1.45-.307 1.966-1.185L85.3 9.923h1.757l2.259 5.424 2.008-5.424h1.715l-2.956 7.795Z",
            "clip-rule": "evenodd"
        }), c("path", {
            fill: "currentColor",
            d: "M6.992 11.055c-2.359-.509-3.41-.708-3.41-1.612 0-.85.711-1.274 2.134-1.274 1.25 0 2.165.544 2.839 1.61.05.081.155.11.241.066l2.655-1.335a.186.186 0 0 0 .076-.259c-1.102-1.9-3.137-2.94-5.818-2.94C2.188 5.311 0 7.037 0 9.781c0 2.915 2.664 3.651 5.027 4.16 2.362.51 3.417.709 3.417 1.613s-.769 1.33-2.303 1.33c-1.416 0-2.467-.644-3.102-1.896a.186.186 0 0 0-.251-.082L.14 16.21a.188.188 0 0 0-.083.253c1.051 2.102 3.207 3.285 6.087 3.285 3.668 0 5.885-1.698 5.885-4.527 0-2.83-2.677-3.651-5.037-4.16v-.007ZM21.218 5.311c-1.505 0-2.835.531-3.791 1.477-.06.057-.159.015-.159-.067V.687A.185.185 0 0 0 17.081.5h-3.322a.185.185 0 0 0-.187.187v18.73c0 .104.083.186.187.186h3.322a.185.185 0 0 0 .187-.186V11.2c0-1.587 1.223-2.804 2.87-2.804 1.649 0 2.843 1.191 2.843 2.804v8.216c0 .104.082.186.187.186h3.322a.185.185 0 0 0 .187-.186V11.2c0-3.452-2.274-5.89-5.459-5.89ZM33.415 4.774c-1.803 0-3.493.55-4.706 1.343a.186.186 0 0 0-.06.25l1.464 2.488c.054.089.168.12.257.066a5.853 5.853 0 0 1 3.052-.834c2.899 0 5.03 2.036 5.03 4.726 0 2.292-1.706 3.99-3.868 3.99-1.762 0-2.985-1.022-2.985-2.463 0-.825.352-1.502 1.27-1.98a.183.183 0 0 0 .073-.258l-1.381-2.327a.187.187 0 0 0-.226-.079c-1.85.683-3.15 2.327-3.15 4.533 0 3.338 2.67 5.83 6.396 5.83 4.35 0 7.478-3 7.478-7.303 0-4.612-3.64-7.982-8.644-7.982ZM51.776 5.283c-1.68 0-3.182.62-4.277 1.707a.093.093 0 0 1-.16-.066v-1.31a.185.185 0 0 0-.187-.186h-3.235a.185.185 0 0 0-.188.187v18.702c0 .104.083.186.188.186h3.32a.185.185 0 0 0 .188-.186v-6.133c0-.082.099-.123.16-.07 1.091 1.012 2.536 1.603 4.19 1.603 3.897 0 6.936-3.139 6.936-7.217 0-4.078-3.042-7.217-6.935-7.217Zm-.63 11.266c-2.215 0-3.895-1.754-3.895-4.074S48.928 8.4 51.147 8.4c2.22 0 3.893 1.726 3.893 4.075 0 2.348-1.651 4.074-3.896 4.074h.003Z"
        })]
    })
}
const oe = () => {
    const {
        locale: e,
        translate: n
    } = p(), t = n("en" === e ? "paymentTerms.installmentsModal.partnership" : "paymentTerms.installmentsModal.partnershipDisclaimer", {
        affirmLogo: c("span", {
            className: "inline-block",
            children: c(le, {})
        })
    });
    return c("footer", {
        className: "flex flex-col items-center",
        children: [c("div", {
            className: "mb-3 h-5 w-22 text-purple-primary",
            children: c(se, {})
        }), c("small", {
            className: "text-caption font-light tracking-wider text-grayscale-d0",
            children: t
        })]
    })
};
const ce = () => ({
        left: void 0 === o.screenLeft ? o.screenX : o.screenLeft,
        top: void 0 === o.screenTop ? o.screenY : o.screenTop
    }),
    pe = () => ({
        width: o.innerWidth || s.documentElement.clientWidth,
        height: o.innerHeight || s.documentElement.clientHeight
    }),
    me = () => screen.width && o.screen.availWidth ? screen.width / o.screen.availWidth : 1,
    de = `${m}/shopify_pay/prequal_authorize?target_origin=${o.location.origin}`,
    ue = () => {
        const {
            translate: e
        } = p(), {
            instanceId: n
        } = d(), t = u(), a = y(null);
        h({
            allowedOrigins: [f, g],
            handler: e => {
                var n, r, i;
                switch (e.type) {
                    case "close":
                        null === (n = a.current) || void 0 === n || n.close(), t("overlayClose");
                        break;
                    case "error":
                        null === (r = a.current) || void 0 === r || r.close(), t("closeOverlayAndModal");
                        break;
                    case "prequal_buyer_upsert_successful":
                        null === (i = a.current) || void 0 === i || i.close(), t("buyerOnboardingSuccess")
                }
            },
            source: a
        }), v((() => {
            const e = e => {
                "Escape" !== e.key && "Esc" !== e.key || t("overlayClose")
            };
            return o.addEventListener("keydown", e), () => {
                o.removeEventListener("keydown", e)
            }
        }), [t]);
        return b(c(P, {
            instanceId: n,
            type: "modal",
            variant: "installmentsPrequalOverlay",
            children: c("div", {
                "data-testid": "prequal-buyer-form-overlay",
                className: "fixed inset-0 z-max flex animate-fade-in flex-col items-center justify-center bg-gradient-to-b from-black/95 to-black/60 text-center font-sans text-body-large text-white",
                children: [c("div", {
                    className: "h-5 w-22",
                    children: c(se, {})
                }), c("div", {
                    className: "my-5 flex flex-col items-center justify-center gap-4",
                    children: [c("p", {
                        children: e("paymentTerms.prequalOverlay.needMoreInfo")
                    }), c("p", {
                        children: e("paymentTerms.prequalOverlay.clickContinue")
                    })]
                }), c("button", {
                    type: "button",
                    "data-testid": "installments-prequal-overlay-continue",
                    className: "cursor-pointer bg-transparent text-white underline hover_text-grayscale-l2l focus_outline-none",
                    onClick: () => {
                        var e;
                        a.current && !a.current.closed || (a.current = function({
                            url: e,
                            width: n,
                            height: t,
                            windowName: a,
                            onClose: r
                        }) {
                            const i = ce(),
                                l = pe(),
                                s = l.width || screen.width,
                                c = l.height || screen.height,
                                p = me(),
                                m = (s - n) / 2 / p + i.left,
                                d = (c - t) / 2 / p + i.top,
                                u = o.open(e, a, `scrollbars=yes,width=${n},height=${t},top=${d},left=${m}`);
                            if (!u) return null;
                            if (u.focus(), r) {
                                const e = setInterval((() => {
                                    u.closed && (r(), clearInterval(e))
                                }), 1e3)
                            }
                            return u
                        }({
                            url: de,
                            width: 500,
                            height: 750
                        })), null === (e = a.current) || void 0 === e || e.focus()
                    },
                    children: e("paymentTerms.prequalOverlay.continue")
                })]
            })
        }), s.body)
    },
    ye = () => c("div", {
        className: "flex w-full items-center justify-center",
        children: c("svg", {
            width: 64,
            height: 64,
            viewBox: "0 0 44 44",
            xmlns: "http://www.w3.org/2000/svg",
            className: "animate-spin fill-purple-primary",
            children: c("path", {
                d: "M15.542 1.487A21.507 21.507 0 00.5 22c0 11.874 9.626 21.5 21.5 21.5 9.847 0 18.364-6.675 20.809-16.072a1.5 1.5 0 00-2.904-.756C37.803 34.755 30.473 40.5 22 40.5 11.783 40.5 3.5 32.217 3.5 22c0-8.137 5.3-15.247 12.942-17.65a1.5 1.5 0 10-.9-2.863z"
            })
        })
    }),
    he = e => {
        var {
            disabled: n,
            handleLoginCompleted: s,
            handlePrequalFlowSideEffect: o,
            storefrontOrigin: m
        } = e, d = _(e, ["disabled", "handleLoginCompleted", "handlePrequalFlowSideEffect", "storefrontOrigin"]);
        const {
            translate: h
        } = p(), {
            notify: f
        } = T(), {
            trackPageImpression: g,
            trackUserAction: b
        } = t(), P = u(), S = y(null), O = y(null), [M, q] = a(), L = l((() => {
            const e = () => i(void 0, void 0, void 0, (function*() {
                q(void 0)
            }));
            return {
                requestShow: e,
                start: e
            }
        }), []);
        k(L), v((() => {
            g({
                page: "SIGN_IN_WITH_SHOP_BUTTON"
            })
        }), [g]);
        const E = r((e => i(void 0, [e], void 0, (function*({
                loggedIn: e,
                shouldFinalizeLogin: n
            }) {
                e && n && (yield w(m, f)), null == s || s()
            }))), [s, f, m]),
            {
                authorizeUrl: A
            } = C(Object.assign(Object.assign(Object.assign({
                analyticsContext: "loginWithShopPrequal",
                error: M
            }, d), {
                uxMode: "iframe"
            }), {
                disableSignUp: !1,
                flow: "prequal",
                flowVersion: "unspecified",
                hideCopy: !1,
                proxy: !0
            }));
        const F = r((() => {
                b({
                    userAction: "SIGN_IN_WITH_SHOP_BUTTON_CLICK"
                })
            }), [b]),
            B = I(F, 150, !0),
            R = r((() => {
                var e;
                b({
                    userAction: "SIGN_IN_WITH_SHOP_PROMPT_CONTINUE_CLICK"
                }), null === (e = null == O ? void 0 : O.current) || void 0 === e || e.close({
                    dismissMethod: "windoid_continue",
                    reason: "user_prompt_continue_clicked"
                })
            }), [b]),
            j = l((() => h(n ? "paymentTerms.buttons.unavailable" : "paymentTerms.buttons.check")), [n, h]);
        return c(N, {
            children: [c(x, {
                className: "m-auto flex size-full w-full cursor-pointer items-center justify-center rounded-xs px-11 py-2.5 text-button-large font-normal",
                disabled: n,
                onClick: B,
                ref: S,
                children: c("span", {
                    className: "whitespace-nowrap font-sans text-white",
                    "data-testid": "prequal-button-text",
                    children: j
                })
            }), c(Z, {
                activator: S,
                insideModal: !0,
                onComplete: E,
                onCustomFlowSideEffect: o,
                onError: function({
                    code: e,
                    email: n,
                    message: t
                }) {
                    var a;
                    P("error", {
                        code: e,
                        email: n,
                        message: t
                    }), "retriable_server_error" === e && (M === e && (null === (a = O.current) || void 0 === a || a.reload()), q(e))
                },
                onPromptContinue: R,
                proxy: !0,
                ref: O,
                src: A,
                variant: "default"
            })]
        })
    },
    fe = () => {
        const {
            translate: e
        } = p(), {
            fullPrice: n,
            samplePlans: t
        } = D(), a = e("paymentTerms.samplePlansContent.subtitle", {
            count: t.length,
            priceWithoutInterest: c("span", {
                className: "font-bold",
                dangerouslySetInnerHTML: {
                    __html: n
                }
            })
        });
        return c(N, {
            children: [c("p", {
                "data-testid": "subtitle",
                className: "mb-4 text-subtitle font-normal leading-snug text-grayscale-d0",
                children: a
            }), c("ul", {
                className: "m-0 list-none rounded-xs border border-grayscale-l2 bg-grayscale-l4 px-5 py-4",
                children: t.map((({
                    pricePerTerm: n,
                    apr: t,
                    numberOfPaymentTerms: a,
                    interest: r,
                    totalPriceWithInterest: i,
                    loanType: l
                }) => {
                    const s = "split_pay" === l,
                        o = e(s ? "paymentTerms.samplePlansContent.everyTwoWeeks" : "paymentTerms.samplePlansContent.monthly"),
                        p = e(s ? "paymentTerms.samplePlansContent.splitPayFrequency" : "paymentTerms.samplePlansContent.otherFrequency", {
                            pricePerTerm: c("span", {
                                className: "text-body-large font-medium",
                                children: n
                            }),
                            frequency: o
                        }),
                        m = e(s ? "paymentTerms.samplePlansContent.splitPayNumberOfTerms" : "paymentTerms.samplePlansContent.otherNumberOfTerms", {
                            numberOfTerms: s ? 2 * a : a
                        });
                    return c("li", {
                        className: "border-b border-grayscale-l2 py-2.5 text-grayscale-d0 first_pt-0 last_border-b-0 last_pb-0",
                        children: [c("div", {
                            className: "mb-2 flex justify-between text-body-small font-normal",
                            children: c("span", {
                                "data-testid": "list-item__frequency",
                                className: "flex flex-nowrap items-end gap-1",
                                children: [c("span", {
                                    className: "font-medium",
                                    children: p
                                }), c("span", {
                                    "data-testid": "list-item__number-of-terms",
                                    children: m
                                })]
                            })
                        }), c("div", {
                            className: "flex flex-col space-y-2.5 text-caption font-normal",
                            children: [c("div", {
                                className: "flex justify-between",
                                children: [c("span", {
                                    "data-testid": "list-item__interest-detail-label",
                                    children: e("paymentTerms.samplePlansContent.interestDetails", {
                                        apr: t
                                    })
                                }), c("span", {
                                    "data-testid": "list-item__interest-amount",
                                    children: r
                                })]
                            }), c("div", {
                                className: "flex justify-between",
                                children: [c(N, {
                                    children: e("paymentTerms.samplePlansContent.total")
                                }), c("span", {
                                    className: "font-semibold",
                                    children: i
                                })]
                            })]
                        })]
                    }, `${n}-${a}-${l}`)
                }))
            })]
        })
    },
    ge = ({
        onClose: e
    }) => {
        const {
            checkoutUrl: n,
            countryCode: s,
            fullPrice: m,
            metaType: d,
            sellerId: u,
            variantInfo: h
        } = D(), g = l((() => Number(u)), [u]), {
            translate: b
        } = p(), {
            trackInstallmentsPrequalPopupPageImpression: P
        } = U(), _ = y(null), [T, w] = a("prequal_authorize_loaded"), [C, I] = a(!1), [x, q] = a(!1), [L, E] = a(!1), [A, F] = a("mainContent"), [B, R] = a(!1), [j, $] = a(!1), {
            analyticsData: Z
        } = t(), z = re(), W = l((() => {
            const e = f.replace("https://", "");
            return `${f}/pay/installments/prequalifications/authorize?shopify_domain=${o.location.hostname}&pay_domain=${e}&analytics_trace_id=${Z}&redirect_source=${o.location.origin}`
        }), [Z]), V = r((() => i(void 0, void 0, void 0, (function*() {
            n && (o.location.assign(n), P({
                pageType: "prequal_continue_to_checkout_clicked",
                sellerId: g
            }))
        }))), [n, g, P]), H = r((() => {
            P({
                pageType: "prequal_buyer_form_overlay_loaded",
                sellerId: g
            }), R(!0)
        }), [g, P]), {
            destroy: J
        } = S({
            onClose: e,
            onContinueToCheckout: V,
            onPrequalError: () => {
                G()
            },
            onPrequalMissingInformation: () => {
                F("mainContent"), H()
            },
            onPrequalSuccess: () => {
                G()
            },
            onPrequalReady: () => {
                var e;
                O({
                    contentWindow: null === (e = _.current) || void 0 === e ? void 0 : e.contentWindow,
                    event: {
                        type: "createprequal",
                        amount: te(m),
                        currency: "USD",
                        sellerId: g
                    }
                })
            },
            onResizeIframe: ({
                height: e
            }) => {
                _.current.style.height = `${Math.max(Math.min(o.innerHeight-75,642),e)}px`
            },
            source: _
        });
        v((() => {
            const e = _.current;
            return () => {
                e && J()
            }
        }), [J]);
        const G = () => {
                F("iframe")
            },
            K = r((() => {
                _.current && (F("loading"), P({
                    pageType: "prequal_results_page_loading",
                    sellerId: g
                }), $(!0))
            }), [g, P]),
            Y = l((() => {
                const n = () => {
                    R(!1)
                };
                return {
                    buyerOnboardingSuccess: () => {
                        n(), K()
                    },
                    closeOverlayAndModal: () => {
                        n(), null == e || e()
                    },
                    modalopened: () => {
                        I(!1)
                    },
                    overlayClose: () => {
                        n()
                    }
                }
            }), [e, K]);
        k(Y);
        const X = r((() => {
                if (E(!0), x) switch (T) {
                    case "prequal_results_page_loaded":
                        K();
                        break;
                    case "prequal_buyer_form_overlay_loaded":
                        H()
                } else I(!0)
            }), [T, K, H, x]),
            Q = r((({
                shopPayInstallmentsOnboarded: e = !1
            }) => {
                q(!0), w(e ? "prequal_results_page_loaded" : "prequal_buyer_form_overlay_loaded"), L && (I(!1), X())
            }), [L, X]),
            ee = b(`paymentTerms.samplePlansContent.legal.${s}`, z),
            ne = l((() => c(N, {
                children: [C && c("div", {
                    className: "flex h-10 w-full items-center justify-center rounded-login-button bg-purple-primary",
                    children: c(ie, {})
                }), c("div", {
                    className: M("h-10 w-full", C && "hidden"),
                    "data-testid": "check-if-you-qualify-button",
                    onClick: e => {
                        switch (I(!0), T) {
                            case "prequal_authorize_loaded":
                                P({
                                    pageType: "prequal_authorize_loaded",
                                    sellerId: Number(u)
                                });
                                break;
                            case "prequal_buyer_form_overlay_loaded":
                                e.stopPropagation(), H(), I(!1);
                                break;
                            case "prequal_results_page_loaded":
                                e.stopPropagation(), K(), I(!1)
                        }
                    },
                    children: c(he, {
                        disabled: Boolean(h && !h.available),
                        handleLoginCompleted: X,
                        handlePrequalFlowSideEffect: Q,
                        storefrontOrigin: o.location.origin
                    })
                })]
            })), [C, X, Q, T, K, H, u, P, h]),
            ae = c("div", {
                class: "flex animate-fade-in flex-col items-center justify-center p-8 font-system",
                "data-testid": "shop-modal-content-processing",
                children: c("div", {
                    class: "flex h-full flex-col items-center justify-center",
                    "data-testid": "shop-modal-content-processing-loading-container",
                    children: [c(ye, {}), c("div", {
                        class: "mt-5 flex flex-col items-center justify-center gap-2",
                        children: [c("p", {
                            "data-testid": "processing-label",
                            children: b("paymentTerms.prequalContent.processing")
                        }), c("p", {
                            class: "text-caption text-grayscale-primary-light",
                            "data-testid": "processing-time-label",
                            children: b("paymentTerms.prequalContent.processingTime")
                        })]
                    })]
                })
            }),
            le = "iframe" === A;
        return c("div", {
            "data-testid": "prequal-modal-content",
            children: ["loading" === A && ae, c("div", {
                "data-testid": "shop-modal-feature-iframe-wrapper",
                class: M(!le && "hidden"),
                children: c("iframe", {
                    className: "max-h-[80vh] w-[432px] max-w-full",
                    "data-testid": "prequal-modal-iframe",
                    ref: _,
                    src: j ? W : "",
                    title: "Shop Pay Installments pre-qualification"
                })
            }), "mainContent" === A && c(N, {
                children: [c(fe, {}), "checkout" !== d && c(N, {
                    children: [c("div", {
                        "data-testid": "navigation-buttons",
                        className: "mt-4 flex flex-col items-center",
                        children: ne
                    }), c("div", {
                        className: "my-1 flex flex-col items-center text-caption font-light leading-normal",
                        children: [c("p", {
                            className: "text-center font-light",
                            children: b("paymentTerms.samplePlansContent.informationShared")
                        }), c("p", {
                            "data-testid": "check_eligibility",
                            className: "text-center font-light",
                            children: b("paymentTerms.samplePlansContent.checkingEligibility")
                        })]
                    })]
                }), c("p", {
                    id: "eligibility-approval",
                    "data-testid": "eligibility-approval",
                    className: "mb-5 mt-8 text-caption font-light tracking-wider text-grayscale-d0",
                    children: ee
                })]
            }), !le && c(oe, {}), B && c(ue, {})]
        })
    },
    ve = q(((e, n) => {
        const {
            translate: t
        } = p(), {
            variantInfo: a,
            checkoutUrl: i
        } = D(), s = !1 === (null == a ? void 0 : a.available), m = r((() => {
            i && o.location.assign(i)
        }), [i]), d = l((() => t(s ? "paymentTerms.buttons.unavailable" : "paymentTerms.buttons.continueToCheckout")), [s, t]);
        return c(x, {
            className: "flex w-full justify-center rounded-xs px-4 py-2-5 text-white",
            disabled: s,
            onClick: m,
            ref: n,
            children: d
        })
    })),
    be = () => {
        const {
            cartPermalink: e,
            countryCode: n,
            metaType: t,
            modalToken: a,
            variantInfo: i,
            checkoutUrl: l
        } = D(), {
            translate: s
        } = p(), {
            trackModalAction: o
        } = U(), m = s(`paymentTerms.samplePlansContent.legal.${n}`, re()), d = r((() => {
            !1 !== (null == i ? void 0 : i.available) && o({
                modalToken: a,
                action: "continue_to_checkout",
                cartPermalink: e
            })
        }), [e, a, o, i]);
        return c("div", {
            "data-testid": "sample-plans-modal-content",
            children: [c(fe, {}), "checkout" !== t && l && c(N, {
                children: [c("div", {
                    "data-testid": "navigation-buttons",
                    className: "mt-4 flex flex-col items-center",
                    children: c("div", {
                        "data-testid": "sample-plans-modal-continue-to-checkout-button",
                        className: "w-full",
                        onClick: d,
                        children: c(ve, {})
                    })
                }), c("div", {
                    className: "my-1 flex flex-col items-center text-caption font-light leading-normal",
                    children: [c("p", {
                        className: "text-center font-light",
                        children: s("paymentTerms.samplePlansContent.informationShared")
                    }), c("p", {
                        className: "text-center font-light",
                        children: s("paymentTerms.samplePlansContent.checkingEligibility")
                    })]
                })]
            }), c("p", {
                id: "eligibility-approval",
                "data-testid": "eligibility-approval",
                className: "mb-5 mt-8 text-caption font-light tracking-wider text-grayscale-d0",
                children: m
            }), c(oe, {})]
        })
    },
    Pe = ({
        eligible: e,
        loanTypes: n
    }) => (null == n ? void 0 : n.length) && e ? n.includes("interest") && n.includes("split_pay") ? "adaptive" : n.includes("split_pay") ? "split_pay" : "interest_only" : "ineligible",
    _e = ({
        modalType: e,
        numberOfPaymentTerms: n
    }) => {
        switch (e) {
            case "adaptive":
                return "paymentTerms.splitPayContents.subtitle.interestAndSplitPay";
            case "split_pay":
                return 2 === n ? "paymentTerms.splitPayContents.subtitle.splitPayOnly2" : 1 === n ? "paymentTerms.splitPayContents.subtitle.splitPayOnly30" : "paymentTerms.splitPayContents.subtitle.splitPayOnly";
            case "interest_only":
                return "paymentTerms.splitPayContents.subtitle.interestOnly";
            default:
                return
        }
    },
    Te = ({
        countryCode: e,
        lendersLink: n,
        modalType: t
    }) => {
        const a = ["paymentTerms.splitPayContents.legal.ratesFromApr", {
            link: n
        }];
        switch (e) {
            case "CA":
                return ["paymentTerms.splitPayContents.legal.CA"];
            case "US":
                switch (t) {
                    case "adaptive":
                        return ["paymentTerms.splitPayContents.legal.interestAndSplitPay", a, "paymentTerms.splitPayContents.legal.caResidentsNotice"];
                    case "split_pay":
                        return ["paymentTerms.splitPayContents.legal.splitPayOnly", "paymentTerms.splitPayContents.legal.caResidentsNotice"];
                    case "interest_only":
                        return ["paymentTerms.splitPayContents.legal.interestOnly", a, "paymentTerms.splitPayContents.legal.caResidentsNotice"];
                    case "ineligible":
                        return ["paymentTerms.splitPayContents.legal.ineligible", "paymentTerms.splitPayContents.legal.caResidentsNotice"];
                    default:
                        return []
                }
            default:
                return []
        }
    },
    ke = ({
        minIneligibleMessageType: e,
        numberOfPaymentTerms: n,
        fullPrice: t,
        priceRange: a
    }) => {
        const r = (null == a ? void 0 : a.minPrice) ? te(a.minPrice) : null,
            i = t ? te(t) : null;
        if (!r || !(null == a ? void 0 : a.maxPrice)) return "";
        if (!i || i < r) {
            let t = "paymentTerms.splitPayContents.subtitle.ineligibleMin";
            2 !== n && 1 !== n || (t = "paymentTerms.splitPayContents.subtitle.ineligibleMinOverTime");
            return "monthly" === e ? "paymentTerms.splitPayContents.subtitle.ineligibleMonthlyPaymentsMin" : t
        }
        return "paymentTerms.splitPayContents.subtitle.ineligibleMax"
    };

function we() {
    return c("svg", {
        viewBox: "0 0 21 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: c("path", {
            d: "M17.364 1H2.636C1.733 1 1 1.784 1 2.75v10.5c0 .966.733 1.75 1.636 1.75h14.728c.903 0 1.636-.784 1.636-1.75V2.75C19 1.784 18.267 1 17.364 1ZM1 6h18M13 11h2",
            stroke: "#0B0B0C",
            "stroke-width": "2",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        })
    })
}

function Ce() {
    return c("svg", {
        viewBox: "0 0 22 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [c("path", {
            d: "M18.5 10.547c0 4.72-3.9 8.577-8.75 8.577S1 15.267 1 10.547s3.9-8.576 8.75-8.576 8.75 3.857 8.75 8.576Z",
            stroke: "#0B0B0C",
            "stroke-width": "2"
        }), c("path", {
            d: "M11.488 8.07a1 1 0 1 0 1.4-1.429l-1.4 1.428ZM10.04 6.556v1-1Zm-2.908 5.877a1 1 0 1 0-1.266 1.547l1.266-1.547Zm5.054-5.079.7-.714V6.64l-.002-.001-.003-.003-.006-.006-.017-.016a2.497 2.497 0 0 0-.21-.176 4.31 4.31 0 0 0-2.609-.881v2a2.31 2.31 0 0 1 1.45.516l.007.006-.003-.003-.002-.003c-.001 0-.002 0-.002-.002h-.001l-.001-.001.7-.715Zm-2.146-1.798c-1.916 0-3.137.48-3.846 1.279-.704.793-.695 1.68-.695 1.938h2c0-.185.01-.406.19-.61.177-.2.726-.607 2.35-.607v-2ZM5.5 8.774c0 1.24 1.314 2.773 4.54 2.773v-2c-2.686 0-2.54-1.127-2.54-.773h-2Zm4.54 2.773c1.273 0 1.687.373 1.813.525a.64.64 0 0 1 .139.296v.012l.002.01.004.048c.001.007.006.05.018.104.005.02.022.098.065.192a1.8 1.8 0 0 0 .172.26c.121.113.491.296.739.327v-2c.247.03.617.213.738.326.062.075.146.207.172.26.043.094.06.173.064.191.013.054.018.097.018.103l.003.03.001.01v-.002l-.001-.013a2.413 2.413 0 0 0-.08-.448 2.64 2.64 0 0 0-.514-.982c-.609-.734-1.667-1.249-3.352-1.249v2Zm2.952 1.774c-.277-.04-.653-.242-.76-.349a1.802 1.802 0 0 1-.139-.212c-.035-.073-.054-.134-.059-.15a.971.971 0 0 1-.03-.138L12 12.444v.003c0 .019 0 .057-.005.107a.893.893 0 0 1-.12.359c-.106.176-.466.624-1.834.624v2c1.867 0 2.985-.66 3.547-1.592a2.894 2.894 0 0 0 .402-1.697 1.371 1.371 0 0 0-.041-.216.992.992 0 0 0-.06-.15 1.8 1.8 0 0 0-.139-.213c-.106-.106-.482-.31-.758-.348v2Zm-2.951.216c-.738 0-1.46-.26-2.031-.554a6.269 6.269 0 0 1-.872-.546l-.007-.005h.001v.001h.001l-.633.774a158.25 158.25 0 0 0-.631.776l.002.002.007.006a2.646 2.646 0 0 0 .093.072c.06.044.143.106.248.178.21.143.508.332.875.52.72.372 1.768.777 2.947.777v-2Z",
            fill: "#0B0B0C"
        }), c("path", {
            d: "M9.75 4.961v11.173",
            stroke: "#0B0B0C",
            "stroke-width": "2",
            "stroke-linecap": "round"
        })]
    })
}
const Ie = () => {
        const e = D(),
            {
                lendersLink: n
            } = re(),
            {
                pricePerTerm: t,
                minPrice: a,
                maxPrice: r,
                fullPrice: i
            } = e,
            {
                translate: s
            } = p(),
            {
                subTitle: o,
                legalCopy: m
            } = l((() => {
                const {
                    subTitleKey: l,
                    legalCopyKeys: o
                } = (({
                    countryCode: e,
                    eligible: n,
                    fullPrice: t,
                    lendersLink: a,
                    loanTypes: r,
                    minIneligibleMessageType: i,
                    numberOfPaymentTerms: l,
                    priceRange: s
                }) => {
                    var o;
                    const c = Pe({
                            eligible: n,
                            loanTypes: r
                        }),
                        p = ke({
                            fullPrice: t,
                            priceRange: s,
                            numberOfPaymentTerms: l,
                            minIneligibleMessageType: i
                        });
                    return {
                        subTitleKey: null !== (o = _e({
                            modalType: c,
                            numberOfPaymentTerms: l
                        })) && void 0 !== o ? o : p,
                        legalCopyKeys: Te({
                            countryCode: e,
                            lendersLink: a,
                            modalType: c
                        })
                    }
                })(Object.assign(Object.assign({}, e), {
                    lendersLink: n,
                    priceRange: {
                        minPrice: a,
                        maxPrice: null != r ? r : ""
                    }
                }));
                return {
                    subTitle: s(l, {
                        price: c("span", {
                            className: "font-bold",
                            dangerouslySetInnerHTML: {
                                __html: i
                            }
                        }),
                        splitPayLoanRepayment: c("span", {
                            className: "font-bold",
                            dangerouslySetInnerHTML: {
                                __html: t
                            }
                        }),
                        minPrice: c("span", {
                            dangerouslySetInnerHTML: {
                                __html: a
                            }
                        }),
                        maxPrice: c("span", {
                            dangerouslySetInnerHTML: {
                                __html: null != r ? r : ""
                            }
                        })
                    }),
                    legalCopy: o.map((e => {
                        if (Array.isArray(e)) {
                            const [n, t] = e;
                            return s(n, t)
                        }
                        return s(e)
                    })).filter(Boolean).join(" ")
                }
            }), [e, i, n, r, a, t, s]),
            d = l((() => {
                const n = Pe(e);
                return ["adaptive", "split_pay"].includes(n) ? [{
                    description: s("paymentTerms.splitPayContents.interestFees"),
                    icon: c(Ce, {})
                }, {
                    description: s("paymentTerms.splitPayContents.interestCredit"),
                    icon: c(we, {})
                }] : [{
                    description: s("paymentTerms.splitPayContents.noInterestFees"),
                    icon: c(Ce, {})
                }, {
                    description: s("paymentTerms.splitPayContents.noInterestCredit"),
                    icon: c(we, {})
                }]
            }), [e, s]);
        return c(N, {
            children: [c("p", {
                className: "mb-7 text-subtitle font-normal leading-snug",
                "data-testid": "split-pay-subtitle",
                children: o
            }), c("ul", {
                "data-testid": "split-pay-content",
                className: "m-0 list-none p-0",
                children: d.map(((e, n) => c("li", {
                    className: "flex items-center pb-2",
                    children: [c("div", {
                        className: "box-content w-6 flex-none pr-3",
                        children: e.icon
                    }), c("span", {
                        className: "m-0",
                        children: e.description
                    })]
                }, `split-pay-item-list-item=${n+1}`)))
            }), c("p", {
                id: "eligibility-approval",
                className: "mb-5 mt-4 text-caption font-light tracking-wider text-grayscale-d0",
                children: m
            }), c(oe, {})]
        })
    },
    xe = () => {
        const {
            cartPermalink: e,
            modalToken: n,
            modalVariant: t,
            modalOpen: a,
            setModalOpen: i
        } = D(), {
            translate: s
        } = p(), {
            trackModalAction: o
        } = U(), m = r((() => {
            o({
                modalToken: n,
                action: "close",
                cartPermalink: e
            }), i(!1)
        }), [e, n, i, o]), d = l((() => {
            switch (t) {
                case "prequal":
                    return c(ge, {
                        onClose: m
                    });
                case "samplePlans":
                    return c(be, {});
                default:
                    return c(Ie, {})
            }
        }), [m, t]);
        return c(z, {
            variant: "default",
            visible: a,
            onDismiss: m,
            headerTitle: s("paymentTerms.installmentsModal.title"),
            children: c("section", {
                "data-testid": "shopify-payment-terms-modal",
                className: "w-[432px] max-w-full p-8 pt-0 font-system text-grayscale-d2/70",
                children: [c("div", {
                    hidden: !0,
                    id: "shopify-payment-terms-modal-warning-text",
                    children: s("paymentTerms.installmentsModal.newWindow")
                }), d]
            })
        })
    };

function Ne({
    containerStyles: e,
    onLoaded: n,
    onReady: t
}) {
    const {
        instanceId: i
    } = d(), {
        authorizeUrl: l
    } = C({
        analyticsContext: "loginWithShopPrequal",
        analyticsTraceId: i,
        disableSignUp: !0,
        flow: "prequal",
        flowVersion: "prequalAmount",
        hideCopy: !0,
        isCompactLayout: !1,
        proxy: !0,
        requireVerification: !1
    }), {
        translate: s
    } = p(), o = y(null), [m, u] = a(!1), [h, f] = a(!1), [g, b] = a("loading"), {
        destroy: P
    } = S({
        onCustomFlowSideEffect: ({
            fontAssetLoaded: e = !1,
            shopPayInstallmentsOnboarded: n = !1
        }) => {
            u(e), f(n), b("confirmed")
        },
        onError: () => {
            b("error"), null == t || t({
                shopPayInstallmentsOnboarded: !1,
                fontLoaded: !1
            })
        },
        onLoaded: () => {
            "loading" === g && b("loaded")
        },
        onResizeIframe: ({
            height: e,
            width: n
        }) => {
            o.current && (o.current.style.height = `${e}px`, o.current.style.width = `${n}px`), "confirmed" === g && b("ready")
        },
        source: o
    }), _ = r((() => {
        var n;
        e && O({
            contentWindow: null === (n = null == o ? void 0 : o.current) || void 0 === n ? void 0 : n.contentWindow,
            event: {
                type: "setcomponentstyle",
                style: e
            }
        })
    }), [e]);
    return v((() => {
        _()
    }), [e, _]), v((() => {
        "ready" === g && (null == t || t({
            shopPayInstallmentsOnboarded: h,
            fontLoaded: m
        }))
    }), [t, g, h, m]), v((() => {
        "loaded" === g && (null == n || n(), _())
    }), [g, n, _]), v((() => {
        const e = o.current;
        return () => {
            e && P()
        }
    }), [P]), c("div", {
        "data-testid": "container",
        className: "mr-0.5 flex flex-row content-center items-center gap-x-1",
        children: [c("span", {
            "data-testid": "content",
            children: s("paymentTerms.prequalAmount.purchasingPower", {
                defaultValue: "Your purchasing power is"
            })
        }), c("iframe", {
            className: "m-0 inline-block size-0 border-0 p-0",
            "data-testid": "prequal-amount-iframe",
            ref: o,
            src: l,
            title: "Shop Pay Installments pre-qualification amount"
        }), c("span", {
            className: "-ml-1 inline-block",
            children: "."
        })]
    })
}
const Se = () => {
    const {
        dataLoaded: e,
        eligible: n,
        fullPrice: t,
        isLegacyBanner: i,
        pricePerTerm: s,
        minPrice: m,
        maxPrice: u,
        loanTypes: y,
        metaType: h,
        minIneligibleMessageType: f,
        financingTermForBanner: g,
        backgroundColor: v,
        numberOfPaymentTerms: b,
        isEligibleForPrequalification: P,
        hasZeroInterestLoanType: _,
        isInAdaptiveRangeWithoutZeroInterest: T,
        canShowSamplePlanModalContent: k,
        setModalOpen: w
    } = D(), {
        element: C
    } = d(), [I, x] = a(!1), [S, O] = a(!1);
    U();
    const {
        translate: q
    } = p(), L = Boolean(t && n && te(t) >= 50), E = l((() => Boolean(t && te(t) < 150)), [t]), A = l((() => {
        var e;
        if (!I) return;
        const n = null === (e = null == C ? void 0 : C.shadowRoot) || void 0 === e ? void 0 : e.querySelector("#prequalAmountContainer");
        if (!n) return;
        const t = o.getComputedStyle(n);
        return {
            color: t.color,
            fontSize: t.fontSize,
            fontFamily: t.fontFamily,
            letterSpacing: t.letterSpacing,
            fontFace: G(t.fontFamily)
        }
    }), [C, I]), F = l((() => {
        const e = Q(v);
        return c("div", {
            className: M("inline-flex align-middle", e),
            children: c(se, {
                className: "h-[14px] w-[59px]"
            })
        })
    }), [v]), B = r((() => {
        let e = "paymentTerms.banner.nonEligibleMin";
        "monthly" === f ? e = "paymentTerms.banner.nonEligibleMonthlyPaymentsMin" : 2 === b ? e = "paymentTerms.banner.nonEligibleMinOverTime" : 1 === b && (e = "paymentTerms.banner.nonEligibleMinOverTime30");
        const n = q(e, {
            minPrice: c("span", {
                className: "font-bold",
                dangerouslySetInnerHTML: {
                    __html: m
                }
            }),
            shopPayLogo: F
        });
        if (!t || !u) return n;
        return te(t) > te(u) ? q("paymentTerms.banner.nonEligibleMax", {
            maxPrice: c("span", {
                className: "font-bold",
                dangerouslySetInnerHTML: {
                    __html: u
                }
            }),
            shopPayLogo: F
        }) : n
    }), [f, b, q, m, F, t, u]), R = l((() => {
        if ("checkout" === h) return "";
        if (!y.length) return B();
        const e = c("span", {
            className: "font-bold",
            children: s
        });
        if (g && _) {
            const n = 0 === g.apr;
            return q(n ? "paymentTerms.banner.zeroInterestEligibleZeroApr" : "paymentTerms.banner.zeroInterestEligible", {
                price: e,
                shopPayLogo: F
            })
        }
        if (g && T) return q("paymentTerms.banner.payIn4OrAsLowAsEligible", {
            price: e,
            shopPayLogo: F
        });
        if (y.includes("split_pay")) {
            let n = "paymentTerms.banner.splitPayEligible";
            return 2 === b ? n = "paymentTerms.banner.splitPayEligible2" : 1 === b && (n = "paymentTerms.banner.splitPayEligible30"), q(n, {
                price: e,
                shopPayLogo: F
            })
        }
        return y.includes("interest") ? i ? q("paymentTerms.banner.interestOnlyEligible", {
            shopPayLogo: F
        }) : q("paymentTerms.banner.dynamicInterestOnlyEligible", {
            price: e,
            shopPayLogo: F
        }) : B()
    }), [h, y, s, g, _, T, B, q, F, b, i]), j = l((() => q(P ? "paymentTerms.banner.prequal" : n && k ? "paymentTerms.banner.viewSamplePlans" : "paymentTerms.banner.learnMore")), [P, n, k, q]), $ = q(E ? "paymentTerms.banner.learnMore" : "paymentTerms.banner.prequalContents.prequalifiedSeePlans"), Z = r((({
        shopPayInstallmentsOnboarded: e,
        fontLoaded: n
    }) => {
        e && L && (x(!0), n && O(!0))
    }), [L]), z = r((() => {
        w(!0)
    }), [w]);
    if (!e) return null;
    const W = "checkout" !== h && !i;
    return c(N, {
        children: [c("p", {
            className: M("m-0", S ? "" : "font-system"),
            id: "shopify-installments",
            "data-testid": "shopify-installments",
            children: [c("span", {
                className: "pr-1.5",
                id: "shopify-installments-content",
                "data-testid": "shopify-installments-content",
                children: R
            }), c("span", {
                className: "relative inline-flex overflow-hidden",
                children: [c("span", {
                    className: M("inline-flex items-center", I && "absolute translate-y-full animate-fade-out"),
                    id: "prequalBackupCTA",
                    children: c("button", {
                        type: "button",
                        "aria-haspopup": "dialog",
                        className: "m-0 cursor-pointer border-0 bg-transparent p-0 font-inherit underline",
                        id: "shopify-installments-cta",
                        "data-testid": "shopify-installments-cta",
                        onClick: z,
                        children: j
                    })
                }), W && c("span", {
                    className: M("inline-flex min-w-max items-center gap-0.5", I ? "animate-slide-up" : "absolute translate-y-full"),
                    id: "prequalAmountContainer",
                    children: [c(Ne, {
                        containerStyles: A,
                        onLoaded: () => x(!0),
                        onReady: Z
                    }), c("button", {
                        type: "button",
                        "aria-haspopup": "dialog",
                        className: "m-0 cursor-pointer border-0 bg-transparent p-0 font-inherit underline",
                        tabIndex: -1,
                        onClick: z,
                        children: $
                    })]
                })]
            })]
        }), c(xe, {})]
    })
};
const Oe = e => {
        const n = Math.max(...e.terms.map((e => e.installments_count)));
        return e.terms.find((e => e.installments_count === n))
    },
    Me = ({
        fullPrice: e,
        financingPlans: n
    }) => {
        if (!n || 0 === n.length || !e) return [];
        const t = te(e),
            a = Be({
                price: t,
                financingPlans: n
            });
        if (!a) return [];
        const r = new Set;
        return a.terms.forEach((e => {
            "split_pay" === e.loan_type ? r.add("split_pay") : 0 === e.apr ? r.add("zero_percent") : r.add("interest")
        })), Array.from(r)
    },
    qe = ({
        variantId: e,
        variants: n
    }) => {
        var t, a;
        return null !== (a = null === (t = n.find((n => Number(n.id) === e))) || void 0 === t ? void 0 : t.full_price) && void 0 !== a ? a : ""
    },
    Le = {
        boundless: ".cart__subtotal",
        brooklyn: ".cart__subtotal",
        dawn: ".totals__subtotal-value, .sections.cart.new_subtotal",
        debut: ".cart-subtotal__price",
        express: ".cart__subtotal, .cart-drawer__subtotal-value",
        minimal: ".h5.cart__subtotal-price",
        narrative: ".cart-subtotal__price, .cart-drawer__subtotal-number",
        simple: ".cart__subtotal.h3",
        supply: ".h1.cart-subtotal--price",
        venture: ".CartSubtotal"
    },
    Ee = e => e ? Number.parseInt(e, 10) : void 0;

function Ae({
    currencyCode: e,
    financingPlans: n,
    variantId: t,
    variants: a
}) {
    const r = a.find((e => Number(e.id) === t));
    if (!r || !r.full_price) return "";
    const i = r.full_price,
        l = te(i),
        s = Be({
            price: l,
            financingPlans: n
        });
    if (!s) return r.price_per_term;
    const o = Oe(s);
    return Fe({
        currencyCode: e,
        price: l,
        term: o
    })
}
const Fe = ({
        currencyCode: e,
        price: n,
        term: t
    }) => {
        const a = t.apr / 1200,
            r = t.installments_count;
        if (0 === a) return ae({
            currencyCode: e,
            price: n / r
        });
        const i = n * a * Math.pow(1 + a, r),
            l = Math.pow(1 + a, r) - 1;
        return ae({
            currencyCode: e,
            price: i / l
        })
    },
    Be = ({
        financingPlans: e,
        price: n
    }) => e.find((e => {
        const t = te(e.min_price),
            a = te(e.max_price);
        return n >= t && n <= a
    })),
    Re = {
        product: ["variants", "max_price", "min_price", "financing_plans"],
        cart: ["min_price", "max_price", "price_per_term", "eligible", "number_of_payment_terms", "full_price", "financing_plans"],
        checkout: ["min_price", "max_price", "price_per_term", "eligible", "number_of_payment_terms", "full_price", "financing_plans"]
    };

function je(e, n) {
    return n.every((n => n in e))
}

function $e(e, n) {
    return null != e && ("cart" === e.type || "checkout" === e.type ? ze(e, n) : function(e, n) {
        var t;
        const a = ze(e, n);
        if (!a) return !1;
        const r = (null === (t = e.variants) || void 0 === t ? void 0 : t.length) > 0 && je(e.variants[0], ["id", "price_per_term", "eligible", "full_price", "available"]);
        if (!r) return null == n || n("product", JSON.stringify(e)), !1;
        return !0
    }(e, n))
}

function Ze(e, n) {
    return null != e && ("cart" === (null == e ? void 0 : e.type) ? function(e, n) {
        const t = je(e, ["min_price", "max_price", "price", "eligible", "number_of_payment_terms", "available_loan_types"]);
        t || n("cart", JSON.stringify(e))
    }(e, n) : function(e, n) {
        var t;
        const a = je(e, ["variants", "max_price", "min_price", "number_of_payment_terms"]),
            r = (null === (t = e.variants) || void 0 === t ? void 0 : t.length) > 0 && je(e.variants[0], ["id", "price", "eligible", "available_loan_types", "available"]);
        a && r || n("product", JSON.stringify(e))
    }(e, n), je(e, ["min_price", "max_price"]))
}

function ze(e, n) {
    const t = Re[null == e ? void 0 : e.type];
    return !(!t || !je(e, t)) || (null == n || n(null == e ? void 0 : e.type, JSON.stringify(e)), !1)
}

function We({
    onPriceChange: e,
    numberOfPaymentTerms: n
}) {
    const t = r((e => {
        if (!isNaN(e)) return Math.floor(e / n * 100) / 100
    }), [n]);
    v((() => {
        const n = (() => {
                var e, n, t, a, r;
                const i = null === (t = null === (n = null === (e = o.Shopify) || void 0 === e ? void 0 : e.theme) || void 0 === n ? void 0 : n.name) || void 0 === t ? void 0 : t.toLowerCase(),
                    l = null !== (a = Le[i]) && void 0 !== a ? a : null;
                l || s.querySelector("[data-cart-subtotal]") || null === (r = console.warn) || void 0 === r || r.call(console, "[Shop Pay Installments] Cart price updates may not be handled automatically for this theme. To ensure the price shown in the Shop Pay Installments banner is updated correctly, follow the instructions found here: https://shopify.dev/themes/pricing-payments/installments#updating-the-banner-with-cart-total-changes");
                return l
            })(),
            a = new MutationObserver((a => {
                a.forEach((a => {
                    if (a.target.nodeType !== Node.ELEMENT_NODE) return;
                    const r = a.target;
                    if ((r.matches("[data-cart-subtotal]") || n && r.matches(n)) && r.textContent) {
                        const n = te(r.textContent);
                        if (n) {
                            t(n) && e(r.textContent)
                        }
                    }
                }))
            }));
        return a.observe(s, {
            attributes: !0,
            childList: !0,
            subtree: !0
        }), () => a.disconnect()
    }), [e, t])
}
const Ve = ({
        children: e,
        shopifyMeta: n,
        variantId: t
    }) => {
        const {
            notify: p
        } = T(), {
            trackElementImpression: m,
            trackInstallmentsBannerImpression: u,
            trackInstallmentsBannerPrequalInteraction: y,
            trackInvalidInstallmentBannerMetadata: h,
            trackInstallmentsPrequalPopupPageImpression: f,
            trackModalOpened: g
        } = U(), {
            element: b
        } = d(), [P, _] = a(!1), [k, w] = a(!0), [C, I] = a(!1), [x, N] = a(R()), [S, O] = a(""), [M, q] = a(!1), [j, $] = a(t), [Z, z] = a(), D = L(), [H, J] = a(), {
            getCart: G
        } = (() => {
            const {
                notify: e
            } = T();
            return {
                getCart: r((() => i(void 0, void 0, void 0, (function*() {
                    const n = L();
                    try {
                        const e = yield E(`https://${n}/cart.js`);
                        return yield e.json()
                    } catch (t) {
                        return e(new A(`Error fetching cart token: ${t}`, "FetchCartError"), {
                            metadata: {
                                shop: {
                                    hostname: n
                                }
                            }
                        }), {
                            token: "",
                            currency: "",
                            items: []
                        }
                    }
                }))), [e])
            }
        })();
        v((() => {
            j !== t && $(t)
        }), [t]);
        const K = l((() => k ? "shop-pay-banner" : "shop-pay-installments-banner"), [k]),
            X = l((() => (({
                cartDetails: e,
                variantInfo: n,
                modalToken: t
            }) => (null == e ? void 0 : e.token) ? e.token : n ? B({
                variants: n.idQuantityMapping,
                paymentOption: "shop_pay_installments",
                source: "installments_modal",
                sourceToken: t
            }) : void 0)({
                cartDetails: H,
                modalToken: x,
                variantInfo: Z
            })), [H, x, Z]),
            Q = l((() => {
                var e;
                if (!n) return;
                let t;
                try {
                    t = JSON.parse(n)
                } catch (n) {
                    return void(null === (e = console.warn) || void 0 === e || e.call(console, "[Shop Pay Installments] Error parsing metadata", n))
                }
                try {
                    if ($e(t, (() => h(t.type, n)))) return _(!0), w(!1), t;
                    if (Ze(t, (() => h(t.type, n)))) return _(!0), w(!0), t
                } catch (e) {
                    if (e instanceof TypeError && e.message.match("Failed to construct 'HTMLElement': This instance is already constructed")) return void console.error(e);
                    e instanceof Error && p(e, {
                        metadata: {
                            component: {
                                name: "shop-pay-installments-banner",
                                shopifyMeta: n,
                                variantId: j
                            }
                        }
                    })
                }
            }), [p, n, h, j]),
            ee = l((() => {
                var e;
                return null !== (e = null == Q ? void 0 : Q.type) && void 0 !== e ? e : W.metaType
            }), [null == Q ? void 0 : Q.type]),
            ne = l((() => Q && "financing_plans" in Q ? (e => {
                var n;
                const t = null !== (n = null == e ? void 0 : e[0]) && void 0 !== n ? n : null;
                return t ? t.terms.map((e => "split_pay" === e.loan_type ? "split_pay" : 0 === e.apr ? "zero_percent" : "interest")) : []
            })(Q.financing_plans) : []), [Q]),
            re = l((() => (e => e && (e.includes("interest") && !e.includes("split_pay") || e.includes("zero_percent")) ? "monthly" : "split_pay")(ne)), [ne]),
            ie = l((() => Y(b)), [b]),
            {
                canShowSamplePlanModalContent: le,
                countryCode: se,
                currencyCode: oe,
                financingTermForBanner: ce,
                hasZeroInterestLoanType: pe,
                installmentPlans: me,
                installmentsBuyerPrequalificationEnabled: de,
                isEligibleForPrequalification: ue,
                isInAdaptiveRangeWithoutZeroInterest: ye,
                loanTypes: he,
                maxPrice: fe,
                minPrice: ge,
                numberOfPaymentTerms: ve,
                pricePerTerm: be,
                sellerId: _e,
                variantAvailable: Te
            } = l((() => {
                var e, n;
                if (!Q) return W;
                const t = function({
                    extract: e,
                    meta: n
                }) {
                    const t = {};
                    return e.forEach((e => {
                        if (n[e]) {
                            const a = F(e);
                            t[a] = n[e]
                        }
                    })), t
                }({
                    extract: ["country_code", "currency_code", "installments_buyer_prequalification_enabled", "max_price", "min_price", "seller_id"],
                    meta: Q
                });
                let {
                    eligible: a,
                    financingTermForBanner: r,
                    fullPrice: i,
                    installmentPlans: l,
                    loanTypes: s,
                    numberOfPaymentTerms: o,
                    pricePerTerm: c,
                    variantAvailable: p
                } = W;
                const m = "product" === ee;
                if (m && k && j) {
                    const n = Q,
                        t = n.variants.find((e => Number(e.id) === Number(j)));
                    a = !!t && t.eligible, s = t && null !== (e = t.available_loan_types) && void 0 !== e ? e : [], o = n.number_of_payment_terms, c = t ? t.price : ""
                }
                if (m && !k && j) {
                    const e = Q,
                        n = function({
                            currencyCode: e,
                            financingPlans: n,
                            variantId: t,
                            variants: a
                        }) {
                            const r = a.find((e => Number(e.id) === t));
                            if (!r || !r.full_price) return {
                                eligible: !1,
                                financingTermForBanner: null,
                                fullPrice: "",
                                loanTypes: [],
                                pricePerTerm: "",
                                variantAvailable: !1
                            };
                            const i = qe({
                                    variantId: t,
                                    variants: a
                                }),
                                l = te(i),
                                s = Be({
                                    financingPlans: n,
                                    price: l
                                });
                            return {
                                eligible: r.eligible,
                                financingTermForBanner: s ? Oe(s) : null,
                                fullPrice: i,
                                loanTypes: Me({
                                    fullPrice: i,
                                    financingPlans: n
                                }),
                                pricePerTerm: Ae({
                                    currencyCode: e,
                                    financingPlans: n,
                                    variantId: t,
                                    variants: a
                                }),
                                variantAvailable: r.available
                            }
                        }({
                            currencyCode: e.currency_code,
                            financingPlans: e.financing_plans,
                            variants: e.variants,
                            variantId: j
                        });
                    a = n.eligible, r = n.financingTermForBanner, i = n.fullPrice, s = n.loanTypes, o = (({
                        variantId: e,
                        variants: n
                    }) => {
                        const t = n.find((n => Number(n.id) === e));
                        return (null == t ? void 0 : t.number_of_payment_terms) || 4
                    })({
                        variantId: Number(j),
                        variants: e.variants
                    }), c = n.pricePerTerm, p = n.variantAvailable
                }
                if ("cart" === ee && k) {
                    const e = Q;
                    a = e.eligible, s = null !== (n = e.available_loan_types) && void 0 !== n ? n : [], o = e.number_of_payment_terms, c = e.price
                }
                if (("cart" === ee || "checkout" === ee) && !k) {
                    const e = Q;
                    i = e.full_price;
                    const n = e.financing_plans,
                        t = Me({
                            fullPrice: i,
                            financingPlans: n
                        }),
                        l = (({
                            price: e,
                            financingPlans: n
                        }) => {
                            const t = te(e),
                                a = Be({
                                    price: t,
                                    financingPlans: n
                                });
                            if (a) return Oe(a)
                        })({
                            financingPlans: n,
                            price: i
                        });
                    a = e.eligible, r = null != l ? l : null, s = null != t ? t : [], o = l ? l.installments_count : e.number_of_payment_terms, c = l ? Fe({
                        currencyCode: e.currency_code,
                        price: te(e.full_price),
                        term: l
                    }) : e.price_per_term
                }
                const d = s.includes("zero_percent"),
                    u = a && !d && 2 === s.length && s.includes("split_pay") && s.includes("interest");
                l = Q && "financing_plans" in Q ? (({
                    currencyCode: e,
                    financingPlans: n,
                    isInAdaptiveRangeWithoutZeroInterest: t,
                    totalPrice: a
                }) => {
                    if (!a) return [];
                    const r = te(a),
                        i = Be({
                            price: r,
                            financingPlans: n
                        });
                    if (!i) return [];
                    const l = (({
                        terms: e,
                        isInAdaptiveRangeWithoutZeroInterest: n
                    }) => {
                        if (e.length < 3) return e;
                        if (n) return [e[0], e[e.length - 1]];
                        const t = e.filter((e => "split_pay" !== e.loan_type));
                        return t.length < 3 ? t : [t[0], t[t.length - 1]]
                    })({
                        terms: i.terms,
                        isInAdaptiveRangeWithoutZeroInterest: t
                    }).map((n => ({
                        pricePerTerm: Fe({
                            currencyCode: e,
                            price: r,
                            term: n
                        }),
                        apr: n.apr,
                        numberOfPaymentTerms: n.installments_count,
                        loanType: n.loan_type
                    })));
                    return l
                })({
                    currencyCode: Q.currency_code,
                    totalPrice: i,
                    financingPlans: Q.financing_plans,
                    isInAdaptiveRangeWithoutZeroInterest: u
                }) : [];
                const y = Boolean(a && t.installmentsBuyerPrequalificationEnabled),
                    h = 1 === s.length && "interest" === s[0],
                    f = Boolean((null == l ? void 0 : l.length) && i && (d || h || u));
                return q(a), O(i), Object.assign(Object.assign({}, t), {
                    canShowSamplePlanModalContent: f,
                    financingTermForBanner: r,
                    hasZeroInterestLoanType: d,
                    isEligibleForPrequalification: y,
                    isInAdaptiveRangeWithoutZeroInterest: u,
                    installmentPlans: l,
                    loanTypes: s,
                    numberOfPaymentTerms: o,
                    pricePerTerm: c,
                    variantAvailable: p
                })
            }), [k, ee, Q, j]),
            ke = l((() => le ? ye ? "pay_in_4_or_as_low_as" : "as_low_as" : "pay_in_4"), [le, ye]),
            we = l((() => function({
                installmentPlans: e = [],
                fullPrice: n = "",
                currencyCode: t
            }) {
                return e.map((({
                    pricePerTerm: e,
                    apr: a,
                    numberOfPaymentTerms: r,
                    loanType: i
                }) => {
                    const l = te(e) * r,
                        s = te(n);
                    return {
                        apr: a,
                        interest: ae({
                            currencyCode: t,
                            price: 0 === a ? 0 : l - s
                        }),
                        loanType: i,
                        numberOfPaymentTerms: r,
                        pricePerTerm: e,
                        totalPriceWithInterest: ae({
                            currencyCode: t,
                            price: 0 === a ? s : l
                        })
                    }
                }))
            }({
                currencyCode: oe,
                installmentPlans: me,
                fullPrice: S
            })), [oe, me, S]),
            Ce = l((() => {
                let e = "splitPay";
                return ue ? e = "prequal" : le && (e = "samplePlans"), e
            }), [le, ue]),
            Ie = l((() => {
                switch (Ce) {
                    case "prequal":
                        return (({
                            eligible: e,
                            loanTypes: n,
                            samplePlans: t
                        }) => {
                            if (!n.length || !e) return "ineligible";
                            if (t.some((e => 0 === e.apr && "interest" === e.loanType))) return t.every((e => 0 === e.apr)) ? "zero_interest_only" : "zero_interest";
                            return (null == t ? void 0 : t.some((e => "split_pay" === e.loanType))) && (null == t ? void 0 : t.some((e => "interest" === e.loanType))) ? "adaptive" : "interest_only"
                        })({
                            samplePlans: we,
                            loanTypes: he,
                            eligible: M
                        });
                    case "samplePlans":
                        return (e => {
                            if (e.some((e => 0 === e.apr && "interest" === e.loanType))) return e.every((e => 0 === e.apr)) ? "zero_interest_only" : "zero_interest";
                            return e.some((e => "split_pay" === e.loanType)) && e.some((e => "interest" === e.loanType)) ? "adaptive" : "interest_only"
                        })(we);
                    default:
                        return Pe({
                            eligible: M,
                            loanTypes: he
                        })
                }
            }), [M, he, Ce, we]),
            xe = r((e => {
                if (!ge || !fe) return !1;
                const n = te(ge),
                    t = te(fe);
                return e >= n && e <= t
            }), [ge, fe]);
        We({
            numberOfPaymentTerms: ve,
            onPriceChange: e => {
                O(e), q(xe(te(e)))
            }
        }), v((() => {
            P && (u({
                bannerContent: ke,
                bannerTemplateCodeSignature: k ? "customized_by_merchant" : "standard",
                eligible: M,
                hasPrequalLink: ue,
                origin: ee,
                price: S,
                variantId: j
            }), m({
                elementType: ee,
                elementName: K
            }))
        }), [ke, P, K, M, S, ue, k, ee, m, u, j]), v((() => {
            if ("cart" !== ee || !le) return;
            ! function() {
                i(this, void 0, void 0, (function*() {
                    J(yield(() => {
                        if (D) return G()
                    })())
                }))
            }()
        }), [le, G, D, ee]), v((() => {
            var e;
            if ("checkout" === ee) {
                const n = null === (e = null == b ? void 0 : b.shadowRoot) || void 0 === e ? void 0 : e.querySelector("#shopify-installments");
                null == n || n.classList.add("inline")
            }
        }), [null == b ? void 0 : b.shadowRoot, ee]), v((() => {
            if ("product" !== ee) return;
            const e = null == b ? void 0 : b.closest("form"),
                n = null == e ? void 0 : e.elements,
                t = null == n ? void 0 : n.quantity;
            let a = null;
            if (!t) {
                const n = null == e ? void 0 : e.getAttribute("id"),
                    t = null == n ? void 0 : n.replace("product-form-installment-", "");
                a = s.getElementById(`Quantity-${t}`)
            }
            const r = t || a,
                i = () => {
                    var e;
                    const n = null !== (e = null == r ? void 0 : r.value) && void 0 !== e ? e : 1;
                    z({
                        available: Te,
                        idQuantityMapping: `${j}:${n}`
                    })
                };
            return null == r || r.addEventListener("change", i), null == r || r.addEventListener("input", i), i(), () => {
                null == r || r.removeEventListener("change", i), null == r || r.removeEventListener("input", i)
            }
        }), [b, ee, Te, j]), v((() => {
            if (!C) return;
            const e = R();
            N(e)
        }), [C]), v((() => {
            if (!C) return;
            const e = "splitPay" === Ce ? "[]" : JSON.stringify(we);
            g({
                cartPermalink: "splitPay" === Ce ? void 0 : X,
                eligibleSpiPlanType: Ie,
                modalToken: x,
                origin: ee,
                price: S,
                spiPlanDetails: e,
                variantId: j
            }), m({
                elementType: ee,
                elementName: "shopify-installments-modal"
            }), ue && (y({
                bannerContent: ke,
                eligible: M,
                origin: ee,
                prequalLinkClicked: !0,
                price: S
            }), f({
                sellerId: Ee(_e),
                pageType: "prequal_intro_page_loaded"
            }))
        }), [ke, X, M, S, ue, ee, C, x, Ie, Ce, we, _e, m, y, f, g, j]), v((() => {
            const e = null == b ? void 0 : b.closest("form");
            if (!e) return;
            const n = (t = 0) => {
                    if (t > 4) return;
                    const a = e.querySelector('select[name^="id"]') || e.querySelector('[name^="id"]'),
                        r = new o.URL(o.location.href).searchParams.get("variant");
                    let i;
                    a && (i = Number(a.value)), a || isNaN(Number(r)) || (i = Number(r)), i && (j === i ? setTimeout((() => n(t + 1)), 100) : $(i))
                },
                t = () => n();
            return e.addEventListener("change", t), () => {
                e.removeEventListener("change", t)
            }
        }), [b, j]);
        const Ne = l((() => {
                if ("checkout" === ee || "splitPay" === Ce) return null;
                const e = B({
                    variants: null == Z ? void 0 : Z.idQuantityMapping,
                    paymentOption: "shop_pay_installments",
                    source: "installments_modal",
                    sourceToken: x
                });
                return "#" === e ? null : e
            }), [ee, x, Ce, Z]),
            Se = l((() => ({
                backgroundColor: ie,
                bannerContent: ke,
                canShowSamplePlanModalContent: le,
                cartPermalink: X,
                checkoutUrl: Ne,
                countryCode: se,
                currencyCode: oe,
                dataLoaded: P,
                eligible: M,
                financingTermForBanner: ce,
                fullPrice: ae({
                    price: te(S),
                    currencyCode: oe
                }),
                hasZeroInterestLoanType: pe,
                installmentPlans: me,
                installmentsBuyerPrequalificationEnabled: de,
                isEligibleForPrequalification: ue,
                isInAdaptiveRangeWithoutZeroInterest: ye,
                isLegacyBanner: k,
                loanTypes: he,
                maxPrice: fe ? ae({
                    price: te(fe),
                    currencyCode: oe
                }) : void 0,
                metaType: ee,
                minIneligibleMessageType: re,
                minPrice: ae({
                    price: te(ge),
                    currencyCode: oe
                }),
                modalOpen: C,
                modalToken: x,
                modalVariant: Ce,
                numberOfPaymentTerms: ve,
                pricePerTerm: be,
                samplePlans: we,
                sellerId: _e,
                setModalOpen: I,
                variantAvailable: Te,
                variantId: j,
                variantInfo: Z
            })), [ie, ke, le, X, Ne, se, oe, P, M, ce, S, pe, me, de, ue, ye, k, he, fe, ee, re, ge, C, x, Ce, ve, be, we, _e, Te, j, Z]);
        return c(V.Provider, {
            value: Se,
            children: e
        })
    },
    De = () => (v((() => {
        if (s.querySelector('style[data-description="shop-pay-installments-font-faces"]')) return;
        const e = s.createElement("style");
        e.dataset.description = "shop-pay-installments-font-faces", e.appendChild(s.createTextNode("\n        @font-face {\n          font-family: 'InterVariable';\n          src: url('https://cdn.shopify.com/static/fonts/inter/v4/InterVariable.woff2') format('woff2');\n          font-weight: 100 900;\n          font-display: swap;\n          font-style: normal;\n          font-named-instance: 'Regular';\n        }")), s.head.appendChild(e)
    }), []), c(Se, {})),
    He = e => i(void 0, void 0, void 0, (function*() {
        return {
            paymentTerms: {
                banner: {
                    learnMore: "Learn more",
                    viewSamplePlans: "View sample plans",
                    prequal: "Check your purchasing power",
                    splitPayEligible: "Pay in 4 interest-free installments of {price} with {shopPayLogo}",
                    splitPayEligible2: "Pay in 2 interest-free installments of {price} with {shopPayLogo}",
                    splitPayEligible30: "Pay {price} within 30 days interest-free with {shopPayLogo}",
                    interestOnlyEligible: "Split your purchase into monthly installments with {shopPayLogo}",
                    dynamicInterestOnlyEligible: "From {price}/mo with {shopPayLogo}",
                    payIn4OrAsLowAsEligible: "4 interest-free installments, or from {price}/mo with {shopPayLogo}",
                    zeroInterestEligible: "From {price}/mo or 0% APR with {shopPayLogo}",
                    zeroInterestEligibleZeroApr: "From {price}/mo at 0% APR with {shopPayLogo}",
                    nonEligibleMin: "Pay in 4 interest-free installments for orders over {minPrice} with {shopPayLogo}",
                    nonEligibleMinOverTime: "Pay over time for orders over {minPrice} with {shopPayLogo}",
                    nonEligibleMinOverTime30: "Pay within 30 days interest-free for orders over {minPrice} with {shopPayLogo}",
                    nonEligibleMonthlyPaymentsMin: "Split your purchase into monthly installments for orders over {minPrice} with {shopPayLogo}",
                    nonEligibleMax: "Split your purchase into installments for orders up to {maxPrice} with {shopPayLogo}",
                    prequalContents: {
                        notPrequalifiedSeePlans: "Check your purchasing power",
                        prequalifiedSeePlans: "See plans",
                        purchasingPowerA: "Your purchasing power is ",
                        purchasingPowerB: "Spend any amount up to "
                    }
                },
                prequalAmount: {
                    purchasingPower: "Your purchasing power is "
                },
                installmentsModal: {
                    title: "Get it now, pay later",
                    close: "Close",
                    newWindow: "Opens in a new window.",
                    partnership: "Installments in partnership with {affirmLogo}",
                    partnershipDisclaimer: "Installments in partnership with {affirmLogo}. Translation services are not provided by Affirm. Affirm and its offerings are only supported in English."
                },
                prequalOverlay: {
                    continue: "Continue",
                    needMoreInfo: "We need a bit more information",
                    clickContinue: "Click continue and a new tab will open so you can provide your information securely."
                },
                splitPayContents: {
                    interestFees: "No hidden fees, ever.",
                    interestCredit: "No impact on your credit score to apply.",
                    noInterestFees: "No fees, ever.",
                    noInterestCredit: "No impact on your credit score to apply.",
                    subtitle: {
                        interestAndSplitPay: "Choose your payment schedule at checkout - starting at 4 interest-free payments of {splitPayLoanRepayment} every 2 weeks.",
                        interestOnly: "Choose your payment schedule at checkout to split your purchase into monthly installments.",
                        splitPayOnly: "Select installments at checkout to split your purchase into 4 interest-free payments of {splitPayLoanRepayment} every 2 weeks.",
                        splitPayOnly2: "Select installments at checkout to split your purchase into 2 interest-free payments of {splitPayLoanRepayment} every 15 days.",
                        splitPayOnly30: "Select installments at checkout to pay for your purchase of {price} interest-free within 30 days.",
                        ineligibleMin: "For orders over {minPrice}, select installments at checkout to split your purchase into 4 interest-free payments.",
                        ineligibleMinOverTime: "For orders over {minPrice}, select installments at checkout to split your purchase over time.",
                        ineligibleMonthlyPaymentsMin: "For orders over {minPrice}, select installments at checkout to split your purchase into monthly payments.",
                        ineligibleMax: "For orders up to {maxPrice}, select installments at checkout to split your purchase into multiple payments."
                    },
                    legal: {
                        CA: "The estimated payment amount excludes taxes and shipping. Payment options are offered by Affirm and are subject to an eligibility check and might not be available in all provinces and/or territories.",
                        caResidentsNotice: "CA Residents: Loans by Affirm Loan Services, LLC are made or arranged pursuant to a California Finance Lender license.",
                        ratesFromApr: "Rates from 0-36% APR. Payment options through Affirm are subject to an eligibility check, may not be available in all states, and are provided by these lending partners: {link}. Options depend on your purchase amount, and a down payment may be required.",
                        interestAndSplitPay: "The estimated payment amount excludes taxes and shipping.",
                        splitPayOnly: "The estimated payment amount excludes taxes and shipping. Payment options are offered by Affirm and are subject to an eligibility check and might not be available in all states.",
                        ineligible: "Payment options are offered by Affirm and are subject to an eligibility check and might not be available in all states."
                    }
                },
                samplePlansContent: {
                    subtitle: {
                        one: "Sample plan for {priceWithoutInterest} purchase",
                        other: "Sample plans for {priceWithoutInterest} purchase"
                    },
                    legal: {
                        US: "The estimated payment amount excludes taxes and shipping. Rates range from 0-36% APR. Payment options through Shop Pay Installments are subject to an eligibility check and are provided by these lending partners: {lendersLink}. Options depend on your purchase amount, and a down payment may be required. More options may be available upon approval. State notices to consumers: {licensesLink}.",
                        CA: "The estimated payment amount excludes taxes and shipping. Rates range from 0-32% APR (subject to provincial regulatory limits). Payment options through Shop Pay Installments are subject to an eligibility check and approval. Options depend on your purchase amount, and a down payment may be required. More options may be available upon approval. Available in select provinces and/or territories. Visit {affirmCanadaHelpLink} for more info."
                    },
                    continueToCheckout: "Continue to checkout",
                    unavailable: "Unavailable",
                    informationShared: "By continuing, your information will be shared with Affirm.",
                    checkingEligibility: "Checking your qualification won’t affect your credit.",
                    interestDetails: "Interest ({apr}% APR)",
                    total: "Total",
                    splitPayFrequency: "{pricePerTerm} {frequency}",
                    otherFrequency: "{pricePerTerm} {frequency}",
                    everyTwoWeeks: "every 2 weeks",
                    monthly: "every month",
                    splitPayNumberOfTerms: "for {numberOfTerms} weeks",
                    otherNumberOfTerms: "for {numberOfTerms} months"
                },
                prequalContent: {
                    processing: "Processing your request",
                    processingTime: "This can take up to a minute..."
                },
                buttons: {
                    check: "Check if you qualify",
                    unavailable: "Unavailable",
                    continueToCheckout: "Continue to checkout"
                }
            }
        }
    }));
j((e => {
    var {
        element: n
    } = e, t = _(e, ["element"]);
    return c($, {
        element: n,
        featureName: "ShopifyPaymentTerms",
        getFeatureDictionary: He,
        children: c(Ve, Object.assign({}, t, {
            children: c(De, Object.assign({}, t))
        }))
    })
}), {
    name: "shopify-payment-terms",
    props: {
        variantId: "number",
        shopifyMeta: "string"
    },
    shadow: "open"
});
//# sourceMappingURL=client.payment-terms_BhWs7j4b.en.esm.js.map