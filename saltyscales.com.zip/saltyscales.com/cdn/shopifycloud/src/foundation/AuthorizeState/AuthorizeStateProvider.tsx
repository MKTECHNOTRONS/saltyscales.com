import type {FunctionComponent, PropsWithChildren} from 'preact/compat';
import {useMemo, useReducer} from 'preact/compat';

import {AuthorizeStateContext} from './context';
import {reducer} from './reducer';

export const AuthorizeStateProvider: FunctionComponent<PropsWithChildren> = ({
  children,
}) => {
  const [state, dispatch] = useReducer(reducer, {
    autoOpened: false,
    loaded: false,
    modalDismissible: false,
    modalForceHidden: false,
    modalVisible: false,
    sessionDetected: false,
  });

  const value = useMemo(() => {
    const {
      autoOpened,
      loaded,
      modalDismissible,
      modalForceHidden,
      modalVisible,
      sessionDetected,
    } = state;

    return {
      autoOpened,
      dispatch,
      loaded,
      modalDismissible,
      modalForceHidden,
      modalVisible: modalVisible && !modalForceHidden,
      sessionDetected,
    };
  }, [dispatch, state]);

  return (
    <AuthorizeStateContext.Provider value={value}>
      {children}
    </AuthorizeStateContext.Provider>
  );
};
